%=========================================================================
%=========================================================================

function [sys,x0,str,ts] = modl_grid(t,x,u,flag,par)
% Netzseitiges Filter
% Inputs    u(1:3) = iin
% States    x(1:3) = iL
% Outputs   y(1:3) = uout

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes(par);
    case 1 % Calculate derivatives
        sys = mdlDerivatives(t,x,u,par);
    case 3 % Calculate outputs
        sys = mdlOutputs(t,x,u,par);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par)
        x0 = par.grid.ig0;
        sizes = simsizes;
        sizes.NumContStates  = numel(x0);
        sizes.NumDiscStates  = 0;
        sizes.NumOutputs     = 3;
        sizes.NumInputs      = 3;
        sizes.DirFeedthrough = 1;
        sizes.NumSampleTimes = 1;
        sys = simsizes(sizes);
        
        str = [];
        % sample time is continuous -> ts = 0 and offset = 0
        ts = [0 0];
    end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(t,x,u,par)
        
        if par.CalcRMS == 0 
            iI = u;
        
            omg = par.grid.omg;
            phi = par.grid.Vgphi;
            mag = par.grid.Vgmag; 
            if t < 4 && t > 3
                mag = 0.3*mag; phi = phi+pi/6;
            end
            V2 = mag * [ sin(omg*t + phi) ; sin(omg*t + phi - 2/3*pi) ; sin(omg*t + phi + 2/3*pi) ]; 

            Rs = par.grid.Rs;
            R = par.grid.Rg;
            L = par.grid.Lg;
            dx = ( - (Rs+R)*x - V2 + Rs*iI ) / L;
        else 
            dx = zeros(3,1); 
        end

    end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(t,x,u,par)
        if par.CalcRMS == 0 
            Rs = par.grid.Rs;
            iI = u;
            i = x;
            is = iI - i;
            y = is*Rs;
        else
            iI = u;
            omg = par.grid.omg;
            phi = par.grid.Vgphi;
            mag = par.grid.Vgmag; 
            V2 = mag * [ sin(omg*t + phi) ; sin(omg*t + phi - 2/3*pi) ; sin(omg*t + phi + 2/3*pi) ];
            v2_ab = par.Conv.T*V2;
            v2_ab = v2_ab(1)+1j*v2_ab(2);
            iI_ab = par.Conv.T*iI;
            iI_ab = iI_ab(1)+1j*iI_ab(2);
            Rs = par.grid.Rs;
            R = par.grid.Rg;
            L = par.grid.Lg;
            i_ab = (Rs*iI_ab-v2_ab)/(Rs+R+1j*omg*L);
            vs_ab = Rs*(iI_ab-i_ab);
            y = par.Conv.T_*[real(vs_ab);imag(vs_ab)];
            
        end
    end

end % end of modl_grid %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

