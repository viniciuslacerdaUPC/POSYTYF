%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = WTPrimary(t,x,u,flag,par_WT)

% BlockInfo, SysHandle (~) = Model.System.Block_42.System.Block_11
%  SID  BlockHandle             BlockType               BlockName
%  472  ~                       SubSystem               WT Primary
%  474  ~.System.Block          Inport                  v_in_PU
%  475  ~.System.Block_1        Inport                  P_req_in_PU
%  476  ~.System.Block_22       Outport                 power_WT
%  851  ~.System.Block_8        Mux                     Mux
%  852  ~.System.Block_16       S-Function              S-Function
%  854  ~.System.Block_7        Sum                     Minus
%  855  ~.System.Block_3        Constant                Constant
%  856  ~.System.Block_15       Product                 Product3
%  857  ~.System.Block_4        Constant                Constant1
%  862  ~.System.Block_5        Demux                   Demux
%  864  ~.System.Block_14       Scope                   Pitch angle
%  865  ~.System.Block_20       Scope                   generator torque
%  866  ~.System.Block_21       Scope                   tower movement
%  867  ~.System.Block_9        Mux                     Mux1
%  868  ~.System.Block_10       Mux                     Mux2
%  869  ~.System.Block_2        Scope                   Blade out of Plane Movement
%  870  ~.System.Block_11       Mux                     Mux3
%  871  ~.System.Block_6        Scope                   Drive Train States
%  872  ~.System.Block_12       Mux                     Mux4
%  873  ~.System.Block_13       Scope                   Observer States
%  874  ~.System.Block_17       Scope                   Scope power WT
%  875  ~.System.Block_18       Scope                   Scope req Power in PU
%  876  ~.System.Block_19       Scope                   Scope windspeed

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_852 = par_WT;

% Initialisation
if flag == 0
    x0 = zeros(13,1);
    [~,x0_temp] = sFunc_WTmdl([],[],[],0,p_852);
    x0(1:13) = x0_temp(1:13);
    sys = [13 ,... % NumContStates
           0 ,... % NumDiscStates
           1 ,... % NumOutputs
           2 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 2;
    info.InportsVarName{1} = 'v_in_PU'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'P_req_in_PU'; info.InportsDimension{2} = [1 1];
    info.NumOutports = 1;
    info.OutportsVarName{1} = 'power_WT'; info.OutportsDimension{1} = [1 1];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:2,1) = u{2};
    elseif isa(u,'struct')
        u0(1:1,1) = u.v_in_PU;
        u0(2:2,1) = u.P_req_in_PU;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)WTPrimary(t,x,u,flag,par_WT);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_852(1:13,1) = x(1:13);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        v_in_PU = u{1};
        P_req_in_PU = u{2};
    elseif isa(u,'struct')
        v_in_PU = u.v_in_PU;
        P_req_in_PU = u.P_req_in_PU;
    else
        v_in_PU = zeros([1 1]);  v_in_PU(:) = u(1:1);
        P_req_in_PU = zeros([1 1]);  P_req_in_PU(:) = u(2:2);
    end
end

u_856_1 = v_in_PU;            % Product3        <-- v_in_PU         

% Constant Block 857 "Constant1"
y_857 = 11.6;
u_856_2 = y_857;              % Product3        <-- Constant1       

% Product Block 856 "Product3"
y_856 =u_856_1 .* u_856_2;

u_851_2 = y_856;              % Mux             <-- Product3        
u_854_2 = P_req_in_PU;        % Minus           <-- P_req_in_PU     

% Constant Block 855 "Constant"
y_855 = 1;
u_854_1 = y_855;              % Minus           <-- Constant        

% Sum Block 854 "Minus"
y_854 = + u_854_1 - u_854_2;

u_851_1 = y_854;              % Mux             <-- Minus           

% Mux Block 851 "Mux"
y_851 = [u_851_1;u_851_2];

u_852_1 = y_851;              % S-Function      <-- Mux             

% S-Function Block 852 "S-Function"
y_852 = sFunc_WTmdl(t,x_852,[],3,p_852);

u_862_1 = y_852;              % Demux           <-- S-Function      

% Demux Block 862 "Demux"
y_862_1 = u_862_1(1);
y_862_2 = u_862_1(2);
y_862_3 = u_862_1(3);
y_862_4 = u_862_1(4);
y_862_5 = u_862_1(5);
y_862_6 = u_862_1(6);
y_862_7 = u_862_1(7);
y_862_8 = u_862_1(8);
y_862_9 = u_862_1(9);
y_862_10 = u_862_1(10);
y_862_11 = u_862_1(11);
y_862_12 = u_862_1(12);
y_862_13 = u_862_1(13);
y_862_14 = u_862_1(14);

power_WT = y_862_1;           % power_WT        <-- Demux           
u_867_2 = y_862_5;            % Mux1            <-- Demux           
u_867_1 = y_862_4;            % Mux1            <-- Demux           
u_867_3 = y_862_6;            % Mux1            <-- Demux           
u_867_4 = y_862_7;            % Mux1            <-- Demux           

% Mux Block 867 "Mux1"
y_867 = [u_867_1;u_867_2;u_867_3;u_867_4];

u_868_1 = y_862_8;            % Mux2            <-- Demux           
u_868_2 = y_862_9;            % Mux2            <-- Demux           

% Mux Block 868 "Mux2"
y_868 = [u_868_1;u_868_2];

u_870_1 = y_862_10;           % Mux3            <-- Demux           
u_870_2 = y_862_11;           % Mux3            <-- Demux           
u_870_3 = y_862_12;           % Mux3            <-- Demux           

% Mux Block 870 "Mux3"
y_870 = [u_870_1;u_870_2;u_870_3];

u_872_1 = y_862_13;           % Mux4            <-- Demux           
u_872_2 = y_862_14;           % Mux4            <-- Demux           

% Mux Block 872 "Mux4"
y_872 = [u_872_1;u_872_2];


% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(13,1);
        
        % S-Function derivative call of "S-Function" (SID 852)
        dx(1:13) = sFunc_WTmdl(t,x_852,u_852_1,1,p_852);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = power_WT;
        elseif flagout == 2
            y = struct();
            y.power_WT = power_WT;
        else
            y = power_WT;
        end
        sys = y;
end

end % end of WTPrimary
