function [sys,x0,info,ts] = WTSecondary(t,x,u,flag,par_INV)

if par_INV.CalcRMS ~= 0
    error('par_INV.CalcRMS must be 0');
end

if par_INV.ConvVersion == 0 % GFOL
    if flag == 0
        [sys,x0,info,ts] = WTSecondary_GFOL_EMT(t,x,u,flag,par_INV);
    else
        sys = WTSecondary_GFOL_EMT(t,x,u,flag,par_INV);
    end
elseif par_INV.ConvVersion == 2 % GFOR
    if flag == 0
        [sys,x0,info,ts] = WTSecondary_GFOR_EMT(t,x,u,flag,par_INV);
    else
        sys = WTSecondary_GFOR_EMT(t,x,u,flag,par_INV);
    end
else
    error('par_INV.ConvVersion must be 0 or 2');
end