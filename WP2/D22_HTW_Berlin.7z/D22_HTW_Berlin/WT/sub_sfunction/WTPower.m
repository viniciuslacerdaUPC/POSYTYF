function [sys,x0,info,ts] = WTPower(t,x,u,flag,par_INV,par_WT)

if par_INV.CalcRMS ~= 0
    error('par_INV.CalcRMS must be 0');
end

if par_INV.ConvVersion == 0 % GFOL
    if flag == 0
        [sys,x0,info,ts] = WTPower_GFOL_EMT(t,x,u,flag,par_INV,par_WT);
    else
        sys = WTPower_GFOL_EMT(t,x,u,flag,par_INV,par_WT);
    end
elseif par_INV.ConvVersion == 2 % GFOR
    if flag == 0
        [sys,x0,info,ts] = WTPower_GFOR_EMT(t,x,u,flag,par_INV,par_WT);
    else
        sys = WTPower_GFOR_EMT(t,x,u,flag,par_INV,par_WT);
    end
else
    error('par_INV.ConvVersion must be 0 or 2');
end