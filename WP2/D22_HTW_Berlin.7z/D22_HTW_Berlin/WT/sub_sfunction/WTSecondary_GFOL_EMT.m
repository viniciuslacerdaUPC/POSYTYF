%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = WTSecondary(t,x,u,flag,par_INV)

% BlockInfo, SysHandle (~) = Model.System.Block_30.System.Block_12
%  SID  BlockHandle             BlockType               BlockName
% 1103  ~                       SubSystem               WT secondary
% 1104  ~.System.Block          Inport                  P_DC_in_PU
% 1105  ~.System.Block_1        Inport                  v_grid_mag_phase
% 1106  ~.System.Block_2        Inport                  Q_req_in_PU
% 1107  ~.System.Block_4        Product                 Divide1
% 1108  ~.System.Block_5        Product                 Divide2
% 1109  ~.System.Block_6        Product                 Divide3
% 1110  ~.System.Block_7        Product                 Divide4
% 1111  ~.System.Block_8        Product                 Divide5
% 1112  ~.System.Block_11       Scope                   INV_P_grid / INV_Q_grid / Q_GRID
% 1113  ~.System.Block_12       Scope                   INV_i_filter
% 1114  ~.System.Block_14       Scope                   INV_v_grid_abc
% 1119  ~.System.Block_9        Gain                    Gain1
% 1120  ~.System.Block_10       Scope                   I filter abc
% 1121  ~.System.Block_13       Scope                   INV_omega_PLL
% 1122  ~.System.Block_15       Mux                     Mux
% 1123  ~.System.Block_16       Mux                     Mux1
% 1124  ~.System.Block_17       Mux                     Mux2
% 1125  ~.System.Block_25       Scope                   P_grid / Q_grod
% 1127  ~.System.Block_33       S-Function              S-Function4
% 1128  ~.System.Block_34       S-Function              S-Function5
% 1129  ~.System.Block_35       S-Function              S-Function6
% 1130  ~.System.Block_36       Terminator              Terminator
% 1131  ~.System.Block_37       Selector                V abc 
% 1132  ~.System.Block_38       Scope                   inv_v_DC
% 1133  ~.System.Block_39       Scope                   inv_v_terminal_abc
% 1134  ~.System.Block_40       Selector                omega PLL in PU
% 1135  ~.System.Block_41       Selector                states
% 1141  ~.System.Block_19       Constant                PU Current
% 1142  ~.System.Block_20       Constant                PU Current1
% 1143  ~.System.Block_21       Constant                PU Power
% 1144  ~.System.Block_22       Constant                PU Power1
% 1145  ~.System.Block_23       Constant                PU Voltage
% 1146  ~.System.Block_24       Constant                PU Voltage1
% 1147  ~.System.Block_26       Product                 Product1
% 1148  ~.System.Block_27       Product                 Product2
% 1149  ~.System.Block_28       Product                 Product3
% 1150  ~.System.Block_30       S-Function              S-Function1
% 1151  ~.System.Block_31       S-Function              S-Function2
% 1152  ~.System.Block_32       S-Function              S-Function3
% 1153  ~.System.Block_42       Outport                 P_grid_in_PU
% 1154  ~.System.Block_43       Outport                 Q_grid_in_PU
% 1155  ~.System.Block_44       Outport                 iF_mag_phase
% 1156  ~.System.Block_45       Outport                 v_mag_phase
% 1157  ~.System.Block_46       Outport                 v_DC_in_PU
% 1203  ~.System.Block_3        Demux                   Demux
% 1204  ~.System.Block_29       S-Function              S-Function
% 1206  ~.System.Block_18       Mux                     Mux3

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_1150 = 1.5707963267949;
p_1127 = par_INV;
p_1128 = par_INV;
p_1129 = par_INV;

% Initialisation
if flag == 0
    x0 = zeros(13,1);
    [~,x0_temp] = sfun_capacitor([],[],[],0,p_1127);
    x0(1:1) = x0_temp(1:1);
    [~,x0_temp] = sFunc_converter([],[],[],0,p_1128);
    x0(2:10) = x0_temp(1:9);
    [~,x0_temp] = modl_filter([],[],[],0,p_1129);
    x0(11:13) = x0_temp(1:3);
    sys = [13 ,... % NumContStates
           0 ,... % NumDiscStates
           7 ,... % NumOutputs
           4 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 3;
    info.InportsVarName{1} = 'P_DC_in_PU'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'v_grid_mag_phase'; info.InportsDimension{2} = [2 1];
    info.InportsVarName{3} = 'Q_req_in_PU'; info.InportsDimension{3} = [1 1];
    info.NumOutports = 5;
    info.OutportsVarName{1} = 'P_grid_in_PU'; info.OutportsDimension{1} = [1 1];
    info.OutportsVarName{2} = 'Q_grid_in_PU'; info.OutportsDimension{2} = [1 1];
    info.OutportsVarName{3} = 'iF_mag_phase'; info.OutportsDimension{3} = [1 2];
    info.OutportsVarName{4} = 'v_mag_phase'; info.OutportsDimension{4} = [1 2];
    info.OutportsVarName{5} = 'v_DC_in_PU'; info.OutportsDimension{5} = [1 1];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:3,1) = u{2};
        u0(4:4,1) = u{3};
    elseif isa(u,'struct')
        u0(1:1,1) = u.P_DC_in_PU;
        u0(2:3,1) = u.v_grid_mag_phase;
        u0(4:4,1) = u.Q_req_in_PU;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)WTSecondary(t,x,u,flag,par_INV);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_1127(1:1,1) = x(1:1);
x_1128(1:9,1) = x(2:10);
x_1129(1:3,1) = x(11:13);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        P_DC_in_PU = u{1};
        v_grid_mag_phase = u{2};
        Q_req_in_PU = u{3};
    elseif isa(u,'struct')
        P_DC_in_PU = u.P_DC_in_PU;
        v_grid_mag_phase = u.v_grid_mag_phase;
        Q_req_in_PU = u.Q_req_in_PU;
    else
        P_DC_in_PU = zeros([1 1]);  P_DC_in_PU(:) = u(1:1);
        v_grid_mag_phase = zeros([2 1]);  v_grid_mag_phase(:) = u(2:3);
        Q_req_in_PU = zeros([1 1]);  Q_req_in_PU(:) = u(4:4);
    end
end


% Constant Block 1141 "PU Current"
y_1141 = 1234.5679;
u_1110_2 = y_1141;            % Divide4         <-- PU Current      
u_1150_1 = v_grid_mag_phase;  % S-Function1     <-- v_grid_mag_phase 

% Constant Block 1145 "PU Voltage"
y_1145 = 2700;
u_1147_2 = y_1145;            % Product1        <-- PU Voltage      

% Constant Block 1143 "PU Power"
y_1143 = 5000000;
u_1149_2 = y_1143;            % Product3        <-- PU Power        
u_1148_2 = y_1143;            % Product2        <-- PU Power        
u_1148_1 = P_DC_in_PU;        % Product2        <-- P_DC_in_PU      

% Constant Block 1144 "PU Power1"
y_1144 = 5000000;
u_1108_2 = y_1144;            % Divide2         <-- PU Power1       
u_1107_2 = y_1144;            % Divide1         <-- PU Power1       

% Constant Block 1146 "PU Voltage1"
y_1146 = 2700;
u_1109_2 = y_1146;            % Divide3         <-- PU Voltage1     
u_1149_1 = Q_req_in_PU;       % Product3        <-- Q_req_in_PU     

% Constant Block 1142 "PU Current1"
y_1142 = 5400;
u_1111_2 = y_1142;            % Divide5         <-- PU Current1     

% S-Function Block 1150 "S-Function1"
y_1150 = modl_magphi2vabc(t,[],u_1150_1,3,p_1150);

u_1147_1 = y_1150;            % Product1        <-- S-Function1     

% Product Block 1149 "Product3"
y_1149 =u_1149_1 .* u_1149_2;

u_1124_5 = y_1149;            % Mux2            <-- Product3        

% Product Block 1147 "Product1"
y_1147 =u_1147_1 .* u_1147_2;

u_1206_1 = y_1147;            % Mux3            <-- Product1        
u_1122_2 = y_1147;            % Mux             <-- Product1        
u_1124_3 = y_1147;            % Mux2            <-- Product1        

% Product Block 1148 "Product2"
y_1148 =u_1148_1 .* u_1148_2;

u_1123_1 = y_1148;            % Mux1            <-- Product2        
u_1124_1 = y_1148;            % Mux2            <-- Product2        

% S-Function Block 1129 "S-Function6"
y_1129 = modl_filter(t,x_1129,[],3,p_1129);

u_1110_1 = y_1129;            % Divide4         <-- S-Function6     
u_1206_2 = y_1129;            % Mux3            <-- S-Function6     
u_1124_4 = y_1129;            % Mux2            <-- S-Function6     

% Product Block 1110 "Divide4"
y_1110 = u_1110_1./ u_1110_2 ;

u_1152_1 = y_1110;            % S-Function3     <-- Divide4         

% S-Function Block 1152 "S-Function3"
y_1152 = modl_vabc2magphi(t,[],u_1152_1,3);

iF_mag_phase = y_1152;        % iF_mag_phase    <-- S-Function3     

% Mux Block 1206 "Mux3"
y_1206 = [u_1206_1;u_1206_2];

u_1204_1 = y_1206;            % S-Function      <-- Mux3            

% S-Function Block 1204 "S-Function"
y_1204 = modl_3phase_power(t,[],u_1204_1,3);

u_1203_1 = y_1204;            % Demux           <-- S-Function      

% Demux Block 1203 "Demux"
y_1203_1 = u_1203_1(1);
y_1203_2 = u_1203_1(2);

u_1108_1 = y_1203_2;          % Divide2         <-- Demux           

% Product Block 1108 "Divide2"
y_1108 = u_1108_1./ u_1108_2 ;

Q_grid_in_PU = y_1108;        % Q_grid_in_PU    <-- Divide2         
u_1107_1 = y_1203_1;          % Divide1         <-- Demux           
u_1119_1 = y_1203_1;          % Gain1           <-- Demux           

% Product Block 1107 "Divide1"
y_1107 = u_1107_1./ u_1107_2 ;

P_grid_in_PU = y_1107;        % P_grid_in_PU    <-- Divide1         

% S-Function Block 1127 "S-Function4"
y_1127 = sfun_capacitor(t,x_1127,[],3,p_1127);

u_1111_1 = y_1127;            % Divide5         <-- S-Function4     
u_1124_2 = y_1127;            % Mux2            <-- S-Function4     

% Product Block 1111 "Divide5"
y_1111 = u_1111_1./ u_1111_2 ;

v_DC_in_PU = y_1111;          % v_DC_in_PU      <-- Divide5         

% Mux Block 1124 "Mux2"
y_1124 = [u_1124_1;u_1124_2;u_1124_3;u_1124_4;u_1124_5];

u_1128_1 = y_1124;            % S-Function5     <-- Mux2            

% S-Function Block 1128 "S-Function5"
y_1128 = sFunc_converter(t,x_1128,u_1128_1,3,p_1128);

u_1135_1 = y_1128;            % states          <-- S-Function5     
u_1134_1 = y_1128;            % omega PLL in PU <-- S-Function5     
u_1131_1 = y_1128;            % V abc           <-- S-Function5     

% Selector Block 1135 "states"
y_1135 = u_1135_1([1 2 3 4 5 6 7 8 9]);



% Selector Block 1134 "omega PLL in PU"
y_1134 = u_1134_1(10);



% Selector Block 1131 "V abc "
y_1131 = u_1131_1([11 12 13]);


u_1109_1 = y_1131;            % Divide3         <-- V abc           
u_1122_1 = y_1131;            % Mux             <-- V abc           

% Product Block 1109 "Divide3"
y_1109 = u_1109_1./ u_1109_2 ;

u_1151_1 = y_1109;            % S-Function2     <-- Divide3         

% S-Function Block 1151 "S-Function2"
y_1151 = modl_vabc2magphi(t,[],u_1151_1,3);

v_mag_phase = y_1151;         % v_mag_phase     <-- S-Function2     

% Mux Block 1122 "Mux"
y_1122 = [u_1122_1;u_1122_2];

u_1129_1 = y_1122;            % S-Function6     <-- Mux             

% Gain Block 1119 "Gain1"
y_1119 = -1*u_1119_1;


u_1123_2 = y_1119;            % Mux1            <-- Gain1           

% Mux Block 1123 "Mux1"
y_1123 = [u_1123_1;u_1123_2];

u_1127_1 = y_1123;            % S-Function4     <-- Mux1            

% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(13,1);
        
        % S-Function derivative call of "S-Function4" (SID 1127)
        dx(1:1) = sfun_capacitor(t,x_1127,u_1127_1,1,p_1127);
        
        % S-Function derivative call of "S-Function5" (SID 1128)
        dx(2:10) = sFunc_converter(t,x_1128,u_1128_1,1,p_1128);
        
        % S-Function derivative call of "S-Function6" (SID 1129)
        dx(11:13) = modl_filter(t,x_1129,u_1129_1,1,p_1129);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = P_grid_in_PU;
            y{2} = Q_grid_in_PU;
            y{3} = iF_mag_phase;
            y{4} = v_mag_phase;
            y{5} = v_DC_in_PU;
        elseif flagout == 2
            y = struct();
            y.P_grid_in_PU = P_grid_in_PU;
            y.Q_grid_in_PU = Q_grid_in_PU;
            y.iF_mag_phase = iF_mag_phase;
            y.v_mag_phase = v_mag_phase;
            y.v_DC_in_PU = v_DC_in_PU;
        else
            y = [P_grid_in_PU(:);Q_grid_in_PU(:);iF_mag_phase(:);v_mag_phase(:);v_DC_in_PU(:);];
        end
        sys = y;
end

end % end of WTSecondary
