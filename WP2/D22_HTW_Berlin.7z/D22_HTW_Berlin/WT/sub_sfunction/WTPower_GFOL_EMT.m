%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = WTPower(t,x,u,flag,par_INV,par_WT)

% BlockInfo, SysHandle (~) = Model.System.Block_44
%  SID  BlockHandle             BlockType               BlockName
%  851  ~.System.Block_24       Mux                     Mux
%  852  ~.System.Block_46       S-Function              S-Function
%  854  ~.System.Block_23       Sum                     Minus
%  855  ~.System.Block_6        Constant                Constant
%  856  ~.System.Block_44       Product                 Product3
%  857  ~.System.Block_7        Constant                Constant1
%  862  ~.System.Block_9        Demux                   Demux
%  864  ~.System.Block_41       Scope                   Pitch angle
%  865  ~.System.Block_60       Scope                   generator torque
%  866  ~.System.Block_65       Scope                   tower movement
%  867  ~.System.Block_25       Mux                     Mux1
%  868  ~.System.Block_26       Mux                     Mux2
%  869  ~.System.Block_4        Scope                   Blade out of Plane Movement
%  870  ~.System.Block_27       Mux                     Mux3
%  871  ~.System.Block_16       Scope                   Drive Train States
%  872  ~.System.Block_28       Mux                     Mux4
%  873  ~.System.Block_33       Scope                   Observer States
%  874  ~.System.Block_54       Scope                   Scope power WT
%  875  ~.System.Block_55       Scope                   Scope req Power in PU
%  876  ~.System.Block_56       Scope                   Scope windspeed
% 1107  ~.System.Block_11       Product                 Divide1
% 1108  ~.System.Block_12       Product                 Divide2
% 1109  ~.System.Block_13       Product                 Divide3
% 1110  ~.System.Block_14       Product                 Divide4
% 1111  ~.System.Block_15       Product                 Divide5
% 1112  ~.System.Block_19       Scope                   INV_P_grid / INV_Q_grid / Q_GRID
% 1113  ~.System.Block_20       Scope                   INV_i_filter
% 1114  ~.System.Block_22       Scope                   INV_v_grid_abc
% 1119  ~.System.Block_17       Gain                    Gain1
% 1120  ~.System.Block_18       Scope                   I filter abc
% 1121  ~.System.Block_21       Scope                   INV_omega_PLL
% 1122  ~.System.Block_29       Mux                     Mux5
% 1123  ~.System.Block_30       Mux                     Mux6
% 1124  ~.System.Block_31       Mux                     Mux7
% 1125  ~.System.Block_40       Scope                   P_grid / Q_grod
% 1127  ~.System.Block_50       S-Function              S-Function4
% 1128  ~.System.Block_51       S-Function              S-Function5
% 1129  ~.System.Block_52       S-Function              S-Function6
% 1130  ~.System.Block_58       Terminator              Terminator
% 1131  ~.System.Block_59       Selector                V abc 
% 1132  ~.System.Block_61       Scope                   inv_v_DC
% 1133  ~.System.Block_62       Scope                   inv_v_terminal_abc
% 1134  ~.System.Block_63       Selector                omega PLL in PU
% 1135  ~.System.Block_64       Selector                states
% 1141  ~.System.Block_34       Constant                PU Current
% 1142  ~.System.Block_35       Constant                PU Current1
% 1143  ~.System.Block_36       Constant                PU Power
% 1144  ~.System.Block_37       Constant                PU Power1
% 1145  ~.System.Block_38       Constant                PU Voltage
% 1146  ~.System.Block_39       Constant                PU Voltage1
% 1147  ~.System.Block_42       Product                 Product1
% 1148  ~.System.Block_43       Product                 Product2
% 1149  ~.System.Block_45       Product                 Product4
% 1150  ~.System.Block_47       S-Function              S-Function1
% 1151  ~.System.Block_48       S-Function              S-Function2
% 1152  ~.System.Block_49       S-Function              S-Function3
% 1180  ~                       SubSystem               WT Power
% 1181  ~.System.Block          Inport                  v_in_PU
% 1183  ~.System.Block_1        Inport                  P_req_in_PU
% 1184  ~.System.Block_3        Inport                  v_grid_mag_phase
% 1185  ~.System.Block_2        Inport                  Q_req_in_PU
% 1186  ~.System.Block_67       Outport                 v_DC_in_PU
% 1187  ~.System.Block_68       Outport                 P_grid_in_PU
% 1188  ~.System.Block_66       Outport                 power_WT
% 1189  ~.System.Block_69       Outport                 Q_grid_in_PU
% 1190  ~.System.Block_70       Outport                 iF_mag_phase
% 1191  ~.System.Block_71       Outport                 v_mag_phase
% 1203  ~.System.Block_10       Demux                   Demux1
% 1204  ~.System.Block_53       S-Function              S-Function7
% 1206  ~.System.Block_32       Mux                     Mux8
% 1207  ~.System.Block_57       Switch                  Switch7
% 1208  ~.System.Block_8        Constant                Constant2
% 1209  ~.System.Block_5        Clock                   Clock

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_852 = par_WT;
p_1150 = 1.5707963267949;
p_1127 = par_INV;
p_1128 = par_INV;
p_1129 = par_INV;

% Initialisation
if flag == 0
    x0 = zeros(26,1);
    [~,x0_temp] = sFunc_WTmdl([],[],[],0,p_852);
    x0(1:13) = x0_temp(1:13);
    [~,x0_temp] = sfun_capacitor([],[],[],0,p_1127);
    x0(14:14) = x0_temp(1:1);
    [~,x0_temp] = sFunc_converter([],[],[],0,p_1128);
    x0(15:23) = x0_temp(1:9);
    [~,x0_temp] = modl_filter([],[],[],0,p_1129);
    x0(24:26) = x0_temp(1:3);
    sys = [26 ,... % NumContStates
           0 ,... % NumDiscStates
           8 ,... % NumOutputs
           5 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 4;
    info.InportsVarName{1} = 'v_in_PU'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'P_req_in_PU'; info.InportsDimension{2} = [1 1];
    info.InportsVarName{3} = 'Q_req_in_PU'; info.InportsDimension{3} = [1 1];
    info.InportsVarName{4} = 'v_grid_mag_phase'; info.InportsDimension{4} = [2 1];
    info.NumOutports = 6;
    info.OutportsVarName{1} = 'power_WT'; info.OutportsDimension{1} = [1 1];
    info.OutportsVarName{2} = 'v_DC_in_PU'; info.OutportsDimension{2} = [1 1];
    info.OutportsVarName{3} = 'P_grid_in_PU'; info.OutportsDimension{3} = [1 1];
    info.OutportsVarName{4} = 'Q_grid_in_PU'; info.OutportsDimension{4} = [1 1];
    info.OutportsVarName{5} = 'iF_mag_phase'; info.OutportsDimension{5} = [1 2];
    info.OutportsVarName{6} = 'v_mag_phase'; info.OutportsDimension{6} = [1 2];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:2,1) = u{2};
        u0(3:3,1) = u{3};
        u0(4:5,1) = u{4};
    elseif isa(u,'struct')
        u0(1:1,1) = u.v_in_PU;
        u0(2:2,1) = u.P_req_in_PU;
        u0(3:3,1) = u.Q_req_in_PU;
        u0(4:5,1) = u.v_grid_mag_phase;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)WTPower(t,x,u,flag,par_INV,par_WT);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_852(1:13,1) = x(1:13);
x_1127(1:1,1) = x(14:14);
x_1128(1:9,1) = x(15:23);
x_1129(1:3,1) = x(24:26);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        v_in_PU = u{1};
        P_req_in_PU = u{2};
        Q_req_in_PU = u{3};
        v_grid_mag_phase = u{4};
    elseif isa(u,'struct')
        v_in_PU = u.v_in_PU;
        P_req_in_PU = u.P_req_in_PU;
        Q_req_in_PU = u.Q_req_in_PU;
        v_grid_mag_phase = u.v_grid_mag_phase;
    else
        v_in_PU = zeros([1 1]);  v_in_PU(:) = u(1:1);
        P_req_in_PU = zeros([1 1]);  P_req_in_PU(:) = u(2:2);
        Q_req_in_PU = zeros([1 1]);  Q_req_in_PU(:) = u(3:3);
        v_grid_mag_phase = zeros([2 1]);  v_grid_mag_phase(:) = u(4:5);
    end
end


% S-Function Block 852 "S-Function"
y_852 = sFunc_WTmdl(t,x_852,[],3,p_852);

u_862_1 = y_852;              % Demux           <-- S-Function      

% Demux Block 862 "Demux"
y_862_1 = u_862_1(1);
y_862_2 = u_862_1(2);
y_862_3 = u_862_1(3);
y_862_4 = u_862_1(4);
y_862_5 = u_862_1(5);
y_862_6 = u_862_1(6);
y_862_7 = u_862_1(7);
y_862_8 = u_862_1(8);
y_862_9 = u_862_1(9);
y_862_10 = u_862_1(10);
y_862_11 = u_862_1(11);
y_862_12 = u_862_1(12);
y_862_13 = u_862_1(13);
y_862_14 = u_862_1(14);

u_872_2 = y_862_14;           % Mux4            <-- Demux           
u_872_1 = y_862_13;           % Mux4            <-- Demux           

% Mux Block 872 "Mux4"
y_872 = [u_872_1;u_872_2];

u_870_3 = y_862_12;           % Mux3            <-- Demux           
u_870_2 = y_862_11;           % Mux3            <-- Demux           
u_870_1 = y_862_10;           % Mux3            <-- Demux           

% Mux Block 870 "Mux3"
y_870 = [u_870_1;u_870_2;u_870_3];

u_868_2 = y_862_9;            % Mux2            <-- Demux           
u_868_1 = y_862_8;            % Mux2            <-- Demux           

% Mux Block 868 "Mux2"
y_868 = [u_868_1;u_868_2];

u_867_4 = y_862_7;            % Mux1            <-- Demux           
u_867_3 = y_862_6;            % Mux1            <-- Demux           
u_867_1 = y_862_4;            % Mux1            <-- Demux           
u_867_2 = y_862_5;            % Mux1            <-- Demux           

% Mux Block 867 "Mux1"
y_867 = [u_867_1;u_867_2;u_867_3;u_867_4];

u_1207_1 = y_862_1;           % Switch7         <-- Demux           
power_WT = y_862_1;           % power_WT        <-- Demux           

% Constant Block 855 "Constant"
y_855 = 1;
u_854_1 = y_855;              % Minus           <-- Constant        
u_854_2 = P_req_in_PU;        % Minus           <-- P_req_in_PU     

% Constant Block 857 "Constant1"
y_857 = 11.6;
u_856_2 = y_857;              % Product3        <-- Constant1       
u_856_1 = v_in_PU;            % Product3        <-- v_in_PU         

% Sum Block 854 "Minus"
y_854 = + u_854_1 - u_854_2;

u_851_1 = y_854;              % Mux             <-- Minus           

% Product Block 856 "Product3"
y_856 =u_856_1 .* u_856_2;

u_851_2 = y_856;              % Mux             <-- Product3        

% Mux Block 851 "Mux"
y_851 = [u_851_1;u_851_2];

u_852_1 = y_851;              % S-Function      <-- Mux             

% S-Function Block 1127 "S-Function4"
y_1127 = sfun_capacitor(t,x_1127,[],3,p_1127);

u_1111_1 = y_1127;            % Divide5         <-- S-Function4     
u_1124_2 = y_1127;            % Mux7            <-- S-Function4     

% S-Function Block 1129 "S-Function6"
y_1129 = modl_filter(t,x_1129,[],3,p_1129);

u_1110_1 = y_1129;            % Divide4         <-- S-Function6     
u_1206_2 = y_1129;            % Mux8            <-- S-Function6     
u_1124_4 = y_1129;            % Mux7            <-- S-Function6     

% Constant Block 1142 "PU Current1"
y_1142 = 5400;
u_1111_2 = y_1142;            % Divide5         <-- PU Current1     

% Product Block 1111 "Divide5"
y_1111 = u_1111_1./ u_1111_2 ;

v_DC_in_PU = y_1111;          % v_DC_in_PU      <-- Divide5         
u_1149_1 = Q_req_in_PU;       % Product4        <-- Q_req_in_PU     

% Constant Block 1146 "PU Voltage1"
y_1146 = 2700;
u_1109_2 = y_1146;            % Divide3         <-- PU Voltage1     

% Constant Block 1144 "PU Power1"
y_1144 = 5000000;
u_1108_2 = y_1144;            % Divide2         <-- PU Power1       
u_1107_2 = y_1144;            % Divide1         <-- PU Power1       

% Constant Block 1143 "PU Power"
y_1143 = 5000000;
u_1149_2 = y_1143;            % Product4        <-- PU Power        
u_1148_2 = y_1143;            % Product2        <-- PU Power        

% Product Block 1149 "Product4"
y_1149 =u_1149_1 .* u_1149_2;

u_1124_5 = y_1149;            % Mux7            <-- Product4        

% Constant Block 1145 "PU Voltage"
y_1145 = 2700;
u_1147_2 = y_1145;            % Product1        <-- PU Voltage      
u_1150_1 = v_grid_mag_phase;  % S-Function1     <-- v_grid_mag_phase 

% S-Function Block 1150 "S-Function1"
y_1150 = modl_magphi2vabc(t,[],u_1150_1,3,p_1150);

u_1147_1 = y_1150;            % Product1        <-- S-Function1     

% Product Block 1147 "Product1"
y_1147 =u_1147_1 .* u_1147_2;

u_1206_1 = y_1147;            % Mux8            <-- Product1        
u_1122_2 = y_1147;            % Mux5            <-- Product1        
u_1124_3 = y_1147;            % Mux7            <-- Product1        

% Mux Block 1206 "Mux8"
y_1206 = [u_1206_1;u_1206_2];

u_1204_1 = y_1206;            % S-Function7     <-- Mux8            

% S-Function Block 1204 "S-Function7"
y_1204 = modl_3phase_power(t,[],u_1204_1,3);

u_1203_1 = y_1204;            % Demux1          <-- S-Function7     

% Demux Block 1203 "Demux1"
y_1203_1 = u_1203_1(1);
y_1203_2 = u_1203_1(2);

u_1107_1 = y_1203_1;          % Divide1         <-- Demux1          
u_1119_1 = y_1203_1;          % Gain1           <-- Demux1          

% Gain Block 1119 "Gain1"
y_1119 = -1*u_1119_1;


u_1123_2 = y_1119;            % Mux6            <-- Gain1           
u_1108_1 = y_1203_2;          % Divide2         <-- Demux1          

% Product Block 1108 "Divide2"
y_1108 = u_1108_1./ u_1108_2 ;

Q_grid_in_PU = y_1108;        % Q_grid_in_PU    <-- Divide2         

% Product Block 1107 "Divide1"
y_1107 = u_1107_1./ u_1107_2 ;

P_grid_in_PU = y_1107;        % P_grid_in_PU    <-- Divide1         

% Constant Block 1141 "PU Current"
y_1141 = 1234.5679;
u_1110_2 = y_1141;            % Divide4         <-- PU Current      

% Product Block 1110 "Divide4"
y_1110 = u_1110_1./ u_1110_2 ;

u_1152_1 = y_1110;            % S-Function3     <-- Divide4         

% S-Function Block 1152 "S-Function3"
y_1152 = modl_vabc2magphi(t,[],u_1152_1,3);

iF_mag_phase = y_1152;        % iF_mag_phase    <-- S-Function3     

% Constant Block 1208 "Constant2"
y_1208 = 0.5;
u_1207_3 = y_1208;            % Switch7         <-- Constant2       

% Clock Block 1209 "Clock"
y_1209 = t;

u_1207_2 = y_1209;            % Switch7         <-- Clock           

% Switch Block 1207 "Switch7"
if u_1207_2 > 0.1
    y_1207 = u_1207_1;
else
    y_1207 = u_1207_3;
end

u_1148_1 = y_1207;            % Product2        <-- Switch7         

% Product Block 1148 "Product2"
y_1148 =u_1148_1 .* u_1148_2;

u_1123_1 = y_1148;            % Mux6            <-- Product2        
u_1124_1 = y_1148;            % Mux7            <-- Product2        

% Mux Block 1123 "Mux6"
y_1123 = [u_1123_1;u_1123_2];

u_1127_1 = y_1123;            % S-Function4     <-- Mux6            

% Mux Block 1124 "Mux7"
y_1124 = [u_1124_1;u_1124_2;u_1124_3;u_1124_4;u_1124_5];

u_1128_1 = y_1124;            % S-Function5     <-- Mux7            

% S-Function Block 1128 "S-Function5"
y_1128 = sFunc_converter(t,x_1128,u_1128_1,3,p_1128);

u_1135_1 = y_1128;            % states          <-- S-Function5     
u_1134_1 = y_1128;            % omega PLL in PU <-- S-Function5     
u_1131_1 = y_1128;            % V abc           <-- S-Function5     

% Selector Block 1131 "V abc "
y_1131 = u_1131_1([11 12 13]);


u_1109_1 = y_1131;            % Divide3         <-- V abc           
u_1122_1 = y_1131;            % Mux5            <-- V abc           

% Selector Block 1134 "omega PLL in PU"
y_1134 = u_1134_1(10);



% Selector Block 1135 "states"
y_1135 = u_1135_1([1 2 3 4 5 6 7 8 9]);



% Mux Block 1122 "Mux5"
y_1122 = [u_1122_1;u_1122_2];

u_1129_1 = y_1122;            % S-Function6     <-- Mux5            

% Product Block 1109 "Divide3"
y_1109 = u_1109_1./ u_1109_2 ;

u_1151_1 = y_1109;            % S-Function2     <-- Divide3         

% S-Function Block 1151 "S-Function2"
y_1151 = modl_vabc2magphi(t,[],u_1151_1,3);

v_mag_phase = y_1151;         % v_mag_phase     <-- S-Function2     

% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(26,1);
        
        % S-Function derivative call of "S-Function" (SID 852)
        dx(1:13) = sFunc_WTmdl(t,x_852,u_852_1,1,p_852);
        
        % S-Function derivative call of "S-Function4" (SID 1127)
        dx(14:14) = sfun_capacitor(t,x_1127,u_1127_1,1,p_1127);
        
        % S-Function derivative call of "S-Function5" (SID 1128)
        dx(15:23) = sFunc_converter(t,x_1128,u_1128_1,1,p_1128);
        
        % S-Function derivative call of "S-Function6" (SID 1129)
        dx(24:26) = modl_filter(t,x_1129,u_1129_1,1,p_1129);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = power_WT;
            y{2} = v_DC_in_PU;
            y{3} = P_grid_in_PU;
            y{4} = Q_grid_in_PU;
            y{5} = iF_mag_phase;
            y{6} = v_mag_phase;
        elseif flagout == 2
            y = struct();
            y.power_WT = power_WT;
            y.v_DC_in_PU = v_DC_in_PU;
            y.P_grid_in_PU = P_grid_in_PU;
            y.Q_grid_in_PU = Q_grid_in_PU;
            y.iF_mag_phase = iF_mag_phase;
            y.v_mag_phase = v_mag_phase;
        else
            y = [power_WT(:);v_DC_in_PU(:);P_grid_in_PU(:);Q_grid_in_PU(:);iF_mag_phase(:);v_mag_phase(:);];
        end
        sys = y;
end

end % end of WTPower
