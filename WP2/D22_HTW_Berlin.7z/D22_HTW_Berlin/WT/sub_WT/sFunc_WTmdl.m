function [sys,x0,info,ts] = sFunc_WTmdl(~,x,u,flag,par)



% different tasks
switch flag
    case 0 % initialization
        [sys,x0,info,ts] = mdlInitialize(par);
    case 1 % calculate derivatives
        sys = mdlDerivatives([],x,u,par);
    case 3 % calculate outputs
        sys = mdlOutputs([],x,par);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

end

%==========================================================================
% mdlDerivatives
% Return the derivatives for the continuous states
%==========================================================================
function dx = mdlDerivatives(~,x,u,par)

P_req_rel = u(1);
windspeed = u(2);

xu = x(1:2); % states for the actuator
x = x(3:end); 

%P_req_rel = convert_P_req_to_rel(P_req_abs,0,x,par);

% define premise variable
switch par.WTversion
    case {0,5}
        % premise vector  [OS ,v , dp]
        z = [par.OS windspeed P_req_rel];
    case {1,2,3,4}
        % premise vector  [v , dp]
        z = [windspeed P_req_rel];
end

% calculate membership functions
hi = calc_TriangMemFcn([z(2) z(3)],par.TSmdl.LinPoints); % with true wind from data
switch par.WTversion
    case 5
        z(2) = x(end);
    otherwise 
        z(1) = x(end);
end
hk = calc_TriangMemFcn(z,par.TSmdl.LinPoints_c);
hl = hk;

indi = find(hi>0)';
indk = find(hk>0)';
indl = find(hl>0)';

u = zeros(size(par.TSmdl.LTI(1).u0));

% calculate derivatives
dx = zeros(size(x)); % states + recons. states + augmented wind state v
n = length(par.TSmdl.LTI(1).x0);
for k = indk
    if par.WTversion == 2 || par.WTversion == 3 || par.WTversion == 4 || par.WTversion == 5
        Kk = par.TSmdl.LTI_c(k).K;x0k = par.TSmdl.LTI_c(k).x0(1);u0k = par.TSmdl.LTI_c(k).u0;
    else
        Kk = par.TSmdl.LTI(k).K;x0k = par.TSmdl.LTI(k).x0;u0k = par.TSmdl.LTI(k).u0;
    end
    u = u + hk(k)*(-Kk*(x(n+1:end-1)-x0k)+u0k);
    if u(1) < 0
        u(1) = 0;
    end
end

% calculate actuator dyn
dxu = zeros(2,1); 
dxu(1) = -1/.1*xu(1) + 1/.1*u(1); 
dxu(2) = -50*xu(2) + 50*u(2); 

% write current actuator state to input
u = xu; 

for i = indi
    Ai = par.TSmdl.LTI(i).A; Bi = par.TSmdl.LTI(i).B; x0i = par.TSmdl.LTI(i).x0;
    u0i = par.TSmdl.LTI(i).u0; Bdi = par.TSmdl.LTI(i).Bd; d0i = par.TSmdl.LTI(i).d0;
    dx(1:n) = dx(1:n) + hi(i)*( Ai*(x(1:n)-x0i) + Bi*(u-u0i) + Bdi*(windspeed-d0i));
end

e = [x(n-2);windspeed]-x(n+1:end); % x(n-2)=rotational speed

for l = indl
    Aol = par.TSmdl.LTI_c(l).A;Bol = par.TSmdl.LTI_c(l).B;Lol = par.TSmdl.LTI_c(l).L;
    Co = par.TSmdl.LTI_c(l).C;xo0l = par.TSmdl.LTI_c(l).x0;u0l = par.TSmdl.LTI_c(l).u0;
    
    dx(n+1:end) = dx(n+1:end) + ...
        hl(l)*( Aol*(x(n+1:end)-xo0l) + Bol*(u-u0l) + Lol*Co*e);
end

dx = [dxu ; dx]; 

end

%==========================================================================
% mdlOutputs
% Return the block outputs
%==========================================================================
function y = mdlOutputs(~,x,par)

xu = x(1:2); 
x = x(3:end); 

pmax_global = par.TSmdl.LTI(end-numel(par.TSmdl.deltaP)+1).u0(2)*par.TSmdl.LTI(end-numel(par.TSmdl.deltaP)+1).x0(8);
P_sub_abs = x(8)*xu(2)/pmax_global;

y = [ P_sub_abs ; xu; x]';

end

%==========================================================================
% mdlInitialize
% Return the sizes, initial conditions, and sample times for the S-function
%==========================================================================
function [sys,x0,info,ts] = mdlInitialize(par)
sizes = simsizes;
sizes.NumContStates  = size(par.Init.x0,1)+2; % + 2 actuator states
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1 + size(par.Init.x0,1) + 2; % power + states + observer
sizes.NumInputs      = 2; % total number of in numeric values
sizes.DirFeedthrough = 0; % direct feedthrough since D is not 0
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0  = [par.Init.xu0 ; par.Init.x0];
ts  = [0 0];

info = [];

% information about the inports/outports (not inputs/outputs, see above)
% since simulink sticks to the vector format, info is not used in simulink
% info.NumInports = 2;
% info.InportsVarName{1} = 'P_req_abs'; info.InportsDimension{1} = [1 1];
% info.InportsVarName{2} = 'windspeed'; info.InportsDimension{5} = [1 1];
% 
% info.NumOutports = 2;
% info.OutportsVarName{1} = 'P_sub_abs'; info.OutportsDimension{1} = [1 1];
% info.OutportsVarName{2} = 'aux'; info.OutportsDimension{2} = [1 1];
end


% calculate relative power ref. given either absolute ref. or relative ref.
% relative ref. is prioritized in case of conflicting references
function [dP_rel] = convert_P_req_to_rel(P_req_abs,P_req_rel,x,par)
if P_req_rel > 0
    dP_rel = P_req_rel;
    return
elseif P_req_abs < 1 && P_req_abs > 0
    
    pmax_global = par.TSmdl.LTI(end-numel(par.TSmdl.deltaP)+1).u0(2)*par.TSmdl.LTI(end-numel(par.TSmdl.deltaP)+1).x0(8);
    vest = x(end); % estimated wind speed
    
    if vest < par.TSmdl.v(1)
        vest = par.TSmdl.v(1);
    elseif vest > par.TSmdl.v(end)
        vest = par.TSmdl.v(end)-diff(par.TSmdl.v(end-1:end))/10;
    end
    
    [~,ind] = min(abs(par.TSmdl.v-vest));
    w = zeros(2,1);
    if par.TSmdl.v(ind)>vest
        ind = [ind-1 ind];
    else
        ind = [ind ind+1];
    end
    % triangular mem functions
    w(2) = ( vest-par.TSmdl.v(ind(1)) )/( par.TSmdl.v(ind(2))-par.TSmdl.v(ind(1)) );
    w(1) = 1 - w(2);
    
    indmdl = (ind-1)*length(par.TSmdl.deltaP)+1;
    
    % calculate max power at current operating point
    
    pmax_op = w(1)*( par.TSmdl.LTI(indmdl(1)).x0(8)*par.TSmdl.LTI(indmdl(1)).u0(2) ) ...
        +w(2)*( par.TSmdl.LTI(indmdl(2)).x0(8)*par.TSmdl.LTI(indmdl(2)).u0(2) );
    % normalize value
    pmax_op = pmax_op/pmax_global;
    
    dP_rel = 1-(P_req_abs/pmax_op);
    
else
    dP_rel = 0;
end
end