function[h] = calc_TriangMemFcn(z,LinPoints)
dim_z = length(z);

% calculate weighting functions
w = cell(1,dim_z);
for idim = 1 : dim_z
    lps = LinPoints{idim};
    w{idim} = zeros(length(LinPoints{idim}),1);
    if z(idim) <= LinPoints{idim}(1)
        w{idim}(1) = 1;
    else
        for iLP = 2 : length(LinPoints{idim})
            if z(idim) < LinPoints{idim}(iLP)
                w{idim}(iLP-1) = 1-(z(idim)-LinPoints{idim}(iLP-1))/(LinPoints{idim}(iLP)-LinPoints{idim}(iLP-1));
                w{idim}(iLP) = (z(idim)-LinPoints{idim}(iLP-1))/(LinPoints{idim}(iLP)-LinPoints{idim}(iLP-1));
                break
            end
            if z(idim) >= lps(length(LinPoints{idim}))
                w{idim}(length(LinPoints{idim})) = 1;
            end
        end
    end
end

% calculate membership functions iteratively
for idim = 1 : dim_z
    if idim == 1
        h = w{idim};
    else
        h = h*w{idim}';
        h = h';
        h = h(:);
    end
end

end

