function plot_testcase()

[file,path] = uigetfile('results\*.mat');
if isequal(file,0)
    disp('User selected Cancel');
    return
else
    str = fullfile(path,file);
    disp(['User selected ', str]);
    S = load(str); res = S.res;
end

close all;

% Plot all
pmax = numel(get(res.logsout));
m = 3;
n = 5;
c = 0;
for i2 = 1:ceil(pmax/m/n)
    figure('name',str);
    sgtitle(['Overview: page ' num2str(i2) ' of ' num2str(ceil(pmax/m/n))] );
    for i1 = 1:m*n
        c = c + 1;
        if c > pmax, break, end
        subplot(m,n,i1);
        t = res.logsout{c}.Values.Time;
        y = res.logsout{c}.Values.Data;
        s = res.logsout{c}.Name;
        plot(t,y);
        title(s,'interpreter','none');
    end
end

% plot selected
figure('name',str);
choosen = {'INV_P_grid','WT_P_req','WT_power'};
leg = {};
for i1 = 1:pmax
    s = res.logsout{i1}.Name;
    if any(strcmp(s,choosen))
        t = res.logsout{i1}.Values.Time;
        y = res.logsout{i1}.Values.Data;
        leg{end+1} = s;
        plot(t,y);
        hold on;
    end
end
legend(leg,'interpreter','none');
title('active power','interpreter','none');

% plot selected
figure('name',str);
choosen = {'INV_Q_grid','INV_Q_req'};
leg = {};
for i1 = 1:pmax
    s = res.logsout{i1}.Name;
    if any(strcmp(s,choosen))
        t = res.logsout{i1}.Values.Time;
        y = res.logsout{i1}.Values.Data;
        leg{end+1} = s;
        plot(t,y);
        hold on;
    end
end
legend(leg,'interpreter','none');
title('reactive power','interpreter','none');

% plot selected
figure('name',str);
choosen = {'inv_v_DC'};
leg = {};
for i1 = 1:pmax
    s = res.logsout{i1}.Name;
    if any(strcmp(s,choosen))
        t = res.logsout{i1}.Values.Time;
        y = res.logsout{i1}.Values.Data;
        leg{end+1} = s;
        plot(t,y);
        hold on;
    end
end
legend(leg,'interpreter','none');
title('direct link voltage','interpreter','none');

% plot selected
figure('name',str);
choosen = {'INV_omega_PLL',};
leg = {};
for i1 = 1:pmax
    s = res.logsout{i1}.Name;
    if any(strcmp(s,choosen))
        t = res.logsout{i1}.Values.Time;
        y = res.logsout{i1}.Values.Data;
        leg{end+1} = s;
        plot(t,y);
        hold on;
    end
end
legend(leg,'interpreter','none');
title('phase locked-loop signal','interpreter','none');



