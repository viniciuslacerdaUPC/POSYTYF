%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = HYSecondary(t,x,u,flag,par_SG)

% BlockInfo, SysHandle (~) = Model.System.Block_12
%  SID  BlockHandle             BlockType               BlockName
%  503  ~                       SubSystem               HY Secondary
%  504  ~.System.Block          Inport                  P_mech_in_PU
%  505  ~.System.Block_1        Inport                  Q_req_in_PU
%  506  ~.System.Block_2        Inport                  V_grid_mag_phi_PU
%  507  ~.System.Block_3        Sum                     Add1
%  508  ~.System.Block_4        Sum                     Add2
%  509  ~.System.Block_5        Constant                Constant
%  510  ~.System.Block_6        Demux                   Demux
%  511  ~.System.Block_7        Product                 Divide3
%  512  ~.System.Block_8        Gain                    Gain
%  513  ~.System.Block_9        Gain                    Gain1
%  514  ~.System.Block_10       Gain                    Gain2
%  515  ~.System.Block_11       Gain                    Gain3
%  516  ~.System.Block_12       Gain                    Gain4
%  517  ~.System.Block_13       S-Function              Integrator
%  518  ~.System.Block_14       S-Function              Integrator1
%  519  ~.System.Block_15       Mux                     Mux
%  520  ~.System.Block_16       Mux                     Mux1
%  521  ~.System.Block_17       Mux                     Mux2
%  522  ~.System.Block_18       Constant                PU Omega
%  523  ~.System.Block_19       S-Function              S-Fun Synchron Generator
%  524  ~.System.Block_20       S-Function              S-Function
%  525  ~.System.Block_21       S-Function              S-Function1
%  526  ~.System.Block_22       S-Function              S-Function2
%  527  ~.System.Block_23       S-Function              S-Function3
%  528  ~.System.Block_24       Scope                   SG P_mech\nSG P_grid\nSG Q_grid
%  529  ~.System.Block_25       Scope                   SG omega
%  530  ~.System.Block_26       Scope                   SG_P_grid
%  531  ~.System.Block_27       Scope                   Scope
%  532  ~.System.Block_28       Scope                   Scope Exciter Voltage
%  533  ~.System.Block_29       Scope                   Scope1
%  534  ~.System.Block_30       Selector                Selector
%  535  ~.System.Block_31       Sum                     Sum
%  536  ~.System.Block_32       Sum                     Sum1
%  537  ~.System.Block_33       S-Function              Transfer Fcn
%  538  ~.System.Block_34       Selector                electrical Power
%  539  ~.System.Block_35       Selector                electrical Power1
%  540  ~.System.Block_36       Selector                grid currents
%  541  ~.System.Block_37       Scope                   sg_Q_grid
%  542  ~.System.Block_38       Outport                 P_grid_in_PU
%  543  ~.System.Block_39       Outport                 Q_grid_in_PU
%  544  ~.System.Block_40       Outport                 I_mag_phase_in_PU
%  545  ~.System.Block_41       Outport                 omega_in_PU

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_517_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_517_2 = 1;
p_518_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_518_2 = 0;
p_523 = par_SG;
p_525 = 1.5707963267949;
p_537_1 = -0.1;
p_537_2 = 0.25;
p_537_3 = 0.28;
p_537_4 = 0.3;

% Initialisation
if flag == 0
    x0 = zeros(9,1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_517_1,p_517_2);
    x0(1:1) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_518_1,p_518_2);
    x0(2:2) = x0_temp(1:1);
    [~,x0_temp] = modl_SG([],[],[],0,p_523);
    x0(3:8) = x0_temp(1:6);
    [~,x0_temp] = tf_sfun([],[],[],0,p_537_1,p_537_2,p_537_3,p_537_4);
    x0(9:9) = x0_temp(1:1);
    sys = [9 ,... % NumContStates
           0 ,... % NumDiscStates
           5 ,... % NumOutputs
           4 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 3;
    info.InportsVarName{1} = 'P_mech_in_PU'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'Q_req_in_PU'; info.InportsDimension{2} = [1 1];
    info.InportsVarName{3} = 'V_grid_mag_phi_PU'; info.InportsDimension{3} = [2 1];
    info.NumOutports = 4;
    info.OutportsVarName{1} = 'P_grid_in_PU'; info.OutportsDimension{1} = [1 1];
    info.OutportsVarName{2} = 'Q_grid_in_PU'; info.OutportsDimension{2} = [1 1];
    info.OutportsVarName{3} = 'I_mag_phase_in_PU'; info.OutportsDimension{3} = [1 2];
    info.OutportsVarName{4} = 'omega_in_PU'; info.OutportsDimension{4} = [1 1];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:2,1) = u{2};
        u0(3:4,1) = u{3};
    elseif isa(u,'struct')
        u0(1:1,1) = u.P_mech_in_PU;
        u0(2:2,1) = u.Q_req_in_PU;
        u0(3:4,1) = u.V_grid_mag_phi_PU;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)HYSecondary(t,x,u,flag,par_SG);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_517(1:1,1) = x(1:1);
x_518(1:1,1) = x(2:2);
x_523(1:6,1) = x(3:8);
x_537(1:1,1) = x(9:9);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        P_mech_in_PU = u{1};
        Q_req_in_PU = u{2};
        V_grid_mag_phi_PU = u{3};
    elseif isa(u,'struct')
        P_mech_in_PU = u.P_mech_in_PU;
        Q_req_in_PU = u.Q_req_in_PU;
        V_grid_mag_phi_PU = u.V_grid_mag_phi_PU;
    else
        P_mech_in_PU = zeros([1 1]);  P_mech_in_PU(:) = u(1:1);
        Q_req_in_PU = zeros([1 1]);  Q_req_in_PU(:) = u(2:2);
        V_grid_mag_phi_PU = zeros([2 1]);  V_grid_mag_phi_PU(:) = u(3:4);
    end
end

u_507_2 = Q_req_in_PU;        % Add1            <-- Q_req_in_PU     

% Constant Block 522 "PU Omega"
y_522 = 314.1593;
u_511_2 = y_522;              % Divide3         <-- PU Omega        
u_520_1 = P_mech_in_PU;       % Mux1            <-- P_mech_in_PU    
u_525_1 = V_grid_mag_phi_PU;  % S-Function1     <-- V_grid_mag_phi_PU 

% S-Function Block 525 "S-Function1"
y_525 = modl_magphi2vabc(t,[],u_525_1,3,p_525);

u_521_1 = y_525;              % Mux2            <-- S-Function1     
u_520_2 = y_525;              % Mux1            <-- S-Function1     
u_519_1 = y_525;              % Mux             <-- S-Function1     

% S-Function Block 517 "Integrator"
y_517 = sfun_integrator(t,x_517,[],3,p_517_1,p_517_2);

u_508_2 = y_517;              % Add2            <-- Integrator      

% Constant Block 509 "Constant"
y_509 = 1;
u_536_2 = y_509;              % Sum1            <-- Constant        

% S-Function Block 518 "Integrator1"
y_518 = sfun_integrator(t,x_518,[],3,p_518_1,p_518_2);

u_515_1 = y_518;              % Gain3           <-- Integrator1     
u_536_1 = y_518;              % Sum1            <-- Integrator1     

% Sum Block 536 "Sum1"
y_536 = + u_536_1 + u_536_2;

u_520_3 = y_536;              % Mux1            <-- Sum1            

% Mux Block 520 "Mux1"
y_520 = [u_520_1;u_520_2;u_520_3];

u_523_1 = y_520;              % S-Fun Synchron Generator <-- Mux1            

% S-Function Block 523 "S-Fun Synchron Generator"
y_523 = modl_SG(t,x_523,u_523_1,3,p_523);

u_539_1 = y_523;              % electrical Power1 <-- S-Fun Synchron Generator 
u_538_1 = y_523;              % electrical Power <-- S-Fun Synchron Generator 
u_540_1 = y_523;              % grid currents   <-- S-Fun Synchron Generator 

% Selector Block 539 "electrical Power1"
y_539 = u_539_1([5 6 7 8 9 10]);


u_534_1 = y_539;              % Selector        <-- electrical Power1 

% Selector Block 540 "grid currents"
y_540 = u_540_1([1 2 3]);


u_521_2 = y_540;              % Mux2            <-- grid currents   
u_527_1 = y_540;              % S-Function3     <-- grid currents   

% Selector Block 534 "Selector"
y_534 = u_534_1(1);


u_511_1 = y_534;              % Divide3         <-- Selector        

% Product Block 511 "Divide3"
y_511 = u_511_1./ u_511_2 ;

omega_in_PU = y_511;          % omega_in_PU     <-- Divide3         

% Selector Block 538 "electrical Power"
y_538 = u_538_1(4);



% Gain Block 515 "Gain3"
y_515 = 0.5*u_515_1;


u_535_2 = y_515;              % Sum             <-- Gain3           

% Mux Block 521 "Mux2"
y_521 = [u_521_1;u_521_2];

u_526_1 = y_521;              % S-Function2     <-- Mux2            

% S-Function Block 526 "S-Function2"
y_526 = modl_3phase_power(t,[],u_526_1,3);

u_510_1 = y_526;              % Demux           <-- S-Function2     

% Demux Block 510 "Demux"
y_510_1 = u_510_1(1);
y_510_2 = u_510_1(2);

u_512_1 = y_510_2;            % Gain            <-- Demux           
Q_grid_in_PU = y_510_2;       % Q_grid_in_PU    <-- Demux           
P_grid_in_PU = y_510_1;       % P_grid_in_PU    <-- Demux           

% Gain Block 512 "Gain"
y_512 = 1*u_512_1;


u_507_1 = y_512;              % Add1            <-- Gain            

% Sum Block 507 "Add1"
y_507 = - u_507_1 + u_507_2;

u_513_1 = y_507;              % Gain1           <-- Add1            
u_514_1 = y_507;              % Gain2           <-- Add1            

% Gain Block 514 "Gain2"
y_514 = 0.5*u_514_1;


u_517_1 = y_514;              % Integrator      <-- Gain2           

% Gain Block 513 "Gain1"
y_513 = 2*u_513_1;


u_508_1 = y_513;              % Add2            <-- Gain1           

% Sum Block 508 "Add2"
y_508 = + u_508_1 + u_508_2;

u_519_2 = y_508;              % Mux             <-- Add2            

% Mux Block 519 "Mux"
y_519 = [u_519_1;u_519_2];

u_524_1 = y_519;              % S-Function      <-- Mux             

% S-Function Block 524 "S-Function"
y_524 = modl_sg_deltav(t,[],u_524_1,3);

u_537_1 = y_524;              % Transfer Fcn    <-- S-Function      

% S-Function Block 537 "Transfer Fcn"
y_537 = tf_sfun(t,x_537,u_537_1,3,p_537_1,p_537_2,p_537_3,p_537_4);

u_535_1 = y_537;              % Sum             <-- Transfer Fcn    

% Sum Block 535 "Sum"
y_535 = + u_535_1 - u_535_2;

u_516_1 = y_535;              % Gain4           <-- Sum             

% Gain Block 516 "Gain4"
y_516 = 40*u_516_1;


u_518_1 = y_516;              % Integrator1     <-- Gain4           

% S-Function Block 527 "S-Function3"
y_527 = modl_vabc2magphi(t,[],u_527_1,3);

I_mag_phase_in_PU = y_527;    % I_mag_phase_in_PU <-- S-Function3     

% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(9,1);
        
        % S-Function derivative call of "Integrator" (SID 517)
        dx(1:1) = sfun_integrator(t,x_517,u_517_1,1,p_517_1,p_517_2);
        
        % S-Function derivative call of "Integrator1" (SID 518)
        dx(2:2) = sfun_integrator(t,x_518,u_518_1,1,p_518_1,p_518_2);
        
        % S-Function derivative call of "S-Fun Synchron Generator" (SID 523)
        dx(3:8) = modl_SG(t,x_523,u_523_1,1,p_523);
        
        % S-Function derivative call of "Transfer Fcn" (SID 537)
        dx(9:9) = tf_sfun(t,x_537,u_537_1,1,p_537_1,p_537_2,p_537_3,p_537_4);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = P_grid_in_PU;
            y{2} = Q_grid_in_PU;
            y{3} = I_mag_phase_in_PU;
            y{4} = omega_in_PU;
        elseif flagout == 2
            y = struct();
            y.P_grid_in_PU = P_grid_in_PU;
            y.Q_grid_in_PU = Q_grid_in_PU;
            y.I_mag_phase_in_PU = I_mag_phase_in_PU;
            y.omega_in_PU = omega_in_PU;
        else
            y = [P_grid_in_PU(:);Q_grid_in_PU(:);I_mag_phase_in_PU(:);omega_in_PU(:);];
        end
        sys = y;
end

end % end of HYSecondary
