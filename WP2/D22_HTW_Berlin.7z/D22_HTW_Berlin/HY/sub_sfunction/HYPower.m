%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = HYPower(t,x,u,flag,par_SG)

% BlockInfo, SysHandle (~) = Model.System.Block_11
%  SID  BlockHandle             BlockType               BlockName
%   55  ~.System.Block_9        Product                 Divide
%   56  ~.System.Block_10       Product                 Divide1
%   57  ~.System.Block_17       Constant                H0
%   58  ~.System.Block_22       S-Function              Integrator
%   59  ~.System.Block_30       Product                 Product
%   60  ~.System.Block_31       Product                 Product1
%   61  ~.System.Block_51       Sum                     Sum5
%   62  ~.System.Block_47       Sum                     Sum1
%   63  ~.System.Block_58       Constant                U no load
%   64  ~.System.Block_65       Constant                time constant
%  100  ~.System.Block_18       Scope                   HY_P_mech
%  102  ~.System.Block_62       Gain                    permanent droop1
%  105  ~.System.Block_63       Gain                    permanent droop2
%  114  ~.System.Block_49       Sum                     Sum3
%  195  ~.System.Block_21       Scope                   HY_gate
%  201  ~.System.Block_46       Sum                     Sum
%  202  ~.System.Block_50       Sum                     Sum4
%  203  ~.System.Block_5        Constant                Constant
%  204  ~.System.Block_20       Scope                   HY_delta_omega
%  205  ~.System.Block_19       Scope                   HY_delta_load
%  476  ~.System.Block_54       S-Function              Transfer Fcn
%  479  ~.System.Block_23       S-Function              Integrator1
%  480  ~.System.Block_40       Saturate                Saturation
%  505  ~.System.Block_55       S-Function              Transfer Fcn1
%  506  ~.System.Block_56       S-Function              Transfer Fcn2
%  507  ~.System.Block_48       Sum                     Sum2
%  508  ~.System.Block_8        Display                 Display
%  509  ~.System.Block_41       Saturate                Saturation1
%  521  ~.System.Block_3        Sum                     Add1
%  522  ~.System.Block_4        Sum                     Add2
%  523  ~.System.Block_6        Constant                Constant1
%  524  ~.System.Block_7        Demux                   Demux
%  525  ~.System.Block_11       Product                 Divide3
%  526  ~.System.Block_12       Gain                    Gain
%  527  ~.System.Block_13       Gain                    Gain1
%  528  ~.System.Block_14       Gain                    Gain2
%  529  ~.System.Block_15       Gain                    Gain3
%  530  ~.System.Block_16       Gain                    Gain4
%  531  ~.System.Block_24       S-Function              Integrator2
%  532  ~.System.Block_25       S-Function              Integrator3
%  533  ~.System.Block_26       Mux                     Mux
%  534  ~.System.Block_27       Mux                     Mux1
%  535  ~.System.Block_28       Mux                     Mux2
%  536  ~.System.Block_29       Constant                PU Omega
%  537  ~.System.Block_32       S-Function              S-Fun Synchron Generator
%  538  ~.System.Block_33       S-Function              S-Function
%  539  ~.System.Block_34       S-Function              S-Function1
%  540  ~.System.Block_35       S-Function              S-Function2
%  541  ~.System.Block_36       S-Function              S-Function3
%  542  ~.System.Block_37       Scope                   SG P_mech\nSG P_grid\nSG Q_grid
%  543  ~.System.Block_38       Scope                   SG omega
%  544  ~.System.Block_39       Scope                   SG_P_grid
%  545  ~.System.Block_42       Scope                   Scope
%  546  ~.System.Block_43       Scope                   Scope Exciter Voltage
%  547  ~.System.Block_44       Scope                   Scope1
%  548  ~.System.Block_45       Selector                Selector
%  549  ~.System.Block_52       Sum                     Sum6
%  550  ~.System.Block_53       Sum                     Sum7
%  551  ~.System.Block_57       S-Function              Transfer Fcn3
%  552  ~.System.Block_59       Selector                electrical Power
%  553  ~.System.Block_60       Selector                electrical Power1
%  554  ~.System.Block_61       Selector                grid currents
%  555  ~.System.Block_64       Scope                   sg_Q_grid
%  563  ~                       SubSystem               HY Power
%  564  ~.System.Block          Inport                  P_ref_in_PU
%  565  ~.System.Block_1        Inport                  Q_req_in_PU
%  566  ~.System.Block_2        Inport                  V_grid_mag_phi_PU
%  567  ~.System.Block_66       Outport                 P_grid_in_PU
%  568  ~.System.Block_67       Outport                 Q_grid_in_PU
%  569  ~.System.Block_68       Outport                 I_mag_phase_in_PU

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_58_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_58_2 = 0.1;
p_479_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_479_2 = 0.5;
p_531_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_531_2 = 1;
p_532_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_532_2 = 0;
p_537 = par_SG;
p_539 = 1.5707963267949;
p_476_1 = -0.333333333333333;
p_476_2 = 0.5;
p_476_3 = 0.333333333333333;
p_476_4 = 0;
p_505_1 = -0.255102040816327;
p_505_2 = 0.25;
p_505_3 = -0.333333333333333;
p_505_4 = 0.326666666666667;
p_506_1 = -5;
p_506_2 = 2;
p_506_3 = 2.5;
p_506_4 = 0;
p_551_1 = -0.1;
p_551_2 = 0.25;
p_551_3 = 0.28;
p_551_4 = 0.3;

% Initialisation
if flag == 0
    x0 = zeros(14,1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_58_1,p_58_2);
    x0(1:1) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_479_1,p_479_2);
    x0(2:2) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_531_1,p_531_2);
    x0(3:3) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_532_1,p_532_2);
    x0(4:4) = x0_temp(1:1);
    [~,x0_temp] = modl_SG([],[],[],0,p_537);
    x0(5:10) = x0_temp(1:6);
    [~,x0_temp] = tf_sfun([],[],[],0,p_476_1,p_476_2,p_476_3,p_476_4);
    x0(11:11) = x0_temp(1:1);
    [~,x0_temp] = tf_sfun([],[],[],0,p_505_1,p_505_2,p_505_3,p_505_4);
    x0(12:12) = x0_temp(1:1);
    [~,x0_temp] = tf_sfun([],[],[],0,p_506_1,p_506_2,p_506_3,p_506_4);
    x0(13:13) = x0_temp(1:1);
    [~,x0_temp] = tf_sfun([],[],[],0,p_551_1,p_551_2,p_551_3,p_551_4);
    x0(14:14) = x0_temp(1:1);
    sys = [14 ,... % NumContStates
           0 ,... % NumDiscStates
           4 ,... % NumOutputs
           4 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 3;
    info.InportsVarName{1} = 'P_ref_in_PU'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'Q_req_in_PU'; info.InportsDimension{2} = [1 1];
    info.InportsVarName{3} = 'V_grid_mag_phi_PU'; info.InportsDimension{3} = [2 1];
    info.NumOutports = 3;
    info.OutportsVarName{1} = 'P_grid_in_PU'; info.OutportsDimension{1} = [1 1];
    info.OutportsVarName{2} = 'Q_grid_in_PU'; info.OutportsDimension{2} = [1 1];
    info.OutportsVarName{3} = 'I_mag_phase_in_PU'; info.OutportsDimension{3} = [1 2];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:2,1) = u{2};
        u0(3:4,1) = u{3};
    elseif isa(u,'struct')
        u0(1:1,1) = u.P_ref_in_PU;
        u0(2:2,1) = u.Q_req_in_PU;
        u0(3:4,1) = u.V_grid_mag_phi_PU;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)HYPower(t,x,u,flag,par_SG);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_58(1:1,1) = x(1:1);
x_479(1:1,1) = x(2:2);
x_531(1:1,1) = x(3:3);
x_532(1:1,1) = x(4:4);
x_537(1:6,1) = x(5:10);
x_476(1:1,1) = x(11:11);
x_505(1:1,1) = x(12:12);
x_506(1:1,1) = x(13:13);
x_551(1:1,1) = x(14:14);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        P_ref_in_PU = u{1};
        Q_req_in_PU = u{2};
        V_grid_mag_phi_PU = u{3};
    elseif isa(u,'struct')
        P_ref_in_PU = u.P_ref_in_PU;
        Q_req_in_PU = u.Q_req_in_PU;
        V_grid_mag_phi_PU = u.V_grid_mag_phi_PU;
    else
        P_ref_in_PU = zeros([1 1]);  P_ref_in_PU(:) = u(1:1);
        Q_req_in_PU = zeros([1 1]);  Q_req_in_PU(:) = u(2:2);
        V_grid_mag_phi_PU = zeros([2 1]);  V_grid_mag_phi_PU(:) = u(3:4);
    end
end


% S-Function Block 58 "Integrator"
y_58 = sfun_integrator(t,x_58,[],3,p_58_1,p_58_2);

u_62_1 = y_58;                % Sum1            <-- Integrator      
u_55_1 = y_58;                % Divide          <-- Integrator      

% Constant Block 64 "time constant"
y_64 = 0.98;
u_56_2 = y_64;                % Divide1         <-- time constant   

% Constant Block 57 "H0"
y_57 = 1;
u_61_2 = y_57;                % Sum5            <-- H0              

% Constant Block 63 "U no load"
y_63 = 0.01;
u_62_2 = y_63;                % Sum1            <-- U no load       

% Sum Block 62 "Sum1"
y_62 = + u_62_1 - u_62_2;

u_60_2 = y_62;                % Product1        <-- Sum1            

% S-Function Block 479 "Integrator1"
y_479 = sfun_integrator(t,x_479,[],3,p_479_1,p_479_2);

u_480_1 = y_479;              % Saturation      <-- Integrator1     

% S-Function Block 476 "Transfer Fcn"
y_476 = tf_sfun(t,x_476,[],3,p_476_1,p_476_2,p_476_3,p_476_4);

u_105_1 = y_476;              % permanent droop2 <-- Transfer Fcn    

% Gain Block 105 "permanent droop2"
y_105 = 0.75*u_105_1;


u_114_2 = y_105;              % Sum3            <-- permanent droop2 
u_201_1 = P_ref_in_PU;        % Sum             <-- P_ref_in_PU     

% Constant Block 203 "Constant"
y_203 = 1;
u_202_2 = y_203;              % Sum4            <-- Constant        

% Saturate Block 480 "Saturation"
Lower_limit = 0.000000;
Upper_limit = 1.000000;
y_480 = min(Upper_limit,max(Lower_limit,u_480_1));

u_506_1 = y_480;              % Transfer Fcn2   <-- Saturation      
u_505_1 = y_480;              % Transfer Fcn1   <-- Saturation      

% S-Function Block 505 "Transfer Fcn1"
y_505 = tf_sfun(t,x_505,u_505_1,3,p_505_1,p_505_2,p_505_3,p_505_4);

u_507_2 = y_505;              % Sum2            <-- Transfer Fcn1   

% S-Function Block 506 "Transfer Fcn2"
y_506 = tf_sfun(t,x_506,[],3,p_506_1,p_506_2,p_506_3,p_506_4);

u_509_1 = y_506;              % Saturation1     <-- Transfer Fcn2   

% Saturate Block 509 "Saturation1"
Lower_limit = 0.100000;
Upper_limit = 1.000000;
y_509 = min(Upper_limit,max(Lower_limit,u_509_1));

u_55_2 = y_509;               % Divide          <-- Saturation1     

% Product Block 55 "Divide"
y_55 = u_55_1./ u_55_2 ;

u_59_1 = y_55;                % Product         <-- Divide          
u_59_2 = y_55;                % Product         <-- Divide          

% Product Block 59 "Product"
y_59 =u_59_1 .* u_59_2;

u_60_1 = y_59;                % Product1        <-- Product         
u_61_1 = y_59;                % Sum5            <-- Product         

% Sum Block 61 "Sum5"
y_61 = - u_61_1 + u_61_2;

u_56_1 = y_61;                % Divide1         <-- Sum5            

% Product Block 60 "Product1"
y_60 =u_60_1 .* u_60_2;

u_534_1 = y_60;               % Mux1            <-- Product1        
u_201_2 = y_60;               % Sum             <-- Product1        

% Product Block 56 "Divide1"
y_56 = u_56_1./ u_56_2 ;

u_58_1 = y_56;                % Integrator      <-- Divide1         

% Sum Block 201 "Sum"
y_201 = + u_201_1 - u_201_2;

u_476_1 = y_201;              % Transfer Fcn    <-- Sum             

% S-Function Block 532 "Integrator3"
y_532 = sfun_integrator(t,x_532,[],3,p_532_1,p_532_2);

u_529_1 = y_532;              % Gain3           <-- Integrator3     
u_550_1 = y_532;              % Sum7            <-- Integrator3     

% Constant Block 523 "Constant1"
y_523 = 1;
u_550_2 = y_523;              % Sum7            <-- Constant1       

% Gain Block 529 "Gain3"
y_529 = 0.5*u_529_1;


u_549_2 = y_529;              % Sum6            <-- Gain3           

% S-Function Block 531 "Integrator2"
y_531 = sfun_integrator(t,x_531,[],3,p_531_1,p_531_2);

u_522_2 = y_531;              % Add2            <-- Integrator2     
u_539_1 = V_grid_mag_phi_PU;  % S-Function1     <-- V_grid_mag_phi_PU 

% Constant Block 536 "PU Omega"
y_536 = 314.1593;
u_525_2 = y_536;              % Divide3         <-- PU Omega        
u_521_2 = Q_req_in_PU;        % Add1            <-- Q_req_in_PU     

% S-Function Block 539 "S-Function1"
y_539 = modl_magphi2vabc(t,[],u_539_1,3,p_539);

u_535_1 = y_539;              % Mux2            <-- S-Function1     
u_534_2 = y_539;              % Mux1            <-- S-Function1     
u_533_1 = y_539;              % Mux             <-- S-Function1     

% Sum Block 550 "Sum7"
y_550 = + u_550_1 + u_550_2;

u_534_3 = y_550;              % Mux1            <-- Sum7            

% Mux Block 534 "Mux1"
y_534 = [u_534_1;u_534_2;u_534_3];

u_537_1 = y_534;              % S-Fun Synchron Generator <-- Mux1            

% S-Function Block 537 "S-Fun Synchron Generator"
y_537 = modl_SG(t,x_537,u_537_1,3,p_537);

u_553_1 = y_537;              % electrical Power1 <-- S-Fun Synchron Generator 
u_552_1 = y_537;              % electrical Power <-- S-Fun Synchron Generator 
u_554_1 = y_537;              % grid currents   <-- S-Fun Synchron Generator 

% Selector Block 552 "electrical Power"
y_552 = u_552_1(4);



% Selector Block 554 "grid currents"
y_554 = u_554_1([1 2 3]);


u_535_2 = y_554;              % Mux2            <-- grid currents   
u_541_1 = y_554;              % S-Function3     <-- grid currents   

% S-Function Block 541 "S-Function3"
y_541 = modl_vabc2magphi(t,[],u_541_1,3);

I_mag_phase_in_PU = y_541;    % I_mag_phase_in_PU <-- S-Function3     

% Mux Block 535 "Mux2"
y_535 = [u_535_1;u_535_2];

u_540_1 = y_535;              % S-Function2     <-- Mux2            

% S-Function Block 540 "S-Function2"
y_540 = modl_3phase_power(t,[],u_540_1,3);

u_524_1 = y_540;              % Demux           <-- S-Function2     

% Demux Block 524 "Demux"
y_524_1 = u_524_1(1);
y_524_2 = u_524_1(2);

P_grid_in_PU = y_524_1;       % P_grid_in_PU    <-- Demux           
u_526_1 = y_524_2;            % Gain            <-- Demux           
Q_grid_in_PU = y_524_2;       % Q_grid_in_PU    <-- Demux           

% Gain Block 526 "Gain"
y_526 = 1*u_526_1;


u_521_1 = y_526;              % Add1            <-- Gain            

% Sum Block 521 "Add1"
y_521 = - u_521_1 + u_521_2;

u_527_1 = y_521;              % Gain1           <-- Add1            
u_528_1 = y_521;              % Gain2           <-- Add1            

% Gain Block 527 "Gain1"
y_527 = 2*u_527_1;


u_522_1 = y_527;              % Add2            <-- Gain1           

% Sum Block 522 "Add2"
y_522 = + u_522_1 + u_522_2;

u_533_2 = y_522;              % Mux             <-- Add2            

% Mux Block 533 "Mux"
y_533 = [u_533_1;u_533_2];

u_538_1 = y_533;              % S-Function      <-- Mux             

% S-Function Block 538 "S-Function"
y_538 = modl_sg_deltav(t,[],u_538_1,3);

u_551_1 = y_538;              % Transfer Fcn3   <-- S-Function      

% S-Function Block 551 "Transfer Fcn3"
y_551 = tf_sfun(t,x_551,u_551_1,3,p_551_1,p_551_2,p_551_3,p_551_4);

u_549_1 = y_551;              % Sum6            <-- Transfer Fcn3   

% Sum Block 549 "Sum6"
y_549 = + u_549_1 - u_549_2;

u_530_1 = y_549;              % Gain4           <-- Sum6            

% Gain Block 530 "Gain4"
y_530 = 40*u_530_1;


u_532_1 = y_530;              % Integrator3     <-- Gain4           

% Gain Block 528 "Gain2"
y_528 = 0.5*u_528_1;


u_531_1 = y_528;              % Integrator2     <-- Gain2           

% Selector Block 553 "electrical Power1"
y_553 = u_553_1([5 6 7 8 9 10]);


u_548_1 = y_553;              % Selector        <-- electrical Power1 

% Selector Block 548 "Selector"
y_548 = u_548_1(1);


u_525_1 = y_548;              % Divide3         <-- Selector        

% Product Block 525 "Divide3"
y_525 = u_525_1./ u_525_2 ;

u_202_1 = y_525;              % Sum4            <-- Divide3         

% Sum Block 202 "Sum4"
y_202 = - u_202_1 + u_202_2;

u_102_1 = y_202;              % permanent droop1 <-- Sum4            

% Gain Block 102 "permanent droop1"
y_102 = 20*u_102_1;


u_114_1 = y_102;              % Sum3            <-- permanent droop1 

% Sum Block 114 "Sum3"
y_114 = + u_114_1 + u_114_2;

u_507_1 = y_114;              % Sum2            <-- Sum3            

% Sum Block 507 "Sum2"
y_507 = + u_507_1 - u_507_2;

u_479_1 = y_507;              % Integrator1     <-- Sum2            

% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(14,1);
        
        % S-Function derivative call of "Integrator" (SID 58)
        dx(1:1) = sfun_integrator(t,x_58,u_58_1,1,p_58_1,p_58_2);
        
        % S-Function derivative call of "Integrator1" (SID 479)
        dx(2:2) = sfun_integrator(t,x_479,u_479_1,1,p_479_1,p_479_2);
        
        % S-Function derivative call of "Integrator2" (SID 531)
        dx(3:3) = sfun_integrator(t,x_531,u_531_1,1,p_531_1,p_531_2);
        
        % S-Function derivative call of "Integrator3" (SID 532)
        dx(4:4) = sfun_integrator(t,x_532,u_532_1,1,p_532_1,p_532_2);
        
        % S-Function derivative call of "S-Fun Synchron Generator" (SID 537)
        dx(5:10) = modl_SG(t,x_537,u_537_1,1,p_537);
        
        % S-Function derivative call of "Transfer Fcn" (SID 476)
        dx(11:11) = tf_sfun(t,x_476,u_476_1,1,p_476_1,p_476_2,p_476_3,p_476_4);
        
        % S-Function derivative call of "Transfer Fcn1" (SID 505)
        dx(12:12) = tf_sfun(t,x_505,u_505_1,1,p_505_1,p_505_2,p_505_3,p_505_4);
        
        % S-Function derivative call of "Transfer Fcn2" (SID 506)
        dx(13:13) = tf_sfun(t,x_506,u_506_1,1,p_506_1,p_506_2,p_506_3,p_506_4);
        
        % S-Function derivative call of "Transfer Fcn3" (SID 551)
        dx(14:14) = tf_sfun(t,x_551,u_551_1,1,p_551_1,p_551_2,p_551_3,p_551_4);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = P_grid_in_PU;
            y{2} = Q_grid_in_PU;
            y{3} = I_mag_phase_in_PU;
        elseif flagout == 2
            y = struct();
            y.P_grid_in_PU = P_grid_in_PU;
            y.Q_grid_in_PU = Q_grid_in_PU;
            y.I_mag_phase_in_PU = I_mag_phase_in_PU;
        else
            y = [P_grid_in_PU(:);Q_grid_in_PU(:);I_mag_phase_in_PU(:);];
        end
        sys = y;
end

end % end of HYPower
