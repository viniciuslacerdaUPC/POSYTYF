function linearise_HY()

verbose = 0;

% testcase initial setup
P = 0.8; Q = 0; S = 1; W = 1.3; V1 = 1; V2 = -pi/2; omg = 1; VDC = 1;

addpath('sub_sfunction');
addpath('sub_SG');

%%% HYDRO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

loadedstruct = load('parameter\parameter_sg.mat');
par_SG = loadedstruct.par_SG;

%% definition primary power

fun = @(t,x,u,flag) HYPrimary (t,x,u,flag);
fun_y = @(t,x,u) fun(t,x,u,3);
fun_dx = @(t,x,u) fun(t,x,u,1);

init_time = 50;

% steady state primary power

t0 = 0;
[~,x0,info] = fun([],[],[],0);
u0 = [ omg ; P ];

options = odeset('RelTol',1e-3,'MaxStep',1e-3) ;
[t,x] = ode15s(@(t,x)fun_dx(t,x,u0),[0 init_time],x0,options);

x0 = x(end,:); x0 = x0(:);
y0 = fun_y(t(end),x0,u0); y0 = y0(:);

if verbose
    y = zeros(numel(t),numel(y0));
    for i1 = 1:numel(t)
        y(i1,:) = fun_y(t(i1),x(i1,:),u0);
    end
    figure('name','HY'); plot(t,y); hold on;
end

% linearisation primary power

sys = fun(t0,x0,u0,7);

nx = numel(x0);
A = sys(    1:nx  ,    1:nx  );
B = sys(    1:nx  , nx+1:end );
C = sys( nx+1:end ,    1:nx  );
D = sys( nx+1:end , nx+1:end );

lin.u0 = u0;
lin.x0 = x0;
lin.y0 = y0;
lin.A = A;
lin.B = B;
lin.C = C;
lin.D = D;

lin.InportsVarName = info.InportsVarName;
lin.InportsDimension = info.InportsDimension;
lin.OutportsVarName = info.OutportsVarName;
lin.OutportsDimension = info.OutportsDimension;

if verbose
    figure('name','HY stepresponse');
    plot_stepresponse(fun,lin,init_time);
end

save('results\lin_HY.mat','lin');
fprintf('%s Hydro Primary done \n',datetime);

%% definition secondary power %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fun = @(t,x,u,flag) HYSecondary (t,x,u,flag,par_SG);
fun_y = @(t,x,u) fun(t,x,u,3);
fun_dx = @(t,x,u) fun(t,x,u,1);

init_time = 5;

% steady state secondary power

t0 = 0;
[~,x0,info] = fun([],[],[],0);
u0 = [ P ; Q ; V1 ; V2 ];

options = odeset('RelTol',1e-3,'MaxStep',1e-3) ;
[t,x] = ode15s(@(t,x)fun_dx(t,x,u0),[0 init_time],x0,options);

x0 = x(end,:); x0 = x0(:);
y0 = fun_y(t(end),x0,u0); y0 = y0(:);

if verbose
    y = zeros(numel(t),numel(y0));
    for i1 = 1:numel(t)
        y(i1,:) = fun_y(t(i1),x(i1,:),u0);
    end
    figure('name','SG'); plot(t,y); hold on;
end

% linearisation secondary power

sys = fun(t0,x0,u0,7);

nx = numel(x0);
A = sys(    1:nx  ,    1:nx  );
B = sys(    1:nx  , nx+1:end );
C = sys( nx+1:end ,    1:nx  );
D = sys( nx+1:end , nx+1:end );

lin.u0 = u0;
lin.x0 = x0;
lin.y0 = y0;
lin.A = A;
lin.B = B;
lin.C = C;
lin.D = D;

lin.InportsVarName = info.InportsVarName;
lin.InportsDimension = info.InportsDimension;
lin.OutportsVarName = info.OutportsVarName;
lin.OutportsDimension = info.OutportsDimension;

if verbose
    figure('name','SG stepresponse');
    plot_stepresponse(fun,lin,init_time);
end

save('results\lin_SG.mat','lin');
fprintf('%s Hydro Secondary done \n',datetime);

%% definition primary+secondary power %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fun = @(t,x,u,flag) HYPower (t,x,u,flag,par_SG);
fun_y = @(t,x,u) fun(t,x,u,3);
fun_dx = @(t,x,u) fun(t,x,u,1);

% steady state primary+secondary power

t0 = 0;
[~,x0,info] = fun([],[],[],0);
u0 = [ P ; Q ; V1 ; V2 ];
options = odeset('RelTol',1e-3,'MaxStep',1e-3) ;
[t,x] = ode15s(@(t,x)fun_dx(t,x,u0),[0 init_time],x0,options);
x0 = x(end,:); x0 = x0(:);
y0 = fun_y(t(end),x0,u0); y0 = y0(:);

if verbose
    y = zeros(numel(t),numel(y0));
    for i1 = 1:numel(t)
        y(i1,:) = fun_y(t(i1),x(i1,:).',u0);
    end
    figure('name','HY+SG'); plot(t,y); hold on;
end

% linearisation primary+secondary power

sys = fun(t0,x0,u0,7);

nx = numel(x0);
A = sys(    1:nx  ,    1:nx  );
B = sys(    1:nx  , nx+1:end );
C = sys( nx+1:end ,    1:nx  );
D = sys( nx+1:end , nx+1:end );

lin.u0 = u0;
lin.x0 = x0;
lin.y0 = y0;
lin.A = A;
lin.B = B;
lin.C = C;
lin.D = D;

lin.InportsVarName = info.InportsVarName;
lin.InportsDimension = info.InportsDimension;
lin.OutportsVarName = info.OutportsVarName;
lin.OutportsDimension = info.OutportsDimension;

if verbose
    figure('name','HY+INV stepresponse');
    plot_stepresponse(fun,lin,init_time);
end

save('results\lin_HYSG.mat','lin');
fprintf('%s Hydro Primary+Secondary done \n',datetime);

end



function plot_stepresponse(sfun,Lin,te)

clf;

x0 = Lin.x0;
u0 = Lin.u0;
y0 = Lin.y0;

fun_linear = @(t,x,u,flag) modl_linear (t,x,u,flag,Lin);

cmap = lines(numel(u0));

for i1 = 1:numel(u0)
    
    u = u0;
    u(i1) = u(i1)*1.01;
    
    [t,x] = ode15s(@(t,x) sfun(t,x,u,1) ,[0 te] , x0 );
    y = zeros(numel(t),numel(y0));
    for i2 = 1:numel(t)
        y(i2,:) = sfun(t(i2),x(i2,:).',u0,3);
    end
    plot(t,y,'color',cmap(i1,:)); hold on; 
    
    [t,x] = ode15s(@(t,x) fun_linear(t,x,u,1) ,[0 te] , x0 );
    y = zeros(numel(t),numel(y0));
    for i2 = 1:numel(t)
        y(i2,:) = fun_linear(t(i2),x(i2,:).',u0,3);
    end
    plot(t,y,'--','color',cmap(i1,:)); hold on; 
    
    grid on; grid minor;

end

end
































