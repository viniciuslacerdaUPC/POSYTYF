function [sys,x0,str,ts] = modl_SG(t,x,u,flag,par_SG)

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes(par_SG);
    case 1 % Calculate derivatives
        sys = mdlDerivatives(t,x,u,par_SG);
    case 3 % Calculate outputs
        sys = mdlOutputs(x,u,par_SG);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par_SG)
        x0 = par_SG.gen.x0;
        sizes = simsizes;
        sizes.NumContStates  = numel(x0);
        sizes.NumDiscStates  = 0;
        sizes.NumOutputs     = 4 + numel(x0);
        sizes.NumInputs      = 5;
        sizes.DirFeedthrough = 1;
        sizes.NumSampleTimes = 1;
        sys = simsizes(sizes);
        
        str = [];
        % sample time is continuous -> ts = 0 and offset = 0
        ts = [0 0];
    end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(t,x,u,par_SG) % Machowski, page 455
        % read states
        delta = x(2);
        eqi = x(3); 
        edi = x(4); 
        eqii = x(5); 
        edii = x(6); 
        
        % read inputs
        Pm = u(1); 
        Vabc = u(2:4);
        ef = u(5); 
        
        % set para
        Tdoi = par_SG.gen.Td0i ; Tqoi = par_SG.gen.Tq0i; 
        Tdoii = par_SG.gen.Td0ii ; Tqoii = par_SG.gen.Tq0ii; 
        xd = par_SG.gen.xd; xdi = par_SG.gen.xdi; xdii = par_SG.gen.xdii; 
        xq = par_SG.gen.xq; xqi = par_SG.gen.xqi; xqii = par_SG.gen.xqii; 
        r = par_SG.gen.r; 
        
        M = par_SG.gen.M; 
        
        % process voltage measurement
        Vab = par_SG.gen.T*Vabc;
        
        vab = Vab(1) + 1j*Vab(2);         
        vdq = vab*exp(-1j*delta); 
        
        % calculate currents
        idq = inv([-r xqii ; -xdii -r])*([edii;eqii]-[real(vdq) ; imag(vdq)]); 
        id = idq(1); iq = idq(2); 
        % calculate power 
        Pe = 3/2 * ( (edii*id + eqii*iq)+(xdii-xqii)*id*iq );

        % calculate derivatives
        domg = 1/M*(Pm+Pe);
        ddelta = x(1); 
                      
        deqi = 1/Tdoi*(   ef - eqi + id*(xd-xdi));
        dedi = 1/Tqoi*(      - edi - iq*(xq-xqi));
        
        deqii = 1/Tdoii*( eqi - eqii + id*(xdi-xdii));
        dedii = 1/Tqoii*( edi - edii - iq*(xqi-xqii)); 
        
        dx = [domg; ddelta; deqi; dedi; deqii; dedii]; 

    end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(x,u,par_SG)
        delta = x(2);
        eqii = x(5); 
        edii = x(6); 
        
        Vabc = u(2:4); 
        
        % para
        xdii = par_SG.gen.xdii; 
        xqii = par_SG.gen.xqii; 
        r = par_SG.gen.r; 
        
        % process voltage measurement
        Vab = par_SG.gen.T*Vabc;

        vab = Vab(1) + 1j*Vab(2);         
        vdq = vab*exp(-1j*delta); 
        
        % calculate current
        idq = inv([-r xqii ; -xdii -r])*([edii;eqii]-[real(vdq) ; imag(vdq)]); %inv()*()
        iab = (idq(1)+1j*idq(2))*exp(1j*delta);
        Iabc = par_SG.gen.T_*[real(iab);imag(iab)]; 
        
        % calc power
        Pe = (edii*idq(1) + eqii*idq(2))+(xdii-xqii)*idq(1)*idq(2); 
        Pe = 3/2*Pe;
        
        y = [ -Iabc ; -Pe ; x]; 
    end

end 



