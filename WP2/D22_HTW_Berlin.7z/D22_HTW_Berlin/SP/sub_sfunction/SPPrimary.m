%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = SPPrimary(t,x,u,flag)

% BlockInfo, SysHandle (~) = Model.System.Block_5
%  SID  BlockHandle             BlockType               BlockName
%  941  ~                       SubSystem               SP Primary
%  942  ~.System.Block          Inport                  omega_g_pu
%  943  ~.System.Block_1        Inport                  S_pu
%  944  ~.System.Block_2        Inport                  P_ref_pu
%  945  ~.System.Block_3        Gain                    1/Cf_oil
%  946  ~.System.Block_4        Gain                    A_f
%  947  ~.System.Block_5        Sum                     Add
%  948  ~.System.Block_6        Constant                Constant
%  949  ~.System.Block_7        Constant                Constant1
%  950  ~.System.Block_8        Constant                Constant2
%  951  ~.System.Block_9        Constant                Constant3
%  952  ~.System.Block_10       Constant                Constant4
%  953  ~.System.Block_11       Constant                Constant5
%  954  ~.System.Block_12       Product                 Divide
%  955  ~.System.Block_13       Gain                    Gain
%  956  ~.System.Block_14       Gain                    Gain1
%  957  ~.System.Block_15       Gain                    Gain2
%  958  ~.System.Block_16       Gain                    Gain3
%  959  ~.System.Block_17       Goto                    Goto
%  960  ~.System.Block_18       Goto                    Goto1
%  961  ~.System.Block_19       Goto                    Goto10
%  962  ~.System.Block_20       Goto                    Goto11
%  963  ~.System.Block_21       Goto                    Goto12
%  964  ~.System.Block_22       Goto                    Goto13
%  965  ~.System.Block_23       Goto                    Goto2
%  966  ~.System.Block_24       Goto                    Goto3
%  967  ~.System.Block_25       Goto                    Goto4
%  968  ~.System.Block_26       Goto                    Goto5
%  969  ~.System.Block_27       Goto                    Goto6
%  970  ~.System.Block_28       Goto                    Goto7
%  971  ~.System.Block_29       Goto                    Goto8
%  972  ~.System.Block_30       Goto                    Goto9
%  973  ~.System.Block_31       S-Function              Integrator
%  974  ~.System.Block_32       S-Function              Integrator1
%  975  ~.System.Block_33       S-Function              Integrator2
%  976  ~.System.Block_34       S-Function              Integrator3
%  977  ~.System.Block_35       S-Function              Integrator4
%  978  ~.System.Block_36       S-Function              Integrator5
%  979  ~.System.Block_37       S-Function              Integrator6
%  980  ~.System.Block_38       Product                 Product
%  981  ~.System.Block_39       Product                 Product1
%  982  ~.System.Block_40       Product                 Product2
%  983  ~.System.Block_41       Saturate                Saturation
%  984  ~.System.Block_42       Saturate                Saturation1
%  985  ~.System.Block_43       Scope                   Scope
%  986  ~.System.Block_44       Scope                   Scope1
%  987  ~.System.Block_45       Scope                   Scope2
%  988  ~.System.Block_46       Scope                   Scope3
%  989  ~.System.Block_47       Sum                     Sum
%  990  ~.System.Block_48       Sum                     Sum1
%  991  ~.System.Block_49       Sum                     Sum10
%  992  ~.System.Block_50       Sum                     Sum2
%  993  ~.System.Block_51       Sum                     Sum3
%  994  ~.System.Block_52       Sum                     Sum4
%  995  ~.System.Block_53       Sum                     Sum5
%  996  ~.System.Block_54       Sum                     Sum6
%  997  ~.System.Block_55       Sum                     Sum7
%  998  ~.System.Block_56       Sum                     Sum8
%  999  ~.System.Block_57       Sum                     Sum9
% 1000  ~.System.Block_58       Switch                  Switch to avoid x_s < x_s_min
% 1001  ~.System.Block_59       Gain                    [liter]->[m^3]
% 1002  ~.System.Block_60       Gain                    calc_pu
% 1003  ~.System.Block_61       Gain                    calc_pu1
% 1004  ~.System.Block_62       Gain                    eta_o
% 1005  ~.System.Block_63       Gain                    gamma_cp
% 1006  ~.System.Block_64       Gain                    gamma_cp1
% 1007  ~.System.Block_65       Gain                    gamma_cp2
% 1008  ~.System.Block_66       Gain                    gamma_cp_
% 1009  ~.System.Block_67       Gain                    k_ff
% 1010  ~.System.Block_68       Gain                    kp_1
% 1011  ~.System.Block_69       Gain                    kp_2
% 1012  ~.System.Block_70       Constant                omega_g_ref_pu
% 1013  ~.System.Block_71       Gain                    pu -> 1000 W/m^2 
% 1014  ~.System.Block_72       Gain                    pu -> W
% 1015  ~.System.Block_73       S-Function              pump model (pump with flow control )___
% 1016  ~.System.Block_74       Gain                    tau_ch
% 1017  ~.System.Block_75       Gain                    tau_p
% 1018  ~.System.Block_76       Gain                    tau_p1
% 1019  ~.System.Block_77       Gain                    tau_sv
% 1020  ~.System.Block_78       Constant                theta_in_c
% 1021  ~.System.Block_79       Constant                theta_out_ref
% 1022  ~.System.Block_80       Gain                    unit
% 1023  ~.System.Block_81       Outport                 P_m_pu

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_973_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_973_2 = 120;
p_974_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_974_2 = 5;
p_975_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_975_2 = 0.5;
p_976_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_976_2 = 0.5;
p_977_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_977_2 = 2.08;
p_978_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_978_2 = 0;
p_979_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_979_2 = 0;
p_1015_1 = -2;
p_1015_2 = 2;
p_1015_3 = 1;
p_1015_4 = 0;

% Initialisation
if flag == 0
    x0 = zeros(8,1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_973_1,p_973_2);
    x0(1:1) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_974_1,p_974_2);
    x0(2:2) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_975_1,p_975_2);
    x0(3:3) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_976_1,p_976_2);
    x0(4:4) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_977_1,p_977_2);
    x0(5:5) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_978_1,p_978_2);
    x0(6:6) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_979_1,p_979_2);
    x0(7:7) = x0_temp(1:1);
    [~,x0_temp] = tf_sfun([],[],[],0,p_1015_1,p_1015_2,p_1015_3,p_1015_4);
    x0(8:8) = x0_temp(1:1);
    sys = [8 ,... % NumContStates
           0 ,... % NumDiscStates
           1 ,... % NumOutputs
           3 ,... % NumInputs
           0 ,... 
           0 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 3;
    info.InportsVarName{1} = 'omega_g_pu'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'S_pu'; info.InportsDimension{2} = [1 1];
    info.InportsVarName{3} = 'P_ref_pu'; info.InportsDimension{3} = [1 1];
    info.NumOutports = 1;
    info.OutportsVarName{1} = 'P_m_pu'; info.OutportsDimension{1} = [1 1];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:2,1) = u{2};
        u0(3:3,1) = u{3};
    elseif isa(u,'struct')
        u0(1:1,1) = u.omega_g_pu;
        u0(2:2,1) = u.S_pu;
        u0(3:3,1) = u.P_ref_pu;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)SPPrimary(t,x,u,flag);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_973(1:1,1) = x(1:1);
x_974(1:1,1) = x(2:2);
x_975(1:1,1) = x(3:3);
x_976(1:1,1) = x(4:4);
x_977(1:1,1) = x(5:5);
x_978(1:1,1) = x(6:6);
x_979(1:1,1) = x(7:7);
x_1015(1:1,1) = x(8:8);

% Parse inputs
if flag == 1 || flag == 2 
    % no direct feedthrough -> parse inputs for derivatives call only
    if isa(u,'cell')
        omega_g_pu = u{1};
        S_pu = u{2};
        P_ref_pu = u{3};
    elseif isa(u,'struct')
        omega_g_pu = u.omega_g_pu;
        S_pu = u.S_pu;
        P_ref_pu = u.P_ref_pu;
    else
        omega_g_pu = zeros([1 1]);  omega_g_pu(:) = u(1:1);
        S_pu = zeros([1 1]);  S_pu(:) = u(2:2);
        P_ref_pu = zeros([1 1]);  P_ref_pu(:) = u(3:3);
    end
end

% dont use inports at this point
if flag == 1 || flag == 3

    % Constant Block 1012 "omega_g_ref_pu"
    y_1012 = 1;
    u_993_1 = y_1012;             % Sum3            <-- omega_g_ref_pu  

    % Constant Block 1020 "theta_in_c"
    y_1020 = 170;
    u_947_2 = y_1020;             % Add             <-- theta_in_c      

    % S-Function Block 978 "Integrator5"
    y_978 = sfun_integrator(t,x_978,[],3,p_978_1,p_978_2);

    u_990_1 = y_978;              % Sum1            <-- Integrator5     
    u_1000_3 = y_978;             % Switch to avoid x_s < x_s_min <-- Integrator5     
    u_981_2 = y_978;              % Product1        <-- Integrator5     
    u_980_2 = y_978;              % Product         <-- Integrator5     
    u_998_2 = y_978;              % Sum8            <-- Integrator5     

    % Constant Block 1021 "theta_out_ref"
    y_1021 = 290;
    u_999_2 = y_1021;             % Sum9            <-- theta_out_ref   

    % S-Function Block 1015 "pump model (pump with flow control )___"
    y_1015 = tf_sfun(t,x_1015,[],3,p_1015_1,p_1015_2,p_1015_3,p_1015_4);


    % Constant Block 948 "Constant"
    y_948 = 120;
    u_973_2 = y_948;              % Integrator      <-- Constant        

    % S-Function Block 973 "Integrator"
    y_973 = sfun_integrator(t,x_973,[],3,p_973_1,p_973_2);

    u_947_1 = y_973;              % Add             <-- Integrator      
    u_982_1 = y_973;              % Product2        <-- Integrator      
    u_1022_1 = y_973;             % unit            <-- Integrator      
    u_981_1 = y_973;              % Product1        <-- Integrator      
    u_980_1 = y_973;              % Product         <-- Integrator      

    % Sum Block 947 "Add"
    y_947 = + u_947_1 + u_947_2;

    u_999_1 = y_947;              % Sum9            <-- Add             

    % Gain Block 1022 "unit"
    y_1022 = 1*u_1022_1;


    u_1007_1 = y_1022;            % gamma_cp2       <-- unit            

    % Product Block 981 "Product1"
    y_981 =u_981_1 .* u_981_2;

    u_1008_1 = y_981;             % gamma_cp_       <-- Product1        

    % Gain Block 1008 "gamma_cp_"
    y_1008 = 2400*u_1008_1;


    u_1002_1 = y_1008;            % calc_pu         <-- gamma_cp_       

    % Gain Block 1002 "calc_pu"
    y_1002 = 8.3333e-07*u_1002_1;



    % Product Block 980 "Product"
    y_980 =u_980_1 .* u_980_2;

    u_1005_1 = y_980;             % gamma_cp        <-- Product         

    % Gain Block 1005 "gamma_cp"
    y_1005 = 2400*u_1005_1;


    u_989_2 = y_1005;             % Sum             <-- gamma_cp        

    % S-Function Block 977 "Integrator4"
    y_977 = sfun_integrator(t,x_977,[],3,p_977_1,p_977_2);

    u_982_2 = y_977;              % Product2        <-- Integrator4     
    u_1000_1 = y_977;             % Switch to avoid x_s < x_s_min <-- Integrator4     
    u_997_2 = y_977;              % Sum7            <-- Integrator4     

    % Product Block 982 "Product2"
    y_982 =u_982_1 .* u_982_2;

    u_1006_1 = y_982;             % gamma_cp1       <-- Product2        

    % Gain Block 1006 "gamma_cp1"
    y_1006 = 2400*u_1006_1;


    u_1003_1 = y_1006;            % calc_pu1        <-- gamma_cp1       

    % Gain Block 1003 "calc_pu1"
    y_1003 = 8.3333e-07*u_1003_1;


    u_955_1 = y_1003;             % Gain            <-- calc_pu1        

    % Gain Block 955 "Gain"
    y_955 = 1*u_955_1;


    u_995_1 = y_955;              % Sum5            <-- Gain            

    % Constant Block 949 "Constant1"
    y_949 = 5;
    u_974_2 = y_949;              % Integrator1     <-- Constant1       

    % S-Function Block 974 "Integrator1"
    y_974 = sfun_integrator(t,x_974,[],3,p_974_1,p_974_2);

    u_1000_2 = y_974;             % Switch to avoid x_s < x_s_min <-- Integrator1     

    % Switch Block 1000 "Switch to avoid x_s < x_s_min"
    if u_1000_2 > 2
    y_1000 = u_1000_1;
    else
    y_1000 = u_1000_3;
    end

    u_990_2 = y_1000;             % Sum1            <-- Switch to avoid x_s < x_s_min 

    % Sum Block 990 "Sum1"
    y_990 = + u_990_1 - u_990_2;

    u_1001_1 = y_990;             % [liter]->[m^3]  <-- Sum1            

    % Gain Block 1001 "[liter]->[m^3]"
    y_1001 = 0.001*u_1001_1;


    u_956_1 = y_1001;             % Gain1           <-- [liter]->[m^3]  

    % Gain Block 956 "Gain1"
    y_956 = 0.079577*u_956_1;


    u_974_1 = y_956;              % Integrator1     <-- Gain1           

    % Gain Block 1007 "gamma_cp2"
    y_1007 = 2400*u_1007_1;


    u_954_2 = y_1007;             % Divide          <-- gamma_cp2       

    % S-Function Block 976 "Integrator3"
    y_976 = sfun_integrator(t,x_976,[],3,p_976_1,p_976_2);

    P_m_pu = y_976;               % P_m_pu          <-- Integrator3     
    u_994_2 = y_976;              % Sum4            <-- Integrator3     
    u_996_2 = y_976;              % Sum6            <-- Integrator3     

    % S-Function Block 975 "Integrator2"
    y_975 = sfun_integrator(t,x_975,[],3,p_975_1,p_975_2);

    u_996_1 = y_975;              % Sum6            <-- Integrator2     
    u_995_2 = y_975;              % Sum5            <-- Integrator2     

    % Constant Block 950 "Constant2"
    y_950 = 0.5;
    u_975_2 = y_950;              % Integrator2     <-- Constant2       

    % Sum Block 995 "Sum5"
    y_995 = + u_995_1 - u_995_2;

    u_1019_1 = y_995;             % tau_sv          <-- Sum5            

    % Gain Block 1019 "tau_sv"
    y_1019 = 5*u_1019_1;


    u_975_1 = y_1019;             % Integrator2     <-- tau_sv          

    % Constant Block 951 "Constant3"
    y_951 = 0.5;
    u_976_2 = y_951;              % Integrator3     <-- Constant3       

    % Sum Block 996 "Sum6"
    y_996 = + u_996_1 - u_996_2;

    u_1016_1 = y_996;             % tau_ch          <-- Sum6            

    % Gain Block 1016 "tau_ch"
    y_1016 = 2*u_1016_1;


    u_976_1 = y_1016;             % Integrator3     <-- tau_ch          

    % Constant Block 952 "Constant4"
    y_952 = 2.08;
    u_977_2 = y_952;              % Integrator4     <-- Constant4       

    % Constant Block 953 "Constant5"
    y_953 = 0;
    u_978_2 = y_953;              % Integrator5     <-- Constant5       

    % S-Function Block 979 "Integrator6"
    y_979 = sfun_integrator(t,x_979,[],3,p_979_1,p_979_2);

    u_957_1 = y_979;              % Gain2           <-- Integrator6     

    % Gain Block 957 "Gain2"
    y_957 = -0.0126*u_957_1;


    u_991_2 = y_957;              % Sum10           <-- Gain2           

    % Sum Block 999 "Sum9"
    y_999 = - u_999_1 + u_999_2;

    u_958_1 = y_999;              % Gain3           <-- Sum9            
    u_979_1 = y_999;              % Integrator6     <-- Sum9            

    % Gain Block 958 "Gain3"
    y_958 = -0.63002*u_958_1;


    u_991_1 = y_958;              % Sum10           <-- Gain3           

    % Sum Block 991 "Sum10"
    y_991 = + u_991_1 + u_991_2;

    u_984_1 = y_991;              % Saturation1     <-- Sum10           

    % Saturate Block 984 "Saturation1"
    Lower_limit = 0.000000;
    Upper_limit = 12.000000;
    y_984 = min(Upper_limit,max(Lower_limit,u_984_1));

    u_998_1 = y_984;              % Sum8            <-- Saturation1     
    u_1015_1 = y_984;             % pump model (pump with flow control )___ <-- Saturation1     

    % Sum Block 998 "Sum8"
    y_998 = + u_998_1 - u_998_2;

    u_1018_1 = y_998;             % tau_p1          <-- Sum8            

    % Gain Block 1018 "tau_p1"
    y_1018 = 2*u_1018_1;


    u_978_1 = y_1018;             % Integrator5     <-- tau_p1          
end

% use inports only for derivatives
if flag == 1
    u_994_1 = P_ref_pu;           % Sum4            <-- P_ref_pu        
    u_1009_1 = P_ref_pu;          % k_ff            <-- P_ref_pu        
    u_993_2 = omega_g_pu;         % Sum3            <-- omega_g_pu      
    u_1013_1 = S_pu;              % pu -> 1000 W/m^2  <-- S_pu            

    % Gain Block 1013 "pu -> 1000 W/m^2 "
    y_1013 = 1000*u_1013_1;


    u_1004_1 = y_1013;            % eta_o           <-- pu -> 1000 W/m^2  

    % Gain Block 1004 "eta_o"
    y_1004 = 0.8*u_1004_1;


    u_946_1 = y_1004;             % A_f             <-- eta_o           

    % Gain Block 946 "A_f"
    y_946 = 1500*u_946_1;


    u_989_1 = y_946;              % Sum             <-- A_f             

    % Sum Block 989 "Sum"
    y_989 = + u_989_1 - u_989_2;

    u_945_1 = y_989;              % 1/Cf_oil        <-- Sum             

    % Gain Block 945 "1/Cf_oil"
    y_945 = 4.1667e-07*u_945_1;


    u_973_1 = y_945;              % Integrator      <-- 1/Cf_oil        

    % Sum Block 994 "Sum4"
    y_994 = + u_994_1 - u_994_2;

    u_1011_1 = y_994;             % kp_2            <-- Sum4            

    % Sum Block 993 "Sum3"
    y_993 = + u_993_1 - u_993_2;

    u_1010_1 = y_993;             % kp_1            <-- Sum3            

    % Gain Block 1010 "kp_1"
    y_1010 = 20*u_1010_1;


    u_992_1 = y_1010;             % Sum2            <-- kp_1            

    % Gain Block 1009 "k_ff"
    y_1009 = 1*u_1009_1;


    u_992_2 = y_1009;             % Sum2            <-- k_ff            

    % Gain Block 1011 "kp_2"
    y_1011 = 0.75*u_1011_1;


    u_992_3 = y_1011;             % Sum2            <-- kp_2            

    % Sum Block 992 "Sum2"
    y_992 = + u_992_1 + u_992_2 + u_992_3;

    u_1014_1 = y_992;             % pu -> W         <-- Sum2            

    % Gain Block 1014 "pu -> W"
    y_1014 = 1200000*u_1014_1;


    u_954_1 = y_1014;             % Divide          <-- pu -> W         

    % Product Block 954 "Divide"
    y_954 = u_954_1./ u_954_2 ;

    u_983_1 = y_954;              % Saturation      <-- Divide          

    % Saturate Block 983 "Saturation"
    Lower_limit = 0.000000;
    Upper_limit = 10.000000;
    y_983 = min(Upper_limit,max(Lower_limit,u_983_1));

    u_997_1 = y_983;              % Sum7            <-- Saturation      

    % Sum Block 997 "Sum7"
    y_997 = + u_997_1 - u_997_2;

    u_1017_1 = y_997;             % tau_p           <-- Sum7            

    % Gain Block 1017 "tau_p"
    y_1017 = 2*u_1017_1;


    u_977_1 = y_1017;             % Integrator4     <-- tau_p           
end


% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(8,1);
        
        % S-Function derivative call of "Integrator" (SID 973)
        in = [u_973_1;u_973_2];
        dx(1:1) = sfun_integrator(t,x_973,in,1,p_973_1,p_973_2);
        
        % S-Function derivative call of "Integrator1" (SID 974)
        in = [u_974_1;u_974_2];
        dx(2:2) = sfun_integrator(t,x_974,in,1,p_974_1,p_974_2);
        
        % S-Function derivative call of "Integrator2" (SID 975)
        in = [u_975_1;u_975_2];
        dx(3:3) = sfun_integrator(t,x_975,in,1,p_975_1,p_975_2);
        
        % S-Function derivative call of "Integrator3" (SID 976)
        in = [u_976_1;u_976_2];
        dx(4:4) = sfun_integrator(t,x_976,in,1,p_976_1,p_976_2);
        
        % S-Function derivative call of "Integrator4" (SID 977)
        in = [u_977_1;u_977_2];
        dx(5:5) = sfun_integrator(t,x_977,in,1,p_977_1,p_977_2);
        
        % S-Function derivative call of "Integrator5" (SID 978)
        in = [u_978_1;u_978_2];
        dx(6:6) = sfun_integrator(t,x_978,in,1,p_978_1,p_978_2);
        
        % S-Function derivative call of "Integrator6" (SID 979)
        dx(7:7) = sfun_integrator(t,x_979,u_979_1,1,p_979_1,p_979_2);
        
        % S-Function derivative call of "pump model (pump with flow control )___" (SID 1015)
        dx(8:8) = tf_sfun(t,x_1015,u_1015_1,1,p_1015_1,p_1015_2,p_1015_3,p_1015_4);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = P_m_pu;
        elseif flagout == 2
            y = struct();
            y.P_m_pu = P_m_pu;
        else
            y = P_m_pu;
        end
        sys = y;
end

end % end of SPPrimary
