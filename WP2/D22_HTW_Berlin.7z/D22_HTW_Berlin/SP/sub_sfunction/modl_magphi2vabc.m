function [sys,x0,str,ts] = modl_magphi2vabc(t,~,u,flag,phi0)

switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes();
    case 3
        sys = mdlOutputs(t,u,phi0);
    case { 1, 2, 4, 9 }
        sys = [];
    otherwise
        DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end

end

function V = mdlOutputs(t,u,phi0)
omg = 1;
omg = omg*2*pi*50;
mag = u(1);
phi = u(2);
phi = phi + phi0;
V = mag * [ sin(omg*t + phi) ; sin(omg*t + phi - 2/3*pi) ; sin(omg*t + phi + 2/3*pi) ];
end

function [sys,x0,str,ts] = mdlInitializeSizes()
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 3;
sizes.NumInputs      = 2;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0 = [];
str = [];
ts  = [0 0];

end