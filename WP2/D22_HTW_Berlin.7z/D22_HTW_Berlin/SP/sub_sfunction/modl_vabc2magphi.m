function [sys,x0,str,ts] = modl_vabc2magphi(t,~,u,flag)


switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes();
    case 3
        sys = mdlOutputs(t,u);
    case { 1, 2, 4, 9 }
        sys = [];
    otherwise
        DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end

end

function y = mdlOutputs(t,v_abc)
omg = 1;
omg = omg*2*pi*50;

T = (2/3)*[1 -1/2 -1/2 ; 0 sqrt(3)/2 -sqrt(3)/2];
v_ab_ = T*v_abc;
v_ab = v_ab_(1) + 1j*v_ab_(2);

theta = omg*t;

v_dq = v_ab*exp(-1j*theta);
mag = abs(v_dq);
phi = angle(v_dq);

y = [mag phi];
end

function [sys,x0,str,ts] = mdlInitializeSizes()
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 3;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0 = [];
str = [];
ts  = [0 0];

end