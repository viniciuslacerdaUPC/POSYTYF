function [sys,x0,str,ts] = modl_sg_deltav(~,~,u,flag)

switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes();
    case 3
        sys = mdlOutputs(u);
    case { 1, 2, 4, 9 }
        sys = [];
    otherwise
        DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end

end

function dv = mdlOutputs(u)
Vabc_pu = u(1:3);
vr_pu = u(4);
T = (2/3)*[1 -1/2 -1/2 ; 0 sqrt(3)/2 -sqrt(3)/2];
vab = T*Vabc_pu; 
vg = sqrt(vab(1)^2+vab(2)^2); 
dv = vr_pu-vg;
end

function [sys,x0,str,ts] = mdlInitializeSizes()
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0 = [];
str = [];
ts  = [0 0];

end