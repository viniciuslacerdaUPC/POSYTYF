function [sys,x0,str,ts] = sfun_integrator(~,x,u,flag,par,int_x0)

% input vector u = [ u_in ] or [ u_in ; u_reset ; u_x0 ]

% Parameter: par = [ n inport_reset inport_init limit lb ub disc_stepsize]
%            int_x0 = internal x0
%
% n = NumContStates = NumInputs = NumOutputs
% inport_reset = activate external reset port
% inport_init  = activate external initial condition port
% limit = limit integral = saturation
% lb    = lower saturation bound
% ub    = upper saturation bound
% disc_stepsize = frequency to check for external reset

% limitations
% (1) internal initial condition (parameter int_x0) must be given, even
%     if external initial condition port is activated. furthermore, for
%     the start of the simulation they must be equal. this is due the fact
%     that at the time of the initialisation of the s-functions (within
%     simulink) the inputs u are not given ( u = [] ).

% concept: 
% (1) implementation of external reset with discontonous states
%     if reset is triggered, the following eq holds:
%     x_disc = x0 - x_cont --> see mdlUpdate subfunction
%     this gives for the output in the next time step:
%     y = x_cont + x_disc = x0
% (2) implementation of saturation by setting derivatives to zero
%     y = x_cont + x_disc (in case of no external reset: y = x_cont)
%     if y out of the bounds, allow only derivatives which leads toward
%     the desired intervall --> see mdlDerivatives subfunction

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag

switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes(par,int_x0);
    case 1
        sys = mdlDerivatives(x,u,par);
    case 2
        sys = mdlUpdate(x,u,par,int_x0);
    case 3
        sys = mdlOutputs(x,par,flagout);
    case { 4, 9 }
        sys = [];
    otherwise
        error('Simulink:blocks:unhandledFlag', num2str(flag));
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sys,x0,info,ts] = mdlInitializeSizes(par,int_x0)

% Parameter: par = [ n inport_reset inport_init limit lb ub disc_stepsize]
%            int_x0 = internal x0
n = par(1);                 % NumContStates
n0 = par(2);                % NumContStates of intitial condition
inport_reset = par(3);      % activate external reset port
inport_init = par(4);       % activate external initial condition port
limit = par(5) == 1;        % limit integral = saturation
wrap = par(5) == 2;         % wrap integral = periodic mapping
lb = par(6);                % lower saturation/wrap bound
ub = par(7);                % upper saturation/wrap bound
outport_limit = par(8);     % activate saturation outport
outport_state = par(9);     % activate state outport
disc_stepsize = par(10);    % frequency to check for external reset

% limit inital value if saturation is activated
if limit
    int_x0 = min(max(int_x0(:),lb),ub);
end

% x_cont_0 can be scalar or vector
% scalar: (if S > 1) apply x_cont_0 to each entry of x0
% vector: x0 = x_cont_0
if n0 == 1 && n > 1
    int_x0 = int_x0(1) * ones(n,1);
end

% reset functionality needs discrete states
% discrete states need discrete sample time
if inport_reset
    NumDiscStates = n;
    NumSampleTime = 2;
    ts = [ 0           0
        disc_stepsize  0];
    
    % state vector has continous followed by discontinous states
    x0 = [int_x0(:) ; zeros(NumDiscStates,1) ];
else
    NumDiscStates = 0;
    ts = [0 0];
    NumSampleTime = 1;
    x0 = int_x0(:);
end

% simulink info vector
sys = [n ,... % NumContStates
    NumDiscStates ,... % NumDiscStates
    n + n*outport_limit + n*outport_state,... % NumOutputs
    n + inport_reset + n0*inport_init ,... % NumInputs
    0 ,...
    0 ,... % DirectFeedthrough
    NumSampleTime ]; % NumSampleTimes

% custom info struct, inports
i1 = 1; info.InportsVarName{i1} = 'dx'; info.InportsDimension{i1} = [n 1];
if inport_reset
    i1 = i1 + 1;
    info.InportsVarName{i1} = 'reset'; info.InportsDimension{i1} = [1 1];
end
if inport_init
    i1 = i1 + 1;
    info.InportsVarName{i1} = 'x0'; info.InportsDimension{i1} = [n0 1];
end
info.NumInports = i1; % = 1 + inport_reset + inport_init

% custom info struct, outports
i2 = 1; info.OutportsVarName{i2} = 'y'; info.OutportsDimension{i2} = [n 1];
if outport_limit
    i2 = i2 + 1;
    info.OutportsVarName{i2} = 'limit'; info.OutportsDimension{i2} = [n 1];
end
if outport_state
    i2 = i2 + 1;
    info.OutportsVarName{i2} = 'x'; info.OutportsDimension{i2} = [n 1];
end
info.NumOutports = i2; % = 1 + outport_limit + outport_state

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function x_disc = mdlUpdate(x,u,par,int_x0)

% Parameter: par = [ n inport_reset inport_init limit lb ub disc_stepsize]
%            int_x0 = internal x0
n = par(1);                 % NumContStates
inport_reset = par(3);      % activate external reset port
inport_init = par(4);       % activate external initial condition port
limit = par(5) == 1;        % limit integral = saturation
lb = par(6);                % lower saturation bound
ub = par(7);                % upper saturation bound

% Parse inputs
if isa(u,'cell')
    if inport_reset, u_reset = u{1 + inport_reset}; end
    if inport_init, ext_x0 = u{1 + inport_reset + inport_init}; end
elseif isa(u,'struct')
    if inport_reset, u_reset = u.reset; end
    if inport_init, ext_x0 = u.x0; end
else
    if inport_reset, u_reset = u(n + inport_reset); end
    if inport_init, ext_x0 = u(n + inport_reset + inport_init : end); end
end

if inport_reset % check for external reset signal?
    if u_reset == 0
        x_disc = x(n+1:2*n); % do nothing
    else
        if inport_init % use external inital condition?
            if limit
                ext_x0 = min(max(ext_x0(:),lb),ub); % limit inital value
            end
            x_disc = ext_x0 - x(1:n); % use external inital condition
        else
            if limit
                int_x0 = min(max(int_x0(:),lb),ub); % limit inital value
            end
            x_disc = int_x0(:) - x(1:n); % use internal inital condition
        end
    end
else
    x_disc =  [];
end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function dx = mdlDerivatives(x,u,par)

% Parameter: par = [ n inport_reset inport_init limit lb ub disc_stepsize]
%            int_x0 = internal x0
n = par(1);                 % NumContStates
inport_reset = par(3);      % activate external reset port
limit = par(5) == 1;        % limit integral = saturation
lb = par(6);                % lower saturation bound
ub = par(7);                % upper saturation bound

% Parse inputs
if isa(u,'cell')
    input = u{1};
    if inport_reset, u_reset = u{1 + inport_reset}; end
elseif isa(u,'struct')
    input = u.dx;
    if inport_reset, u_reset = u.reset; end
else
    input = u(1:n);
    if inport_reset, u_reset = u(n + inport_reset); end
end

% in case of reset or saturation stop integration = set derivatives to zero
if inport_reset && u_reset ~= 0 % do reset?
    dx = zeros(n,1);
elseif limit % check for saturation?
    dx = zeros(n,1);
    if inport_reset % with external reset functionality y = x_cont + x_disc
        x = x(1:n) + x(n+1:2*n);
    end
    for i1 = 1:n
        % derivative is not zero only if y = x lies within the intervall
        % or the derivative leads toward the intervall
        if ( x(i1) < ub || input(i1) < 0 ) && ( x(i1) > lb || input(i1) > 0)
            dx(i1) = input(i1);
        end
    end
else
    dx = input;
end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function sys = mdlOutputs(x,par,flagout)

% Parameter: par = [ n inport_reset inport_init limit lb ub disc_stepsize]
%            int_x0 = internal x0
n = par(1);                 % NumContStates
inport_reset = par(3);      % activate external reset port
limit = par(5) == 1;        % limit integral = saturation
wrap = par(5) == 2;         % wrap integral = periodic mapping
lb = par(6);                % lower saturation bound
ub = par(7);                % upper saturation bound
outport_limit = par(8);     % activate saturation outport
outport_state = par(9);     % activate state outport

if inport_reset
    y = x(1:n) + x(n+1:2*n); % x_cont + x_disc
else
    y = x;
end

% limit output value if saturation is activated
if limit
    y = min(max(y(:),lb),ub);
    
end

% determine if saturation is reached
if outport_limit
    is_limited = (y <= lb) | (y >= ub);
end
    
% periodic cast of output if wrap is activated
if wrap && isfinite(lb) && isfinite(ub)
    y = mod( y-lb , ub-lb ) + lb;
end
    
% Compose outputs
if flagout == 1 % cell
    sys{1} = y;
    if outport_limit, sys{1 + outport_limit} = is_limited; end
    if outport_state, sys{1 + outport_limit + outport_state} = x(1:n); end
elseif flagout == 2 % struct
    sys.y = y;
    if outport_limit, sys.limit = is_limited; end
    if outport_state, sys.x = x(1:n); end
else % vector
    if ~outport_limit && ~outport_state
        sys = y;
    elseif outport_limit && ~outport_state
        sys = [ y ; is_limited ];
    elseif ~outport_limit && outport_state
        sys = [ y ; x(1:n) ];
    else
        sys = [ y ; is_limited ; x(1:n) ];
    end
end

end

