function [sys,x0,str,ts] = modl_linear(~,x,u,flag,par)

A = par.A;
B = par.B;
C = par.C;
D = par.D;
x0 = par.x0(:);
y0 = par.y0(:);
u0 = par.u0(:);
x = x(:);
u = u(:);

switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes(A,B,C,x0);
    case 1
        sys = mdlDerivatives(x,u,A,B,x0,u0);
    case 3
        sys = mdlOutputs(x,u,C,D,x0,u0,y0);
    case { 2, 4, 9 }
        sys = [];
    otherwise
        DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end

end

function dx = mdlDerivatives(x,u,A,B,x0,u0)
dx = A*(x-x0) + B*(u-u0);
end

function y = mdlOutputs(x,u,C,D,x0,u0,y0)
y = C*(x-x0) + D*(u-u0) + y0;
end

function [sys,x0,str,ts] = mdlInitializeSizes(A,B,C,x0)
num_ContStates  = size(A,1);
num_Inputs      = size(B,2);
num_Outputs     = size(C,1);

sizes = simsizes;
sizes.NumContStates  = num_ContStates;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = num_Outputs;
sizes.NumInputs      = num_Inputs;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);

str = [];
ts  = [0 0];
end