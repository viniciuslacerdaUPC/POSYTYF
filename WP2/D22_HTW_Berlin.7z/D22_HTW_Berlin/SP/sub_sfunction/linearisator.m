function varargout = linearisator(sfun,t0,x0,u0)

StepRatio = 2.0000001;
MaxStep = 1e-2;
tol = 1e-4;

x0 = x0(:);
u0 = u0(:);
y0 = sfun(t0,x0,u0,3);

nx = numel(x0);
nu = numel(u0);
ny = numel(y0);

A = zeros(nx,nx);
errA = inf(nx,nx);

for i1 = 1:nx
    for i2 = 1:nx
        [ A(i1,i2) , errA(i1,i2) , ~ ] = derivest( ...
            @(x) fun_dxi_x(sfun,t0,x0,u0,x,i2,i1) , x0(i2) , ...
            'Vectorized' , 'no' , 'MaxStep' , MaxStep , 'StepRatio' , StepRatio);
    end
end

if any(~isfinite(A(:)))
    warning('A ~= isfinite');
end

maxerr = max(errA(:));
if maxerr > tol
    warning('A matrix: maxerr = %g > tol = %g',maxerr,tol);
end

B = zeros(nx,nu);
errB = inf(nx,nu);

for i1 = 1:nx
    for i2 = 1:nu
        [ B(i1,i2) , errB(i1,i2) , ~ ] = derivest( ...
            @(u)fun_dxi_u(sfun,t0,x0,u0,u,i2,i1) , u0(i2) , ...
            'Vectorized' , 'no' , 'MaxStep' , MaxStep , 'StepRatio' , StepRatio);
    end
end

if any(~isfinite(B(:)))
    warning('B ~= isfinite');
end

maxerr = max(errB(:));
if maxerr > tol
    warning('B matrix: maxerr = %g > tol = %g',maxerr,tol);
end

C = zeros(ny,nx);
errC = inf(ny,nx);

for i1 = 1:ny
    for i2 = 1:nx
        [ C(i1,i2) , errC(i1,i2) , ~ ] = derivest( ...
            @(x)fun_yi_x(sfun,t0,x0,u0,x,i2,i1) , x0(i2) , ...
            'Vectorized' , 'no' , 'MaxStep' , MaxStep , 'StepRatio' , StepRatio);
    end
end

if any(~isfinite(C(:)))
    warning('C ~= isfinite');
end

maxerr = max(errC(:));
if maxerr > tol
    warning('C matrix: maxerr = %g > tol = %g',maxerr,tol);
end

D = zeros(ny,nu);
errD = inf(ny,nu);

for i1 = 1:ny
    for i2 = 1:nu
        [ D(i1,i2) , errD(i1,i2) , ~ ] = derivest( ...
            @(u)fun_yi_u(sfun,t0,x0,u0,u,i2,i1) , u0(i2) , ...
            'Vectorized' , 'no' , 'MaxStep' , MaxStep , 'StepRatio' , StepRatio);
    end
end

if any(~isfinite(D(:)))
    warning('D ~= isfinite');
end

maxerr = max(errD(:));
if maxerr > tol
    warning('D matrix: maxerr = %g > tol = %g',maxerr,tol);
end

switch nargout
    case 1
        sys = zeros(nx+ny,nx+nu);
        sys( 1:nx , 1:nx ) = A;
        sys( 1:nx , nx+1:end ) = B;
        sys( nx+1:end , 1:nx ) = C;
        sys( nx+1:end , nx+1:end ) = D;
        varargout{1} = sys;
    case 2
        sys = zeros(nx+ny,nx+nu);
        sys( 1:nx , 1:nx ) = A;
        sys( 1:nx , nx+1:end ) = B;
        sys( nx+1:end , 1:nx ) = C;
        sys( nx+1:end , nx+1:end ) = D;
        varargout{1} = sys;
        varargout{2} = maxerr;
    case 4
        varargout{1} = A;
        varargout{2} = B;
        varargout{3} = C;
        varargout{4} = D;
    case 5
        varargout{1} = A;
        varargout{2} = B;
        varargout{3} = C;
        varargout{4} = D;
        varargout{5} = maxerr;
end

% A = sys(1:n,1:n);
% B = sys(1:n,n+1:end);
% C = sys(n+1:end,1:n);
% D = sys(n+1:end,n+1:end);

end



function dxi = fun_dxi_x(sfun,t0,x0,u0,x_in,ind_in,ind_out)
x = x0;
x(ind_in) = x_in;
dx = sfun(t0,x,u0,1);
dxi = dx(ind_out);
end



function dxi = fun_dxi_u(sfun,t0,x0,u0,u_in,ind_in,ind_out)
u = u0;
u(ind_in) = u_in;
dx = sfun(t0,x0,u,1);
dxi = dx(ind_out);
end



function yi = fun_yi_x(sfun,t0,x0,u0,x_in,ind_in,ind_out)
x = x0;
x(ind_in) = x_in;
y = sfun(t0,x,u0,3);
yi = y(ind_out);
end



function yi = fun_yi_u(sfun,t0,x0,u0,u_in,ind_in,ind_out)
u = u0;
u(ind_in) = u_in;
y = sfun(t0,x0,u,3);
yi = y(ind_out);
end
