%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = SPSecondary(t,x,u,flag,par_SG)

% BlockInfo, SysHandle (~) = Model.System.Block_4.System.Block_13
%  SID  BlockHandle             BlockType               BlockName
%  868  ~                       SubSystem               SP Secondary
%  869  ~.System.Block          Inport                  P_mech_in_PU
%  870  ~.System.Block_1        Inport                  Q_req_in_PU
%  871  ~.System.Block_2        Inport                  V_grid_mag_phi_PU
%  872  ~.System.Block_7        Product                 Divide3
%  877  ~.System.Block_8        Gain                    Gain
%  882  ~.System.Block_3        Sum                     Add1
%  883  ~.System.Block_4        Sum                     Add2
%  884  ~.System.Block_10       Gain                    Gain2
%  885  ~.System.Block_9        Gain                    Gain1
%  886  ~.System.Block_13       S-Function              Integrator
%  887  ~.System.Block_27       Scope                   Scope
%  889  ~.System.Block_28       Scope                   Scope Exciter Voltage
%  890  ~.System.Block_33       S-Function              Transfer Fcn
%  893  ~.System.Block_5        Constant                Constant
%  894  ~.System.Block_14       S-Function              Integrator1
%  898  ~.System.Block_31       Sum                     Sum
%  899  ~.System.Block_32       Sum                     Sum1
%  908  ~.System.Block_16       Mux                     Mux1
%  909  ~.System.Block_18       Constant                PU Omega
%  911  ~.System.Block_19       S-Function              S-Fun Synchron Generator
%  912  ~.System.Block_24       Scope                   SG P_mech\nSG P_grid\nSG Q_grid
%  913  ~.System.Block_25       Scope                   SG omega
%  914  ~.System.Block_26       Scope                   SG_P_grid
%  915  ~.System.Block_30       Selector                Selector
%  916  ~.System.Block_34       Selector                electrical Power
%  917  ~.System.Block_35       Selector                electrical Power1
%  918  ~.System.Block_36       Selector                grid currents
%  919  ~.System.Block_37       Scope                   sg_Q_grid
%  920  ~.System.Block_38       Outport                 P_grid_in_PU
%  921  ~.System.Block_39       Outport                 Q_grid_in_PU
%  922  ~.System.Block_40       Outport                 I_mag_phase_in_PU
%  923  ~.System.Block_41       Outport                 omega_in_PU
% 1036  ~.System.Block_21       S-Function              S-Function1
% 1094  ~.System.Block_20       S-Function              S-Function
% 1095  ~.System.Block_15       Mux                     Mux
% 1119  ~.System.Block_22       S-Function              S-Function2
% 1120  ~.System.Block_17       Mux                     Mux2
% 1121  ~.System.Block_6        Demux                   Demux
% 1122  ~.System.Block_11       Gain                    Gain3
% 1123  ~.System.Block_12       Gain                    Gain4
% 1124  ~.System.Block_23       S-Function              S-Function3
% 1127  ~.System.Block_29       Scope                   Scope1

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_886_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_886_2 = 1;
p_894_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_894_2 = 0;
p_911 = par_SG;
p_1036 = 1.5707963267949;
p_890_1 = -0.1;
p_890_2 = 0.25;
p_890_3 = 0.28;
p_890_4 = 0.3;

% Initialisation
if flag == 0
    x0 = zeros(9,1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_886_1,p_886_2);
    x0(1:1) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_894_1,p_894_2);
    x0(2:2) = x0_temp(1:1);
    [~,x0_temp] = modl_SG([],[],[],0,p_911);
    x0(3:8) = x0_temp(1:6);
    [~,x0_temp] = tf_sfun([],[],[],0,p_890_1,p_890_2,p_890_3,p_890_4);
    x0(9:9) = x0_temp(1:1);
    sys = [9 ,... % NumContStates
           0 ,... % NumDiscStates
           5 ,... % NumOutputs
           4 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 3;
    info.InportsVarName{1} = 'P_mech_in_PU'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'Q_req_in_PU'; info.InportsDimension{2} = [1 1];
    info.InportsVarName{3} = 'V_grid_mag_phi_PU'; info.InportsDimension{3} = [2 1];
    info.NumOutports = 4;
    info.OutportsVarName{1} = 'P_grid_in_PU'; info.OutportsDimension{1} = [1 1];
    info.OutportsVarName{2} = 'Q_grid_in_PU'; info.OutportsDimension{2} = [1 1];
    info.OutportsVarName{3} = 'I_mag_phase_in_PU'; info.OutportsDimension{3} = [1 2];
    info.OutportsVarName{4} = 'omega_in_PU'; info.OutportsDimension{4} = [1 1];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:2,1) = u{2};
        u0(3:4,1) = u{3};
    elseif isa(u,'struct')
        u0(1:1,1) = u.P_mech_in_PU;
        u0(2:2,1) = u.Q_req_in_PU;
        u0(3:4,1) = u.V_grid_mag_phi_PU;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)SPSecondary(t,x,u,flag,par_SG);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_886(1:1,1) = x(1:1);
x_894(1:1,1) = x(2:2);
x_911(1:6,1) = x(3:8);
x_890(1:1,1) = x(9:9);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        P_mech_in_PU = u{1};
        Q_req_in_PU = u{2};
        V_grid_mag_phi_PU = u{3};
    elseif isa(u,'struct')
        P_mech_in_PU = u.P_mech_in_PU;
        Q_req_in_PU = u.Q_req_in_PU;
        V_grid_mag_phi_PU = u.V_grid_mag_phi_PU;
    else
        P_mech_in_PU = zeros([1 1]);  P_mech_in_PU(:) = u(1:1);
        Q_req_in_PU = zeros([1 1]);  Q_req_in_PU(:) = u(2:2);
        V_grid_mag_phi_PU = zeros([2 1]);  V_grid_mag_phi_PU(:) = u(3:4);
    end
end

u_882_2 = Q_req_in_PU;        % Add1            <-- Q_req_in_PU     

% Constant Block 909 "PU Omega"
y_909 = 314.1593;
u_872_2 = y_909;              % Divide3         <-- PU Omega        
u_908_1 = P_mech_in_PU;       % Mux1            <-- P_mech_in_PU    
u_1036_1 = V_grid_mag_phi_PU; % S-Function1     <-- V_grid_mag_phi_PU 

% S-Function Block 1036 "S-Function1"
y_1036 = modl_magphi2vabc(t,[],u_1036_1,3,p_1036);

u_1120_1 = y_1036;            % Mux2            <-- S-Function1     
u_908_2 = y_1036;             % Mux1            <-- S-Function1     
u_1095_1 = y_1036;            % Mux             <-- S-Function1     

% S-Function Block 886 "Integrator"
y_886 = sfun_integrator(t,x_886,[],3,p_886_1,p_886_2);

u_883_2 = y_886;              % Add2            <-- Integrator      

% Constant Block 893 "Constant"
y_893 = 1;
u_899_2 = y_893;              % Sum1            <-- Constant        

% S-Function Block 894 "Integrator1"
y_894 = sfun_integrator(t,x_894,[],3,p_894_1,p_894_2);

u_1122_1 = y_894;             % Gain3           <-- Integrator1     
u_899_1 = y_894;              % Sum1            <-- Integrator1     

% Sum Block 899 "Sum1"
y_899 = + u_899_1 + u_899_2;

u_908_3 = y_899;              % Mux1            <-- Sum1            

% Mux Block 908 "Mux1"
y_908 = [u_908_1;u_908_2;u_908_3];

u_911_1 = y_908;              % S-Fun Synchron Generator <-- Mux1            

% S-Function Block 911 "S-Fun Synchron Generator"
y_911 = modl_SG(t,x_911,u_911_1,3,p_911);

u_917_1 = y_911;              % electrical Power1 <-- S-Fun Synchron Generator 
u_916_1 = y_911;              % electrical Power <-- S-Fun Synchron Generator 
u_918_1 = y_911;              % grid currents   <-- S-Fun Synchron Generator 

% Selector Block 917 "electrical Power1"
y_917 = u_917_1([5 6 7 8 9 10]);


u_915_1 = y_917;              % Selector        <-- electrical Power1 

% Selector Block 918 "grid currents"
y_918 = u_918_1([1 2 3]);


u_1120_2 = y_918;             % Mux2            <-- grid currents   
u_1124_1 = y_918;             % S-Function3     <-- grid currents   

% Selector Block 915 "Selector"
y_915 = u_915_1(1);


u_872_1 = y_915;              % Divide3         <-- Selector        

% Product Block 872 "Divide3"
y_872 = u_872_1./ u_872_2 ;

omega_in_PU = y_872;          % omega_in_PU     <-- Divide3         

% Selector Block 916 "electrical Power"
y_916 = u_916_1(4);



% Gain Block 1122 "Gain3"
y_1122 = 0.5*u_1122_1;


u_898_2 = y_1122;             % Sum             <-- Gain3           

% Mux Block 1120 "Mux2"
y_1120 = [u_1120_1;u_1120_2];

u_1119_1 = y_1120;            % S-Function2     <-- Mux2            

% S-Function Block 1119 "S-Function2"
y_1119 = modl_3phase_power(t,[],u_1119_1,3);

u_1121_1 = y_1119;            % Demux           <-- S-Function2     

% Demux Block 1121 "Demux"
y_1121_1 = u_1121_1(1);
y_1121_2 = u_1121_1(2);

u_877_1 = y_1121_2;           % Gain            <-- Demux           
Q_grid_in_PU = y_1121_2;      % Q_grid_in_PU    <-- Demux           
P_grid_in_PU = y_1121_1;      % P_grid_in_PU    <-- Demux           

% Gain Block 877 "Gain"
y_877 = 1*u_877_1;


u_882_1 = y_877;              % Add1            <-- Gain            

% Sum Block 882 "Add1"
y_882 = - u_882_1 + u_882_2;

u_885_1 = y_882;              % Gain1           <-- Add1            
u_884_1 = y_882;              % Gain2           <-- Add1            

% Gain Block 884 "Gain2"
y_884 = 0.5*u_884_1;


u_886_1 = y_884;              % Integrator      <-- Gain2           

% Gain Block 885 "Gain1"
y_885 = 2*u_885_1;


u_883_1 = y_885;              % Add2            <-- Gain1           

% Sum Block 883 "Add2"
y_883 = + u_883_1 + u_883_2;

u_1095_2 = y_883;             % Mux             <-- Add2            

% Mux Block 1095 "Mux"
y_1095 = [u_1095_1;u_1095_2];

u_1094_1 = y_1095;            % S-Function      <-- Mux             

% S-Function Block 1094 "S-Function"
y_1094 = modl_sg_deltav(t,[],u_1094_1,3);

u_890_1 = y_1094;             % Transfer Fcn    <-- S-Function      

% S-Function Block 890 "Transfer Fcn"
y_890 = tf_sfun(t,x_890,u_890_1,3,p_890_1,p_890_2,p_890_3,p_890_4);

u_898_1 = y_890;              % Sum             <-- Transfer Fcn    

% Sum Block 898 "Sum"
y_898 = + u_898_1 - u_898_2;

u_1123_1 = y_898;             % Gain4           <-- Sum             

% Gain Block 1123 "Gain4"
y_1123 = 40*u_1123_1;


u_894_1 = y_1123;             % Integrator1     <-- Gain4           

% S-Function Block 1124 "S-Function3"
y_1124 = modl_vabc2magphi(t,[],u_1124_1,3);

I_mag_phase_in_PU = y_1124;   % I_mag_phase_in_PU <-- S-Function3     

% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(9,1);
        
        % S-Function derivative call of "Integrator" (SID 886)
        dx(1:1) = sfun_integrator(t,x_886,u_886_1,1,p_886_1,p_886_2);
        
        % S-Function derivative call of "Integrator1" (SID 894)
        dx(2:2) = sfun_integrator(t,x_894,u_894_1,1,p_894_1,p_894_2);
        
        % S-Function derivative call of "S-Fun Synchron Generator" (SID 911)
        dx(3:8) = modl_SG(t,x_911,u_911_1,1,p_911);
        
        % S-Function derivative call of "Transfer Fcn" (SID 890)
        dx(9:9) = tf_sfun(t,x_890,u_890_1,1,p_890_1,p_890_2,p_890_3,p_890_4);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = P_grid_in_PU;
            y{2} = Q_grid_in_PU;
            y{3} = I_mag_phase_in_PU;
            y{4} = omega_in_PU;
        elseif flagout == 2
            y = struct();
            y.P_grid_in_PU = P_grid_in_PU;
            y.Q_grid_in_PU = Q_grid_in_PU;
            y.I_mag_phase_in_PU = I_mag_phase_in_PU;
            y.omega_in_PU = omega_in_PU;
        else
            y = [P_grid_in_PU(:);Q_grid_in_PU(:);I_mag_phase_in_PU(:);omega_in_PU(:);];
        end
        sys = y;
end

end % end of SPSecondary
