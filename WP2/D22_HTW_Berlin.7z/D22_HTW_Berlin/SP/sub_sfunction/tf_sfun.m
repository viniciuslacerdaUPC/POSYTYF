function [sys,x0,str,ts] = tf_sfun(~,x,u,flag,A,B,C,D)


switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes(A,B,C,D);
    case 1
        sys = mdlDerivatives(x,u,A,B);
    case 3
        sys = mdlOutputs(x,u,C,D);
    case { 2, 4, 9 }
        sys = [];
    otherwise
        DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end

    function [sys,x0,str,ts]=mdlInitializeSizes(A,B,C,D)
        sizes = simsizes;
        sizes.NumContStates  = size(A,1);
        sizes.NumDiscStates  = 0;
        sizes.NumOutputs     = size(C,1);
        sizes.NumInputs      = 1;
        if all(D(:) == 0)
            sizes.DirFeedthrough = 0;
        else
            sizes.DirFeedthrough = 1;
        end
        sizes.NumSampleTimes = 1;
        
        sys = simsizes(sizes);
        x0  = 0;
        str = [];
        ts  = [0 0];
    end


    function sys = mdlDerivatives(x,u,A,B)
        sys = A*x + B*u;
    end

    function sys = mdlOutputs(x,u,C,D)
        if all(D(:) == 0)
            sys = C*x;
        else
            sys = C*x + D*u;
        end
    end

end