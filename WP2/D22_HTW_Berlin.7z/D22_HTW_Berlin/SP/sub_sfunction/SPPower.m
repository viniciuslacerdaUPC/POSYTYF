%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = SPPower(t,x,u,flag,par_SG)

% BlockInfo, SysHandle (~) = Model.System.Block_15
%  SID  BlockHandle             BlockType               BlockName
%  872  ~.System.Block_18       Product                 Divide3
%  877  ~.System.Block_24       Gain                    Gain5
%  882  ~.System.Block_7        Sum                     Add1
%  883  ~.System.Block_8        Sum                     Add2
%  884  ~.System.Block_26       Gain                    Gain7
%  885  ~.System.Block_25       Gain                    Gain6
%  886  ~.System.Block_49       S-Function              Integrator7
%  887  ~.System.Block_73       Scope                   Scope4
%  889  ~.System.Block_69       Scope                   Scope Exciter Voltage
%  890  ~.System.Block_90       S-Function              Transfer Fcn
%  893  ~.System.Block_15       Constant                Constant6
%  894  ~.System.Block_50       S-Function              Integrator8
%  898  ~.System.Block_79       Sum                     Sum11
%  899  ~.System.Block_80       Sum                     Sum12
%  908  ~.System.Block_52       Mux                     Mux1
%  909  ~.System.Block_54       Constant                PU Omega
%  911  ~.System.Block_58       S-Function              S-Fun Synchron Generator
%  912  ~.System.Block_63       Scope                   SG P_mech\nSG P_grid\nSG Q_grid
%  913  ~.System.Block_64       Scope                   SG omega
%  914  ~.System.Block_65       Scope                   SG_P_grid
%  915  ~.System.Block_75       Selector                Selector
%  916  ~.System.Block_94       Selector                electrical Power
%  917  ~.System.Block_95       Selector                electrical Power1
%  918  ~.System.Block_101      Selector                grid currents
%  919  ~.System.Block_109      Scope                   sg_Q_grid
%  945  ~.System.Block_4        Gain                    1/Cf_oil
%  946  ~.System.Block_5        Gain                    A_f
%  947  ~.System.Block_6        Sum                     Add
%  948  ~.System.Block_9        Constant                Constant
%  949  ~.System.Block_10       Constant                Constant1
%  950  ~.System.Block_11       Constant                Constant2
%  951  ~.System.Block_12       Constant                Constant3
%  952  ~.System.Block_13       Constant                Constant4
%  953  ~.System.Block_14       Constant                Constant5
%  954  ~.System.Block_17       Product                 Divide
%  955  ~.System.Block_19       Gain                    Gain
%  956  ~.System.Block_20       Gain                    Gain1
%  957  ~.System.Block_21       Gain                    Gain2
%  958  ~.System.Block_22       Gain                    Gain3
%  959  ~.System.Block_28       Goto                    Goto
%  960  ~.System.Block_29       Goto                    Goto1
%  961  ~.System.Block_30       Goto                    Goto10
%  962  ~.System.Block_31       Goto                    Goto11
%  963  ~.System.Block_32       Goto                    Goto12
%  964  ~.System.Block_33       Goto                    Goto13
%  965  ~.System.Block_34       Goto                    Goto2
%  966  ~.System.Block_35       Goto                    Goto3
%  967  ~.System.Block_36       Goto                    Goto4
%  968  ~.System.Block_37       Goto                    Goto5
%  969  ~.System.Block_38       Goto                    Goto6
%  970  ~.System.Block_39       Goto                    Goto7
%  971  ~.System.Block_40       Goto                    Goto8
%  972  ~.System.Block_41       Goto                    Goto9
%  973  ~.System.Block_42       S-Function              Integrator
%  974  ~.System.Block_43       S-Function              Integrator1
%  975  ~.System.Block_44       S-Function              Integrator2
%  976  ~.System.Block_45       S-Function              Integrator3
%  977  ~.System.Block_46       S-Function              Integrator4
%  978  ~.System.Block_47       S-Function              Integrator5
%  979  ~.System.Block_48       S-Function              Integrator6
%  980  ~.System.Block_55       Product                 Product
%  981  ~.System.Block_56       Product                 Product1
%  982  ~.System.Block_57       Product                 Product2
%  983  ~.System.Block_66       Saturate                Saturation
%  984  ~.System.Block_67       Saturate                Saturation1
%  985  ~.System.Block_68       Scope                   Scope
%  986  ~.System.Block_70       Scope                   Scope1
%  987  ~.System.Block_71       Scope                   Scope2
%  988  ~.System.Block_72       Scope                   Scope3
%  989  ~.System.Block_76       Sum                     Sum
%  990  ~.System.Block_77       Sum                     Sum1
%  991  ~.System.Block_78       Sum                     Sum10
%  992  ~.System.Block_81       Sum                     Sum2
%  993  ~.System.Block_82       Sum                     Sum3
%  994  ~.System.Block_83       Sum                     Sum4
%  995  ~.System.Block_84       Sum                     Sum5
%  996  ~.System.Block_85       Sum                     Sum6
%  997  ~.System.Block_86       Sum                     Sum7
%  998  ~.System.Block_87       Sum                     Sum8
%  999  ~.System.Block_88       Sum                     Sum9
% 1000  ~.System.Block_89       Switch                  Switch to avoid x_s < x_s_min
% 1001  ~.System.Block_91       Gain                    [liter]->[m^3]
% 1002  ~.System.Block_92       Gain                    calc_pu
% 1003  ~.System.Block_93       Gain                    calc_pu1
% 1004  ~.System.Block_96       Gain                    eta_o
% 1005  ~.System.Block_97       Gain                    gamma_cp
% 1006  ~.System.Block_98       Gain                    gamma_cp1
% 1007  ~.System.Block_99       Gain                    gamma_cp2
% 1008  ~.System.Block_100      Gain                    gamma_cp_
% 1009  ~.System.Block_102      Gain                    k_ff
% 1010  ~.System.Block_103      Gain                    kp_1
% 1011  ~.System.Block_104      Gain                    kp_2
% 1012  ~.System.Block_105      Constant                omega_g_ref_pu
% 1013  ~.System.Block_106      Gain                    pu -> 1000 W/m^2 
% 1014  ~.System.Block_107      Gain                    pu -> W
% 1015  ~.System.Block_108      S-Function              pump model (pump with flow control )___
% 1016  ~.System.Block_110      Gain                    tau_ch
% 1017  ~.System.Block_111      Gain                    tau_p
% 1018  ~.System.Block_112      Gain                    tau_p1
% 1019  ~.System.Block_113      Gain                    tau_sv
% 1020  ~.System.Block_114      Constant                theta_in_c
% 1021  ~.System.Block_115      Constant                theta_out_ref
% 1022  ~.System.Block_116      Gain                    unit
% 1036  ~.System.Block_60       S-Function              S-Function1
% 1094  ~.System.Block_59       S-Function              S-Function
% 1095  ~.System.Block_51       Mux                     Mux
% 1119  ~.System.Block_61       S-Function              S-Function2
% 1120  ~.System.Block_53       Mux                     Mux2
% 1121  ~.System.Block_16       Demux                   Demux
% 1122  ~.System.Block_27       Gain                    Gain8
% 1123  ~.System.Block_23       Gain                    Gain4
% 1124  ~.System.Block_62       S-Function              S-Function3
% 1127  ~.System.Block_74       Scope                   Scope5
% 1129  ~                       SubSystem               SP Power
% 1130  ~.System.Block          Inport                  S_pu
% 1131  ~.System.Block_1        Inport                  P_ref_pu
% 1132  ~.System.Block_2        Inport                  Q_req_in_PU
% 1133  ~.System.Block_3        Inport                  V_grid_mag_phi_PU
% 1134  ~.System.Block_117      Outport                 P_grid_in_PU
% 1135  ~.System.Block_118      Outport                 Q_grid_in_PU
% 1136  ~.System.Block_119      Outport                 I_mag_phase_in_PU

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_973_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_973_2 = 120;
p_974_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_974_2 = 5;
p_975_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_975_2 = 0.5;
p_976_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_976_2 = 0.5;
p_977_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_977_2 = 2.08;
p_978_1 = [1 1 0 1 0 -Inf Inf 0 0 0.01];
p_978_2 = 0;
p_979_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_979_2 = 0;
p_886_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_886_2 = 1;
p_894_1 = [1 1 0 0 0 -Inf Inf 0 0 0.01];
p_894_2 = 0;
p_911 = par_SG;
p_1036 = 1.5707963267949;
p_890_1 = -0.1;
p_890_2 = 0.25;
p_890_3 = 0.28;
p_890_4 = 0.3;
p_1015_1 = -2;
p_1015_2 = 2;
p_1015_3 = 1;
p_1015_4 = 0;

% Initialisation
if flag == 0
    x0 = zeros(17,1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_973_1,p_973_2);
    x0(1:1) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_974_1,p_974_2);
    x0(2:2) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_975_1,p_975_2);
    x0(3:3) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_976_1,p_976_2);
    x0(4:4) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_977_1,p_977_2);
    x0(5:5) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_978_1,p_978_2);
    x0(6:6) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_979_1,p_979_2);
    x0(7:7) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_886_1,p_886_2);
    x0(8:8) = x0_temp(1:1);
    [~,x0_temp] = sfun_integrator([],[],[],0,p_894_1,p_894_2);
    x0(9:9) = x0_temp(1:1);
    [~,x0_temp] = modl_SG([],[],[],0,p_911);
    x0(10:15) = x0_temp(1:6);
    [~,x0_temp] = tf_sfun([],[],[],0,p_890_1,p_890_2,p_890_3,p_890_4);
    x0(16:16) = x0_temp(1:1);
    [~,x0_temp] = tf_sfun([],[],[],0,p_1015_1,p_1015_2,p_1015_3,p_1015_4);
    x0(17:17) = x0_temp(1:1);
    sys = [17 ,... % NumContStates
           0 ,... % NumDiscStates
           4 ,... % NumOutputs
           5 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 4;
    info.InportsVarName{1} = 'S_pu'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'P_ref_pu'; info.InportsDimension{2} = [1 1];
    info.InportsVarName{3} = 'Q_req_in_PU'; info.InportsDimension{3} = [1 1];
    info.InportsVarName{4} = 'V_grid_mag_phi_PU'; info.InportsDimension{4} = [2 1];
    info.NumOutports = 3;
    info.OutportsVarName{1} = 'P_grid_in_PU'; info.OutportsDimension{1} = [1 1];
    info.OutportsVarName{2} = 'Q_grid_in_PU'; info.OutportsDimension{2} = [1 1];
    info.OutportsVarName{3} = 'I_mag_phase_in_PU'; info.OutportsDimension{3} = [1 2];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:2,1) = u{2};
        u0(3:3,1) = u{3};
        u0(4:5,1) = u{4};
    elseif isa(u,'struct')
        u0(1:1,1) = u.S_pu;
        u0(2:2,1) = u.P_ref_pu;
        u0(3:3,1) = u.Q_req_in_PU;
        u0(4:5,1) = u.V_grid_mag_phi_PU;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)SPPower(t,x,u,flag,par_SG);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_973(1:1,1) = x(1:1);
x_974(1:1,1) = x(2:2);
x_975(1:1,1) = x(3:3);
x_976(1:1,1) = x(4:4);
x_977(1:1,1) = x(5:5);
x_978(1:1,1) = x(6:6);
x_979(1:1,1) = x(7:7);
x_886(1:1,1) = x(8:8);
x_894(1:1,1) = x(9:9);
x_911(1:6,1) = x(10:15);
x_890(1:1,1) = x(16:16);
x_1015(1:1,1) = x(17:17);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        S_pu = u{1};
        P_ref_pu = u{2};
        Q_req_in_PU = u{3};
        V_grid_mag_phi_PU = u{4};
    elseif isa(u,'struct')
        S_pu = u.S_pu;
        P_ref_pu = u.P_ref_pu;
        Q_req_in_PU = u.Q_req_in_PU;
        V_grid_mag_phi_PU = u.V_grid_mag_phi_PU;
    else
        S_pu = zeros([1 1]);  S_pu(:) = u(1:1);
        P_ref_pu = zeros([1 1]);  P_ref_pu(:) = u(2:2);
        Q_req_in_PU = zeros([1 1]);  Q_req_in_PU(:) = u(3:3);
        V_grid_mag_phi_PU = zeros([2 1]);  V_grid_mag_phi_PU(:) = u(4:5);
    end
end


% S-Function Block 979 "Integrator6"
y_979 = sfun_integrator(t,x_979,[],3,p_979_1,p_979_2);

u_957_1 = y_979;              % Gain2           <-- Integrator6     

% Gain Block 957 "Gain2"
y_957 = -0.0126*u_957_1;


u_991_2 = y_957;              % Sum10           <-- Gain2           

% Constant Block 953 "Constant5"
y_953 = 0;
u_978_2 = y_953;              % Integrator5     <-- Constant5       

% Constant Block 952 "Constant4"
y_952 = 2.08;
u_977_2 = y_952;              % Integrator4     <-- Constant4       

% Constant Block 951 "Constant3"
y_951 = 0.5;
u_976_2 = y_951;              % Integrator3     <-- Constant3       

% Constant Block 950 "Constant2"
y_950 = 0.5;
u_975_2 = y_950;              % Integrator2     <-- Constant2       

% S-Function Block 975 "Integrator2"
y_975 = sfun_integrator(t,x_975,[],3,p_975_1,p_975_2);

u_996_1 = y_975;              % Sum6            <-- Integrator2     
u_995_2 = y_975;              % Sum5            <-- Integrator2     

% S-Function Block 976 "Integrator3"
y_976 = sfun_integrator(t,x_976,[],3,p_976_1,p_976_2);

u_908_1 = y_976;              % Mux1            <-- Integrator3     
u_994_2 = y_976;              % Sum4            <-- Integrator3     
u_996_2 = y_976;              % Sum6            <-- Integrator3     

% Sum Block 996 "Sum6"
y_996 = + u_996_1 - u_996_2;

u_1016_1 = y_996;             % tau_ch          <-- Sum6            

% Gain Block 1016 "tau_ch"
y_1016 = 2*u_1016_1;


u_976_1 = y_1016;             % Integrator3     <-- tau_ch          

% S-Function Block 974 "Integrator1"
y_974 = sfun_integrator(t,x_974,[],3,p_974_1,p_974_2);

u_1000_2 = y_974;             % Switch to avoid x_s < x_s_min <-- Integrator1     

% Constant Block 949 "Constant1"
y_949 = 5;
u_974_2 = y_949;              % Integrator1     <-- Constant1       

% S-Function Block 977 "Integrator4"
y_977 = sfun_integrator(t,x_977,[],3,p_977_1,p_977_2);

u_982_2 = y_977;              % Product2        <-- Integrator4     
u_1000_1 = y_977;             % Switch to avoid x_s < x_s_min <-- Integrator4     
u_997_2 = y_977;              % Sum7            <-- Integrator4     

% S-Function Block 973 "Integrator"
y_973 = sfun_integrator(t,x_973,[],3,p_973_1,p_973_2);

u_947_1 = y_973;              % Add             <-- Integrator      
u_982_1 = y_973;              % Product2        <-- Integrator      
u_1022_1 = y_973;             % unit            <-- Integrator      
u_981_1 = y_973;              % Product1        <-- Integrator      
u_980_1 = y_973;              % Product         <-- Integrator      

% Product Block 982 "Product2"
y_982 =u_982_1 .* u_982_2;

u_1006_1 = y_982;             % gamma_cp1       <-- Product2        

% Gain Block 1006 "gamma_cp1"
y_1006 = 2400*u_1006_1;


u_1003_1 = y_1006;            % calc_pu1        <-- gamma_cp1       

% Gain Block 1003 "calc_pu1"
y_1003 = 8.3333e-07*u_1003_1;


u_955_1 = y_1003;             % Gain            <-- calc_pu1        

% Constant Block 948 "Constant"
y_948 = 120;
u_973_2 = y_948;              % Integrator      <-- Constant        

% S-Function Block 1015 "pump model (pump with flow control )___"
y_1015 = tf_sfun(t,x_1015,[],3,p_1015_1,p_1015_2,p_1015_3,p_1015_4);


% Gain Block 955 "Gain"
y_955 = 1*u_955_1;


u_995_1 = y_955;              % Sum5            <-- Gain            

% Sum Block 995 "Sum5"
y_995 = + u_995_1 - u_995_2;

u_1019_1 = y_995;             % tau_sv          <-- Sum5            

% Gain Block 1019 "tau_sv"
y_1019 = 5*u_1019_1;


u_975_1 = y_1019;             % Integrator2     <-- tau_sv          

% Gain Block 1022 "unit"
y_1022 = 1*u_1022_1;


u_1007_1 = y_1022;            % gamma_cp2       <-- unit            

% Gain Block 1007 "gamma_cp2"
y_1007 = 2400*u_1007_1;


u_954_2 = y_1007;             % Divide          <-- gamma_cp2       

% Constant Block 1021 "theta_out_ref"
y_1021 = 290;
u_999_2 = y_1021;             % Sum9            <-- theta_out_ref   
u_1013_1 = S_pu;              % pu -> 1000 W/m^2  <-- S_pu            

% Gain Block 1013 "pu -> 1000 W/m^2 "
y_1013 = 1000*u_1013_1;


u_1004_1 = y_1013;            % eta_o           <-- pu -> 1000 W/m^2  

% Gain Block 1004 "eta_o"
y_1004 = 0.8*u_1004_1;


u_946_1 = y_1004;             % A_f             <-- eta_o           

% Gain Block 946 "A_f"
y_946 = 1500*u_946_1;


u_989_1 = y_946;              % Sum             <-- A_f             

% S-Function Block 978 "Integrator5"
y_978 = sfun_integrator(t,x_978,[],3,p_978_1,p_978_2);

u_990_1 = y_978;              % Sum1            <-- Integrator5     
u_1000_3 = y_978;             % Switch to avoid x_s < x_s_min <-- Integrator5     
u_981_2 = y_978;              % Product1        <-- Integrator5     
u_980_2 = y_978;              % Product         <-- Integrator5     
u_998_2 = y_978;              % Sum8            <-- Integrator5     

% Switch Block 1000 "Switch to avoid x_s < x_s_min"
if u_1000_2 > 2
    y_1000 = u_1000_1;
else
    y_1000 = u_1000_3;
end

u_990_2 = y_1000;             % Sum1            <-- Switch to avoid x_s < x_s_min 

% Sum Block 990 "Sum1"
y_990 = + u_990_1 - u_990_2;

u_1001_1 = y_990;             % [liter]->[m^3]  <-- Sum1            

% Gain Block 1001 "[liter]->[m^3]"
y_1001 = 0.001*u_1001_1;


u_956_1 = y_1001;             % Gain1           <-- [liter]->[m^3]  

% Gain Block 956 "Gain1"
y_956 = 0.079577*u_956_1;


u_974_1 = y_956;              % Integrator1     <-- Gain1           

% Product Block 980 "Product"
y_980 =u_980_1 .* u_980_2;

u_1005_1 = y_980;             % gamma_cp        <-- Product         

% Gain Block 1005 "gamma_cp"
y_1005 = 2400*u_1005_1;


u_989_2 = y_1005;             % Sum             <-- gamma_cp        

% Sum Block 989 "Sum"
y_989 = + u_989_1 - u_989_2;

u_945_1 = y_989;              % 1/Cf_oil        <-- Sum             

% Gain Block 945 "1/Cf_oil"
y_945 = 4.1667e-07*u_945_1;


u_973_1 = y_945;              % Integrator      <-- 1/Cf_oil        

% Product Block 981 "Product1"
y_981 =u_981_1 .* u_981_2;

u_1008_1 = y_981;             % gamma_cp_       <-- Product1        

% Gain Block 1008 "gamma_cp_"
y_1008 = 2400*u_1008_1;


u_1002_1 = y_1008;            % calc_pu         <-- gamma_cp_       

% Gain Block 1002 "calc_pu"
y_1002 = 8.3333e-07*u_1002_1;



% Constant Block 1020 "theta_in_c"
y_1020 = 170;
u_947_2 = y_1020;             % Add             <-- theta_in_c      

% Sum Block 947 "Add"
y_947 = + u_947_1 + u_947_2;

u_999_1 = y_947;              % Sum9            <-- Add             

% Sum Block 999 "Sum9"
y_999 = - u_999_1 + u_999_2;

u_958_1 = y_999;              % Gain3           <-- Sum9            
u_979_1 = y_999;              % Integrator6     <-- Sum9            

% Gain Block 958 "Gain3"
y_958 = -0.63002*u_958_1;


u_991_1 = y_958;              % Sum10           <-- Gain3           

% Sum Block 991 "Sum10"
y_991 = + u_991_1 + u_991_2;

u_984_1 = y_991;              % Saturation1     <-- Sum10           

% Saturate Block 984 "Saturation1"
Lower_limit = 0.000000;
Upper_limit = 12.000000;
y_984 = min(Upper_limit,max(Lower_limit,u_984_1));

u_998_1 = y_984;              % Sum8            <-- Saturation1     
u_1015_1 = y_984;             % pump model (pump with flow control )___ <-- Saturation1     

% Sum Block 998 "Sum8"
y_998 = + u_998_1 - u_998_2;

u_1018_1 = y_998;             % tau_p1          <-- Sum8            

% Gain Block 1018 "tau_p1"
y_1018 = 2*u_1018_1;


u_978_1 = y_1018;             % Integrator5     <-- tau_p1          
u_994_1 = P_ref_pu;           % Sum4            <-- P_ref_pu        
u_1009_1 = P_ref_pu;          % k_ff            <-- P_ref_pu        

% Gain Block 1009 "k_ff"
y_1009 = 1*u_1009_1;


u_992_2 = y_1009;             % Sum2            <-- k_ff            

% Sum Block 994 "Sum4"
y_994 = + u_994_1 - u_994_2;

u_1011_1 = y_994;             % kp_2            <-- Sum4            

% Gain Block 1011 "kp_2"
y_1011 = 0.75*u_1011_1;


u_992_3 = y_1011;             % Sum2            <-- kp_2            

% Constant Block 1012 "omega_g_ref_pu"
y_1012 = 1;
u_993_1 = y_1012;             % Sum3            <-- omega_g_ref_pu  

% S-Function Block 894 "Integrator8"
y_894 = sfun_integrator(t,x_894,[],3,p_894_1,p_894_2);

u_1122_1 = y_894;             % Gain8           <-- Integrator8     
u_899_1 = y_894;              % Sum12           <-- Integrator8     

% Constant Block 893 "Constant6"
y_893 = 1;
u_899_2 = y_893;              % Sum12           <-- Constant6       

% Gain Block 1122 "Gain8"
y_1122 = 0.5*u_1122_1;


u_898_2 = y_1122;             % Sum11           <-- Gain8           

% S-Function Block 886 "Integrator7"
y_886 = sfun_integrator(t,x_886,[],3,p_886_1,p_886_2);

u_883_2 = y_886;              % Add2            <-- Integrator7     
u_1036_1 = V_grid_mag_phi_PU; % S-Function1     <-- V_grid_mag_phi_PU 

% Constant Block 909 "PU Omega"
y_909 = 314.1593;
u_872_2 = y_909;              % Divide3         <-- PU Omega        
u_882_2 = Q_req_in_PU;        % Add1            <-- Q_req_in_PU     

% S-Function Block 1036 "S-Function1"
y_1036 = modl_magphi2vabc(t,[],u_1036_1,3,p_1036);

u_1120_1 = y_1036;            % Mux2            <-- S-Function1     
u_908_2 = y_1036;             % Mux1            <-- S-Function1     
u_1095_1 = y_1036;            % Mux             <-- S-Function1     

% Sum Block 899 "Sum12"
y_899 = + u_899_1 + u_899_2;

u_908_3 = y_899;              % Mux1            <-- Sum12           

% Mux Block 908 "Mux1"
y_908 = [u_908_1;u_908_2;u_908_3];

u_911_1 = y_908;              % S-Fun Synchron Generator <-- Mux1            

% S-Function Block 911 "S-Fun Synchron Generator"
y_911 = modl_SG(t,x_911,u_911_1,3,p_911);

u_917_1 = y_911;              % electrical Power1 <-- S-Fun Synchron Generator 
u_916_1 = y_911;              % electrical Power <-- S-Fun Synchron Generator 
u_918_1 = y_911;              % grid currents   <-- S-Fun Synchron Generator 

% Selector Block 916 "electrical Power"
y_916 = u_916_1(4);



% Selector Block 918 "grid currents"
y_918 = u_918_1([1 2 3]);


u_1120_2 = y_918;             % Mux2            <-- grid currents   
u_1124_1 = y_918;             % S-Function3     <-- grid currents   

% S-Function Block 1124 "S-Function3"
y_1124 = modl_vabc2magphi(t,[],u_1124_1,3);

I_mag_phase_in_PU = y_1124;   % I_mag_phase_in_PU <-- S-Function3     

% Mux Block 1120 "Mux2"
y_1120 = [u_1120_1;u_1120_2];

u_1119_1 = y_1120;            % S-Function2     <-- Mux2            

% S-Function Block 1119 "S-Function2"
y_1119 = modl_3phase_power(t,[],u_1119_1,3);

u_1121_1 = y_1119;            % Demux           <-- S-Function2     

% Demux Block 1121 "Demux"
y_1121_1 = u_1121_1(1);
y_1121_2 = u_1121_1(2);

P_grid_in_PU = y_1121_1;      % P_grid_in_PU    <-- Demux           
u_877_1 = y_1121_2;           % Gain5           <-- Demux           
Q_grid_in_PU = y_1121_2;      % Q_grid_in_PU    <-- Demux           

% Gain Block 877 "Gain5"
y_877 = 1*u_877_1;


u_882_1 = y_877;              % Add1            <-- Gain5           

% Sum Block 882 "Add1"
y_882 = - u_882_1 + u_882_2;

u_885_1 = y_882;              % Gain6           <-- Add1            
u_884_1 = y_882;              % Gain7           <-- Add1            

% Gain Block 885 "Gain6"
y_885 = 2*u_885_1;


u_883_1 = y_885;              % Add2            <-- Gain6           

% Sum Block 883 "Add2"
y_883 = + u_883_1 + u_883_2;

u_1095_2 = y_883;             % Mux             <-- Add2            

% Mux Block 1095 "Mux"
y_1095 = [u_1095_1;u_1095_2];

u_1094_1 = y_1095;            % S-Function      <-- Mux             

% S-Function Block 1094 "S-Function"
y_1094 = modl_sg_deltav(t,[],u_1094_1,3);

u_890_1 = y_1094;             % Transfer Fcn    <-- S-Function      

% S-Function Block 890 "Transfer Fcn"
y_890 = tf_sfun(t,x_890,u_890_1,3,p_890_1,p_890_2,p_890_3,p_890_4);

u_898_1 = y_890;              % Sum11           <-- Transfer Fcn    

% Sum Block 898 "Sum11"
y_898 = + u_898_1 - u_898_2;

u_1123_1 = y_898;             % Gain4           <-- Sum11           

% Gain Block 1123 "Gain4"
y_1123 = 40*u_1123_1;


u_894_1 = y_1123;             % Integrator8     <-- Gain4           

% Gain Block 884 "Gain7"
y_884 = 0.5*u_884_1;


u_886_1 = y_884;              % Integrator7     <-- Gain7           

% Selector Block 917 "electrical Power1"
y_917 = u_917_1([5 6 7 8 9 10]);


u_915_1 = y_917;              % Selector        <-- electrical Power1 

% Selector Block 915 "Selector"
y_915 = u_915_1(1);


u_872_1 = y_915;              % Divide3         <-- Selector        

% Product Block 872 "Divide3"
y_872 = u_872_1./ u_872_2 ;

u_993_2 = y_872;              % Sum3            <-- Divide3         

% Sum Block 993 "Sum3"
y_993 = + u_993_1 - u_993_2;

u_1010_1 = y_993;             % kp_1            <-- Sum3            

% Gain Block 1010 "kp_1"
y_1010 = 20*u_1010_1;


u_992_1 = y_1010;             % Sum2            <-- kp_1            

% Sum Block 992 "Sum2"
y_992 = + u_992_1 + u_992_2 + u_992_3;

u_1014_1 = y_992;             % pu -> W         <-- Sum2            

% Gain Block 1014 "pu -> W"
y_1014 = 1200000*u_1014_1;


u_954_1 = y_1014;             % Divide          <-- pu -> W         

% Product Block 954 "Divide"
y_954 = u_954_1./ u_954_2 ;

u_983_1 = y_954;              % Saturation      <-- Divide          

% Saturate Block 983 "Saturation"
Lower_limit = 0.000000;
Upper_limit = 10.000000;
y_983 = min(Upper_limit,max(Lower_limit,u_983_1));

u_997_1 = y_983;              % Sum7            <-- Saturation      

% Sum Block 997 "Sum7"
y_997 = + u_997_1 - u_997_2;

u_1017_1 = y_997;             % tau_p           <-- Sum7            

% Gain Block 1017 "tau_p"
y_1017 = 2*u_1017_1;


u_977_1 = y_1017;             % Integrator4     <-- tau_p           

% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(17,1);
        
        % S-Function derivative call of "Integrator" (SID 973)
        in = [u_973_1;u_973_2];
        dx(1:1) = sfun_integrator(t,x_973,in,1,p_973_1,p_973_2);
        
        % S-Function derivative call of "Integrator1" (SID 974)
        in = [u_974_1;u_974_2];
        dx(2:2) = sfun_integrator(t,x_974,in,1,p_974_1,p_974_2);
        
        % S-Function derivative call of "Integrator2" (SID 975)
        in = [u_975_1;u_975_2];
        dx(3:3) = sfun_integrator(t,x_975,in,1,p_975_1,p_975_2);
        
        % S-Function derivative call of "Integrator3" (SID 976)
        in = [u_976_1;u_976_2];
        dx(4:4) = sfun_integrator(t,x_976,in,1,p_976_1,p_976_2);
        
        % S-Function derivative call of "Integrator4" (SID 977)
        in = [u_977_1;u_977_2];
        dx(5:5) = sfun_integrator(t,x_977,in,1,p_977_1,p_977_2);
        
        % S-Function derivative call of "Integrator5" (SID 978)
        in = [u_978_1;u_978_2];
        dx(6:6) = sfun_integrator(t,x_978,in,1,p_978_1,p_978_2);
        
        % S-Function derivative call of "Integrator6" (SID 979)
        dx(7:7) = sfun_integrator(t,x_979,u_979_1,1,p_979_1,p_979_2);
        
        % S-Function derivative call of "Integrator7" (SID 886)
        dx(8:8) = sfun_integrator(t,x_886,u_886_1,1,p_886_1,p_886_2);
        
        % S-Function derivative call of "Integrator8" (SID 894)
        dx(9:9) = sfun_integrator(t,x_894,u_894_1,1,p_894_1,p_894_2);
        
        % S-Function derivative call of "S-Fun Synchron Generator" (SID 911)
        dx(10:15) = modl_SG(t,x_911,u_911_1,1,p_911);
        
        % S-Function derivative call of "Transfer Fcn" (SID 890)
        dx(16:16) = tf_sfun(t,x_890,u_890_1,1,p_890_1,p_890_2,p_890_3,p_890_4);
        
        % S-Function derivative call of "pump model (pump with flow control )___" (SID 1015)
        dx(17:17) = tf_sfun(t,x_1015,u_1015_1,1,p_1015_1,p_1015_2,p_1015_3,p_1015_4);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = P_grid_in_PU;
            y{2} = Q_grid_in_PU;
            y{3} = I_mag_phase_in_PU;
        elseif flagout == 2
            y = struct();
            y.P_grid_in_PU = P_grid_in_PU;
            y.Q_grid_in_PU = Q_grid_in_PU;
            y.I_mag_phase_in_PU = I_mag_phase_in_PU;
        else
            y = [P_grid_in_PU(:);Q_grid_in_PU(:);I_mag_phase_in_PU(:);];
        end
        sys = y;
end

end % end of SPPower
