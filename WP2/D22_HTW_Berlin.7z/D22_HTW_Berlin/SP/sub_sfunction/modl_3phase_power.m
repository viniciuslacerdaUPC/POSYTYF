function [sys,x0,str,ts] = modl_3phase_power(~,~,u,flag)

switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes();
    case 3
        sys = mdlOutputs(u);
    case { 1, 2, 4, 9 }
        sys = [];
    otherwise
        DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end

end

function y = mdlOutputs(u)
v = u(1:3);
i = u(4:6);
P = sum(v.*i);
dv = [ v(2) - v(3) ; v(3) - v(1) ; v(1) - v(2) ];
Q = sum(i.*dv)/sqrt(3);
y = [P Q];
end

function [sys,x0,str,ts] = mdlInitializeSizes()
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 6;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0 = [];
str = [];
ts  = [0 0];

end