function [sys,x0,str,ts] = modl_grid(t,x,u,flag,par)

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes(par);
    case 1 % Calculate derivatives
        sys = mdlDerivatives(t,x,u,par);
    case 3 % Calculate outputs
        sys = mdlOutputs(t,x,u,par);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par)
        switch lower(par.method)
            case 'emt'
                x0 = par.x0;
            case 'rms'
                x0 = [];
            otherwise
                error('unknown method (rms, emt)');
        end
        sys = [ numel(x0) ,... % NumContStates
           0 ,... % NumDiscStates
           3 ,... % NumOutputs
           5 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
        ts = [0 0];
        str = [];
    end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(t,x,u,par)
        
        switch lower(par.method)
            case 'emt'
                iI = u(1:3)*par.Ib; % PU conversion
                dVmag_in_PU = u(4); 
                dVphi_in_PU = u(5); 
                
                omg = par.omg;
                phi = par.phi + dVphi_in_PU*2*pi;
                mag = ( 1 + dVmag_in_PU ) * par.mag;

                V2 = mag * [ sin(omg*t + phi) ; sin(omg*t + phi - 2/3*pi) ; sin(omg*t + phi + 2/3*pi) ];
                
                Rs = par.Rs;
                R = par.R;
                L = par.L;
                dx = ( - (Rs+R)*x - V2 + Rs*iI ) / L;
            case 'rms'
                dx = [];
            otherwise
                error('unknown method (rms, emt)');
        end

    end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(t,x,u,par)
        iI = u(1:3)*par.Ib; % PU conversion
        switch lower(par.method)
            case 'emt'
                Rs = par.Rs;
                i = x;
                is = iI - i;
                y = is*Rs;
            case 'rms'
                dVmag_in_PU = u(4); 
                dVphi_in_PU = u(5); 
                
                omg = par.omg;
                phi = par.phi + dVphi_in_PU*2*pi;
                mag = ( 1 + dVmag_in_PU ) * par.mag;

                V2 = mag * [ sin(omg*t + phi) ; sin(omg*t + phi - 2/3*pi) ; sin(omg*t + phi + 2/3*pi) ];
                v2_ab = par.T*V2;
                v2_ab = v2_ab(1)+1j*v2_ab(2);
                iI_ab = par.T*iI;
                iI_ab = iI_ab(1)+1j*iI_ab(2);
                
                Rs = par.Rs;
                R = par.R;
                L = par.L;
                
                i_ab = (Rs*iI_ab-v2_ab)/(Rs+R+1j*omg*L);
                
                vs_ab = Rs*(iI_ab-i_ab);
                
                y = par.T_ * [real(vs_ab);imag(vs_ab)];
            otherwise
                error('unknown method (rms, emt)');
        end
        y = y / par.Vb; % PU conversion
    end

end % end of modl_grid %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

