function plot_bode()

[file,path] = uigetfile('results\lin_*.mat');
if isequal(file,0)
    disp('User selected Cancel');
    return
else
    str = fullfile(path,file);
    disp(['User selected ', str]);
    S = load(str); lin = S.lin;
end

A = lin.A;
B = lin.B;
C = lin.C;
D = lin.D;

num_in = numel(lin.u0);
num_out = numel(lin.y0);
InportsVarName = sub_VarName(num_in,lin.InportsVarName,lin.InportsDimension);
OutportsVarName = sub_VarName(num_out,lin.OutportsVarName,lin.OutportsDimension);

figure('name',[file ': Eigenvalues']);
ew = eig(A);
plot(real(ew),imag(ew),'x','linewidth',3);

sys = ss(A,B,C,D);
omg = logspace(-3,5,500);
[mag,phase,wout] = bode(sys,omg);
x = (squeeze(wout));

figure('name',[file ': Magnitude']);
for i1 = 1:num_in
    
    for i2 = 1:num_out
        subplot(num_in+1,num_out+1,i2+1);
        axis off;
        text(0.5,0.5,{'To:' OutportsVarName{i2} },'Interpreter','none','FontWeight','bold','HorizontalAlignment','Center');
    end
    
    subplot(num_in+1,num_out+1,(i1-1+1)*(num_out+1)+1);
    axis off;
    text(0.5,0.5,{'From:' InportsVarName{i1} },'Interpreter','none','FontWeight','bold','HorizontalAlignment','Center');
    
    for i2 = 1:num_out
        subplot(num_in+1,num_out+1,(i1-1+1)*(num_out+1)+i2+1);
        y = 20*log10(squeeze(mag(i2,i1,:)));
        semilogx(x,y,'linewidth',2);

        grid on; grid minor;
        xlabel('\omega in rad/s');
        ylabel('Magnitude in dB');
        % title([InportsVarName{i1} ' ==> ' OutportsVarName{i2}],'interpreter','none');
    end
end

figure('name',[file ': Phase']);
for i1 = 1:num_in
    
    for i2 = 1:num_out
        subplot(num_in+1,num_out+1,i2+1);
        axis off;
        text(0.5,0.5,{'To:' OutportsVarName{i2} },'Interpreter','none','FontWeight','bold','HorizontalAlignment','Center');
    end
    
    subplot(num_in+1,num_out+1,(i1-1+1)*(num_out+1)+1);
    axis off;
    text(0.5,0.5,{'From:' InportsVarName{i1} },'Interpreter','none','FontWeight','bold','HorizontalAlignment','Center');
    
    for i2 = 1:num_out
        subplot(num_in+1,num_out+1,(i1-1+1)*(num_out+1)+i2+1);
        y = (squeeze(phase(i2,i1,:)));
        semilogx(x,y,'linewidth',2);

        grid on; grid minor;
        xlabel('\omega in rad/s');
        ylabel('Phase in deg');
        % title([InportsVarName{i1} ' ==> ' OutportsVarName{i2}],'interpreter','none');
    end
end

end




function VarTitle = sub_VarName(num,VarName,Dimension)
VarTitle = cell(1,num);
i1 = 1; % counter for total value number
i2 = 1; % counter for port number
i3 = 1; % counter for value number at each port
while i1 <= num
    if i3 > Dimension{i2}
        i2 = i2 + 1;
        i3 = 1;
    end
    if Dimension{i2} > 1
        VarTitle{i1} = [ VarName{i2} '(' num2str(i3) ')' ];
    else
        VarTitle{i1} = VarName{i2};
    end
    i1 = i1 + 1;
    i3 = i3 + 1;
end
end

