%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = PVPrimary(t,x,u,flag,par_PV)

% BlockInfo, SysHandle (~) = Model.System.Block_19
%  SID  BlockHandle             BlockType               BlockName
%   76  ~                       SubSystem               PV primary
%   77  ~.System.Block          Inport                  S_in_PU
%   78  ~.System.Block_1        Inport                  P_req_in_PU
%   79  ~.System.Block_2        Inport                  v_dc_in_PU
%   80  ~.System.Block_10       Product                 Divide
%   81  ~.System.Block_20       Constant                PU DC voltage
%   82  ~.System.Block_21       Constant                PU Irradtion
%   83  ~.System.Block_22       Constant                PU Power
%   84  ~.System.Block_23       Constant                PU Power1
%   93  ~.System.Block_7        S-Function              DCDC-converter
%   94  ~.System.Block_8        Demux                   Demux
%   95  ~.System.Block_16       Mux                     Mux2
%  104  ~.System.Block_6        S-Function              DCDC-Power
%  105  ~.System.Block_9        Demux                   Demux1
%  106  ~.System.Block_17       Mux                     Mux3
%  113  ~.System.Block_15       Mux                     Mux1
%  114  ~.System.Block_24       S-Function              PV-array
%  119  ~.System.Block_14       Mux                     Mux
%  120  ~.System.Block_25       S-Function              PV-array heat model
%  122  ~.System.Block_30       Product                 Product3
%  123  ~.System.Block_34       Terminator              Terminator
%  128  ~.System.Block_19       Mux                     Mux5
%  129  ~.System.Block_32       S-Function              S-Function1
%  130  ~.System.Block_35       S-Function              Transfer Fcn
%  135  ~.System.Block_3        Constant                Constant
%  136  ~.System.Block_4        Constant                Constant3
%  137  ~.System.Block_5        Constant                Constant4
%  138  ~.System.Block_11       Product                 Divide1
%  139  ~.System.Block_12       Sum                     Minus
%  140  ~.System.Block_13       Sum                     Minus1
%  141  ~.System.Block_33       Scope                   Scope D_controller/D_feedforward
%  143  ~.System.Block_36       Scope                   temperature
%  150  ~.System.Block_18       Mux                     Mux4
%  151  ~.System.Block_31       S-Function              S-Function
%  154  ~.System.Block_26       Scope                   PV_P_DC
%  155  ~.System.Block_27       Product                 Product
%  156  ~.System.Block_28       Product                 Product1
%  157  ~.System.Block_29       Product                 Product2
%  158  ~.System.Block_37       Outport                 P_dc_in_PU

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_104 = par_PV;
p_93 = par_PV;
p_114 = par_PV;
p_120 = par_PV;
p_151 = par_PV;
p_129 = par_PV;
p_130_1 = -100;
p_130_2 = 8;
p_130_3 = 12.5;
p_130_4 = 0;

% Initialisation
if flag == 0
    x0 = zeros(5,1);
    [~,x0_temp] = sfun_dcdc_converter([],[],[],0,p_93);
    x0(1:2) = x0_temp(1:2);
    [~,x0_temp] = sfun_SDM_heat([],[],[],0,p_120);
    x0(3:3) = x0_temp(1:1);
    [~,x0_temp] = sfun_cntrl_vpv_TS([],[],[],0,p_151);
    x0(4:4) = x0_temp(1:1);
    [~,x0_temp] = tf_sfun([],[],[],0,p_130_1,p_130_2,p_130_3,p_130_4);
    x0(5:5) = x0_temp(1:1);
    sys = [5 ,... % NumContStates
           0 ,... % NumDiscStates
           1 ,... % NumOutputs
           3 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 3;
    info.InportsVarName{1} = 'S_in_PU'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'P_req_in_PU'; info.InportsDimension{2} = [1 1];
    info.InportsVarName{3} = 'v_dc_in_PU'; info.InportsDimension{3} = [1 1];
    info.NumOutports = 1;
    info.OutportsVarName{1} = 'P_dc_in_PU'; info.OutportsDimension{1} = [1 1];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:2,1) = u{2};
        u0(3:3,1) = u{3};
    elseif isa(u,'struct')
        u0(1:1,1) = u.S_in_PU;
        u0(2:2,1) = u.P_req_in_PU;
        u0(3:3,1) = u.v_dc_in_PU;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)PVPrimary(t,x,u,flag,par_PV);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_93(1:2,1) = x(1:2);
x_120(1:1,1) = x(3:3);
x_151(1:1,1) = x(4:4);
x_130(1:1,1) = x(5:5);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        S_in_PU = u{1};
        P_req_in_PU = u{2};
        v_dc_in_PU = u{3};
    elseif isa(u,'struct')
        S_in_PU = u.S_in_PU;
        P_req_in_PU = u.P_req_in_PU;
        v_dc_in_PU = u.v_dc_in_PU;
    else
        S_in_PU = zeros([1 1]);  S_in_PU(:) = u(1:1);
        P_req_in_PU = zeros([1 1]);  P_req_in_PU(:) = u(2:2);
        v_dc_in_PU = zeros([1 1]);  v_dc_in_PU(:) = u(3:3);
    end
end

u_156_1 = S_in_PU;            % Product1        <-- S_in_PU         
u_157_1 = P_req_in_PU;        % Product2        <-- P_req_in_PU     

% Constant Block 82 "PU Irradtion"
y_82 = 1000;
u_156_2 = y_82;               % Product1        <-- PU Irradtion    

% Constant Block 84 "PU Power1"
y_84 = 3000000;
u_157_2 = y_84;               % Product2        <-- PU Power1       
u_155_1 = v_dc_in_PU;         % Product         <-- v_dc_in_PU      

% Constant Block 81 "PU DC voltage"
y_81 = 5400;
u_155_2 = y_81;               % Product         <-- PU DC voltage   

% Constant Block 83 "PU Power"
y_83 = 3000000;
u_80_2 = y_83;                % Divide          <-- PU Power        

% S-Function Block 130 "Transfer Fcn"
y_130 = tf_sfun(t,x_130,[],3,p_130_1,p_130_2,p_130_3,p_130_4);

u_150_1 = y_130;              % Mux4            <-- Transfer Fcn    
u_138_1 = y_130;              % Divide1         <-- Transfer Fcn    

% S-Function Block 120 "PV-array heat model"
y_120 = sfun_SDM_heat(t,x_120,[],3,p_120);

u_128_2 = y_120;              % Mux5            <-- PV-array heat model 
u_150_5 = y_120;              % Mux4            <-- PV-array heat model 
u_113_3 = y_120;              % Mux1            <-- PV-array heat model 

% Product Block 156 "Product1"
y_156 =u_156_1 .* u_156_2;

u_113_2 = y_156;              % Mux1            <-- Product1        
u_119_1 = y_156;              % Mux             <-- Product1        
u_128_1 = y_156;              % Mux5            <-- Product1        
u_150_4 = y_156;              % Mux4            <-- Product1        

% Product Block 155 "Product"
y_155 =u_155_1 .* u_155_2;

u_106_3 = y_155;              % Mux3            <-- Product         
u_95_1 = y_155;               % Mux2            <-- Product         

% S-Function Block 93 "DCDC-converter"
y_93 = sfun_dcdc_converter(t,x_93,[],3,p_93);

u_94_1 = y_93;                % Demux           <-- DCDC-converter  

% Demux Block 94 "Demux"
y_94_1 = u_94_1(1);
y_94_2 = u_94_1(2);

u_150_3 = y_94_2;             % Mux4            <-- Demux           
u_106_4 = y_94_2;             % Mux3            <-- Demux           
u_106_1 = y_94_1;             % Mux3            <-- Demux           
u_113_1 = y_94_1;             % Mux1            <-- Demux           
u_122_2 = y_94_1;             % Product3        <-- Demux           
u_150_2 = y_94_1;             % Mux4            <-- Demux           

% Mux Block 113 "Mux1"
y_113 = [u_113_1;u_113_2;u_113_3];

u_114_1 = y_113;              % PV-array        <-- Mux1            

% S-Function Block 114 "PV-array"
y_114 = sfun_SDM_cells(t,[],u_114_1,3,p_114);

u_122_1 = y_114;              % Product3        <-- PV-array        
u_106_2 = y_114;              % Mux3            <-- PV-array        
u_95_2 = y_114;               % Mux2            <-- PV-array        

% Product Block 122 "Product3"
y_122 =u_122_1 .* u_122_2;

u_119_2 = y_122;              % Mux             <-- Product3        

% Mux Block 119 "Mux"
y_119 = [u_119_1;u_119_2];

u_120_1 = y_119;              % PV-array heat model <-- Mux             

% Constant Block 135 "Constant"
y_135 = 1;
u_139_1 = y_135;              % Minus           <-- Constant        

% Constant Block 137 "Constant4"
y_137 = 5400;
u_138_2 = y_137;              % Divide1         <-- Constant4       

% Product Block 138 "Divide1"
y_138 = u_138_1./ u_138_2 ;

u_139_2 = y_138;              % Minus           <-- Divide1         

% Sum Block 139 "Minus"
y_139 = + u_139_1 - u_139_2;

u_140_2 = y_139;              % Minus1          <-- Minus           

% Constant Block 136 "Constant3"
y_136 = 0.8515;
u_140_3 = y_136;              % Minus1          <-- Constant3       

% Mux Block 150 "Mux4"
y_150 = [u_150_1;u_150_2;u_150_3;u_150_4;u_150_5];

u_151_1 = y_150;              % S-Function      <-- Mux4            

% S-Function Block 151 "S-Function"
y_151 = sfun_cntrl_vpv_TS(t,x_151,u_151_1,3,p_151);

u_140_1 = y_151;              % Minus1          <-- S-Function      

% Sum Block 140 "Minus1"
y_140 = + u_140_1 + u_140_2 - u_140_3;

u_95_3 = y_140;               % Mux2            <-- Minus1          
u_106_5 = y_140;              % Mux3            <-- Minus1          

% Mux Block 95 "Mux2"
y_95 = [u_95_1;u_95_2;u_95_3];

u_93_1 = y_95;                % DCDC-converter  <-- Mux2            

% Mux Block 106 "Mux3"
y_106 = [u_106_1;u_106_2;u_106_3;u_106_4;u_106_5];

u_104_1 = y_106;              % DCDC-Power      <-- Mux3            

% S-Function Block 104 "DCDC-Power"
y_104 = sfun_dcdc_power(t,[],u_104_1,3,p_104);

u_105_1 = y_104;              % Demux1          <-- DCDC-Power      

% Demux Block 105 "Demux1"
y_105_1 = u_105_1(1);
y_105_2 = u_105_1(2);

u_80_1 = y_105_2;             % Divide          <-- Demux1          

% Product Block 80 "Divide"
y_80 = u_80_1./ u_80_2 ;

P_dc_in_PU = y_80;            % P_dc_in_PU      <-- Divide          

% Product Block 157 "Product2"
y_157 =u_157_1 .* u_157_2;

u_128_3 = y_157;              % Mux5            <-- Product2        

% Mux Block 128 "Mux5"
y_128 = [u_128_1;u_128_2;u_128_3];

u_129_1 = y_128;              % S-Function1     <-- Mux5            

% S-Function Block 129 "S-Function1"
y_129 = sfun_cntrl_mppt_exact(t,[],u_129_1,3,p_129);

u_130_1 = y_129;              % Transfer Fcn    <-- S-Function1     

% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(5,1);
        
        % S-Function derivative call of "DCDC-converter" (SID 93)
        dx(1:2) = sfun_dcdc_converter(t,x_93,u_93_1,1,p_93);
        
        % S-Function derivative call of "PV-array heat model" (SID 120)
        dx(3:3) = sfun_SDM_heat(t,x_120,u_120_1,1,p_120);
        
        % S-Function derivative call of "S-Function" (SID 151)
        dx(4:4) = sfun_cntrl_vpv_TS(t,x_151,u_151_1,1,p_151);
        
        % S-Function derivative call of "Transfer Fcn" (SID 130)
        dx(5:5) = tf_sfun(t,x_130,u_130_1,1,p_130_1,p_130_2,p_130_3,p_130_4);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = P_dc_in_PU;
        elseif flagout == 2
            y = struct();
            y.P_dc_in_PU = P_dc_in_PU;
        else
            y = P_dc_in_PU;
        end
        sys = y;
end

end % end of PVPrimary
