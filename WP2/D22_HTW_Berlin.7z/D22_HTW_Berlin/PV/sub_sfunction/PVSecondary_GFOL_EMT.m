%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = PVSecondary(t,x,u,flag,par_INV)

% BlockInfo, SysHandle (~) = Model.System.Block_25
%  SID  BlockHandle             BlockType               BlockName
%   24  ~                       SubSystem               PV secondary
%   25  ~.System.Block          Inport                  P_DC_in_PU
%   26  ~.System.Block_1        Inport                  v_grid_abc_in_PU
%   27  ~.System.Block_2        Inport                  Q_req_in_PU
%   28  ~.System.Block_4        Product                 Divide1
%   29  ~.System.Block_5        Product                 Divide2
%   30  ~.System.Block_6        Product                 Divide3
%   31  ~.System.Block_7        Product                 Divide4
%   32  ~.System.Block_8        Product                 Divide5
%   33  ~.System.Block_11       Scope                   INV_P_grid / INV_Q_grid / Q_GRID
%   34  ~.System.Block_12       Scope                   INV_i_filter
%   35  ~.System.Block_14       Scope                   INV_v_grid_abc
%   40  ~.System.Block_3        Demux                   Demux
%   41  ~.System.Block_9        Gain                    Gain1
%   42  ~.System.Block_10       Scope                   I filter abc
%   43  ~.System.Block_13       Scope                   INV_omega_PLL
%   44  ~.System.Block_15       Mux                     Mux
%   45  ~.System.Block_16       Mux                     Mux1
%   46  ~.System.Block_17       Mux                     Mux2
%   47  ~.System.Block_18       Mux                     Mux3
%   48  ~.System.Block_25       Scope                   P_grid / Q_grod
%   49  ~.System.Block_29       S-Function              S-Function
%   50  ~.System.Block_33       S-Function              S-Function4
%   51  ~.System.Block_34       S-Function              S-Function5
%   52  ~.System.Block_35       S-Function              S-Function6
%   53  ~.System.Block_36       Terminator              Terminator
%   54  ~.System.Block_37       Selector                V abc 
%   55  ~.System.Block_38       Scope                   inv_v_DC
%   56  ~.System.Block_39       Scope                   inv_v_terminal_abc
%   57  ~.System.Block_40       Selector                omega PLL in PU
%   58  ~.System.Block_41       Selector                states
%   64  ~.System.Block_19       Constant                PU Current
%   65  ~.System.Block_20       Constant                PU Current1
%   66  ~.System.Block_21       Constant                PU Power
%   67  ~.System.Block_22       Constant                PU Power1
%   68  ~.System.Block_23       Constant                PU Voltage
%   69  ~.System.Block_24       Constant                PU Voltage1
%   70  ~.System.Block_26       Product                 Product1
%   71  ~.System.Block_27       Product                 Product2
%   72  ~.System.Block_28       Product                 Product3
%   73  ~.System.Block_30       S-Function              S-Function1
%   74  ~.System.Block_31       S-Function              S-Function2
%   75  ~.System.Block_32       S-Function              S-Function3
%   76  ~.System.Block_42       Outport                 P_grid_in_PU
%   77  ~.System.Block_43       Outport                 Q_grid_in_PU
%   78  ~.System.Block_44       Outport                 I_mag_phase_in_PU
%   79  ~.System.Block_45       Outport                 v_terminal_mag_pahse_PU
%   80  ~.System.Block_46       Outport                 v_DC_in_PU

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_73 = 1.5707963267949;
p_50 = par_INV;
p_51 = par_INV;
p_52 = par_INV;

% Initialisation
if flag == 0
    x0 = zeros(13,1);
    [~,x0_temp] = sfun_capacitor([],[],[],0,p_50);
    x0(1:1) = x0_temp(1:1);
    [~,x0_temp] = sFunc_converter([],[],[],0,p_51);
    x0(2:10) = x0_temp(1:9);
    [~,x0_temp] = modl_filter([],[],[],0,p_52);
    x0(11:13) = x0_temp(1:3);
    sys = [13 ,... % NumContStates
           0 ,... % NumDiscStates
           7 ,... % NumOutputs
           4 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 3;
    info.InportsVarName{1} = 'P_DC_in_PU'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'v_grid_abc_in_PU'; info.InportsDimension{2} = [2 1];
    info.InportsVarName{3} = 'Q_req_in_PU'; info.InportsDimension{3} = [1 1];
    info.NumOutports = 5;
    info.OutportsVarName{1} = 'P_grid_in_PU'; info.OutportsDimension{1} = [1 1];
    info.OutportsVarName{2} = 'Q_grid_in_PU'; info.OutportsDimension{2} = [1 1];
    info.OutportsVarName{3} = 'I_mag_phase_in_PU'; info.OutportsDimension{3} = [1 2];
    info.OutportsVarName{4} = 'v_terminal_mag_pahse_PU'; info.OutportsDimension{4} = [1 2];
    info.OutportsVarName{5} = 'v_DC_in_PU'; info.OutportsDimension{5} = [1 1];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:3,1) = u{2};
        u0(4:4,1) = u{3};
    elseif isa(u,'struct')
        u0(1:1,1) = u.P_DC_in_PU;
        u0(2:3,1) = u.v_grid_abc_in_PU;
        u0(4:4,1) = u.Q_req_in_PU;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)PVSecondary(t,x,u,flag,par_INV);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_50(1:1,1) = x(1:1);
x_51(1:9,1) = x(2:10);
x_52(1:3,1) = x(11:13);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        P_DC_in_PU = u{1};
        v_grid_abc_in_PU = u{2};
        Q_req_in_PU = u{3};
    elseif isa(u,'struct')
        P_DC_in_PU = u.P_DC_in_PU;
        v_grid_abc_in_PU = u.v_grid_abc_in_PU;
        Q_req_in_PU = u.Q_req_in_PU;
    else
        P_DC_in_PU = zeros([1 1]);  P_DC_in_PU(:) = u(1:1);
        v_grid_abc_in_PU = zeros([2 1]);  v_grid_abc_in_PU(:) = u(2:3);
        Q_req_in_PU = zeros([1 1]);  Q_req_in_PU(:) = u(4:4);
    end
end


% Constant Block 64 "PU Current"
y_64 = 1234.5679;
u_31_2 = y_64;                % Divide4         <-- PU Current      
u_73_1 = v_grid_abc_in_PU;    % S-Function1     <-- v_grid_abc_in_PU 

% Constant Block 68 "PU Voltage"
y_68 = 2700;
u_70_2 = y_68;                % Product1        <-- PU Voltage      

% Constant Block 66 "PU Power"
y_66 = 5000000;
u_72_2 = y_66;                % Product3        <-- PU Power        
u_71_2 = y_66;                % Product2        <-- PU Power        
u_71_1 = P_DC_in_PU;          % Product2        <-- P_DC_in_PU      

% Constant Block 67 "PU Power1"
y_67 = 5000000;
u_29_2 = y_67;                % Divide2         <-- PU Power1       
u_28_2 = y_67;                % Divide1         <-- PU Power1       

% Constant Block 69 "PU Voltage1"
y_69 = 2700;
u_30_2 = y_69;                % Divide3         <-- PU Voltage1     
u_72_1 = Q_req_in_PU;         % Product3        <-- Q_req_in_PU     

% Constant Block 65 "PU Current1"
y_65 = 5400;
u_32_2 = y_65;                % Divide5         <-- PU Current1     

% S-Function Block 73 "S-Function1"
y_73 = modl_magphi2vabc(t,[],u_73_1,3,p_73);

u_70_1 = y_73;                % Product1        <-- S-Function1     

% Product Block 72 "Product3"
y_72 =u_72_1 .* u_72_2;

u_46_5 = y_72;                % Mux2            <-- Product3        

% Product Block 70 "Product1"
y_70 =u_70_1 .* u_70_2;

u_47_1 = y_70;                % Mux3            <-- Product1        
u_44_2 = y_70;                % Mux             <-- Product1        
u_46_3 = y_70;                % Mux2            <-- Product1        

% Product Block 71 "Product2"
y_71 =u_71_1 .* u_71_2;

u_45_1 = y_71;                % Mux1            <-- Product2        
u_46_1 = y_71;                % Mux2            <-- Product2        

% S-Function Block 52 "S-Function6"
y_52 = modl_filter(t,x_52,[],3,p_52);

u_31_1 = y_52;                % Divide4         <-- S-Function6     
u_47_2 = y_52;                % Mux3            <-- S-Function6     
u_46_4 = y_52;                % Mux2            <-- S-Function6     

% Product Block 31 "Divide4"
y_31 = u_31_1./ u_31_2 ;

u_75_1 = y_31;                % S-Function3     <-- Divide4         

% S-Function Block 75 "S-Function3"
y_75 = modl_vabc2magphi(t,[],u_75_1,3);

I_mag_phase_in_PU = y_75;     % I_mag_phase_in_PU <-- S-Function3     

% Mux Block 47 "Mux3"
y_47 = [u_47_1;u_47_2];

u_49_1 = y_47;                % S-Function      <-- Mux3            

% S-Function Block 49 "S-Function"
y_49 = modl_3phase_power(t,[],u_49_1,3);

u_40_1 = y_49;                % Demux           <-- S-Function      

% Demux Block 40 "Demux"
y_40_1 = u_40_1(1);
y_40_2 = u_40_1(2);

u_29_1 = y_40_2;              % Divide2         <-- Demux           

% Product Block 29 "Divide2"
y_29 = u_29_1./ u_29_2 ;

Q_grid_in_PU = y_29;          % Q_grid_in_PU    <-- Divide2         
u_28_1 = y_40_1;              % Divide1         <-- Demux           
u_41_1 = y_40_1;              % Gain1           <-- Demux           

% Product Block 28 "Divide1"
y_28 = u_28_1./ u_28_2 ;

P_grid_in_PU = y_28;          % P_grid_in_PU    <-- Divide1         

% S-Function Block 50 "S-Function4"
y_50 = sfun_capacitor(t,x_50,[],3,p_50);

u_32_1 = y_50;                % Divide5         <-- S-Function4     
u_46_2 = y_50;                % Mux2            <-- S-Function4     

% Product Block 32 "Divide5"
y_32 = u_32_1./ u_32_2 ;

v_DC_in_PU = y_32;            % v_DC_in_PU      <-- Divide5         

% Mux Block 46 "Mux2"
y_46 = [u_46_1;u_46_2;u_46_3;u_46_4;u_46_5];

u_51_1 = y_46;                % S-Function5     <-- Mux2            

% S-Function Block 51 "S-Function5"
y_51 = sFunc_converter(t,x_51,u_51_1,3,p_51);

u_58_1 = y_51;                % states          <-- S-Function5     
u_57_1 = y_51;                % omega PLL in PU <-- S-Function5     
u_54_1 = y_51;                % V abc           <-- S-Function5     

% Selector Block 58 "states"
y_58 = u_58_1([1 2 3 4 5 6 7 8 9]);



% Selector Block 57 "omega PLL in PU"
y_57 = u_57_1(10);



% Selector Block 54 "V abc "
y_54 = u_54_1([11 12 13]);


u_30_1 = y_54;                % Divide3         <-- V abc           
u_44_1 = y_54;                % Mux             <-- V abc           

% Product Block 30 "Divide3"
y_30 = u_30_1./ u_30_2 ;

u_74_1 = y_30;                % S-Function2     <-- Divide3         

% S-Function Block 74 "S-Function2"
y_74 = modl_vabc2magphi(t,[],u_74_1,3);

v_terminal_mag_pahse_PU = y_74;% v_terminal_mag_pahse_PU <-- S-Function2     

% Mux Block 44 "Mux"
y_44 = [u_44_1;u_44_2];

u_52_1 = y_44;                % S-Function6     <-- Mux             

% Gain Block 41 "Gain1"
y_41 = -1*u_41_1;


u_45_2 = y_41;                % Mux1            <-- Gain1           

% Mux Block 45 "Mux1"
y_45 = [u_45_1;u_45_2];

u_50_1 = y_45;                % S-Function4     <-- Mux1            

% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(13,1);
        
        % S-Function derivative call of "S-Function4" (SID 50)
        dx(1:1) = sfun_capacitor(t,x_50,u_50_1,1,p_50);
        
        % S-Function derivative call of "S-Function5" (SID 51)
        dx(2:10) = sFunc_converter(t,x_51,u_51_1,1,p_51);
        
        % S-Function derivative call of "S-Function6" (SID 52)
        dx(11:13) = modl_filter(t,x_52,u_52_1,1,p_52);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = P_grid_in_PU;
            y{2} = Q_grid_in_PU;
            y{3} = I_mag_phase_in_PU;
            y{4} = v_terminal_mag_pahse_PU;
            y{5} = v_DC_in_PU;
        elseif flagout == 2
            y = struct();
            y.P_grid_in_PU = P_grid_in_PU;
            y.Q_grid_in_PU = Q_grid_in_PU;
            y.I_mag_phase_in_PU = I_mag_phase_in_PU;
            y.v_terminal_mag_pahse_PU = v_terminal_mag_pahse_PU;
            y.v_DC_in_PU = v_DC_in_PU;
        else
            y = [P_grid_in_PU(:);Q_grid_in_PU(:);I_mag_phase_in_PU(:);v_terminal_mag_pahse_PU(:);v_DC_in_PU(:);];
        end
        sys = y;
end

end % end of PVSecondary
