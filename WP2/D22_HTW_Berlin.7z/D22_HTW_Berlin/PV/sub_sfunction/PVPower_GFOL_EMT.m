%% automatic generated Level 1 S-Function
function [sys,x0,info,ts] = PVPower(t,x,u,flag,par_INV,par_PV)

% BlockInfo, SysHandle (~) = Model.System.Block_25
%  SID  BlockHandle             BlockType               BlockName
%   28  ~.System.Block_18       Product                 Divide6
%   29  ~.System.Block_14       Product                 Divide2
%   30  ~.System.Block_15       Product                 Divide3
%   31  ~.System.Block_16       Product                 Divide4
%   32  ~.System.Block_17       Product                 Divide5
%   33  ~.System.Block_21       Scope                   INV_P_grid / INV_Q_grid / Q_GRID
%   34  ~.System.Block_22       Scope                   INV_i_filter
%   35  ~.System.Block_24       Scope                   INV_v_grid_abc
%   40  ~.System.Block_11       Demux                   Demux2
%   41  ~.System.Block_19       Gain                    Gain1
%   42  ~.System.Block_20       Scope                   I filter abc
%   43  ~.System.Block_23       Scope                   INV_omega_PLL
%   44  ~.System.Block_33       Mux                     Mux6
%   45  ~.System.Block_34       Mux                     Mux7
%   46  ~.System.Block_35       Mux                     Mux8
%   47  ~.System.Block_36       Mux                     Mux9
%   48  ~.System.Block_50       Scope                   P_grid / Q_grod
%   49  ~.System.Block_65       S-Function              S-Function7
%   50  ~.System.Block_62       S-Function              S-Function4
%   51  ~.System.Block_63       S-Function              S-Function5
%   52  ~.System.Block_64       S-Function              S-Function6
%   53  ~.System.Block_69       Terminator              Terminator1
%   54  ~.System.Block_71       Selector                V abc 
%   55  ~.System.Block_72       Scope                   inv_v_DC
%   56  ~.System.Block_73       Scope                   inv_v_terminal_abc
%   57  ~.System.Block_74       Selector                omega PLL in PU
%   58  ~.System.Block_75       Selector                states
%   64  ~.System.Block_37       Constant                PU Current
%   65  ~.System.Block_38       Constant                PU Current1
%   66  ~.System.Block_43       Constant                PU Power2
%   67  ~.System.Block_44       Constant                PU Power3
%   68  ~.System.Block_45       Constant                PU Voltage
%   69  ~.System.Block_46       Constant                PU Voltage1
%   70  ~.System.Block_55       Product                 Product4
%   71  ~.System.Block_56       Product                 Product5
%   72  ~.System.Block_57       Product                 Product6
%   73  ~.System.Block_66       S-Function              S-Function8
%   74  ~.System.Block_60       S-Function              S-Function2
%   75  ~.System.Block_61       S-Function              S-Function3
%   85  ~.System.Block_12       Product                 Divide
%   86  ~.System.Block_39       Constant                PU DC voltage
%   87  ~.System.Block_40       Constant                PU Irradtion
%   88  ~.System.Block_41       Constant                PU Power
%   89  ~.System.Block_42       Constant                PU Power1
%   98  ~.System.Block_8        S-Function              DCDC-converter
%   99  ~.System.Block_9        Demux                   Demux
%  100  ~.System.Block_29       Mux                     Mux2
%  109  ~.System.Block_7        S-Function              DCDC-Power
%  110  ~.System.Block_10       Demux                   Demux1
%  111  ~.System.Block_30       Mux                     Mux3
%  118  ~.System.Block_28       Mux                     Mux1
%  119  ~.System.Block_47       S-Function              PV-array
%  124  ~.System.Block_27       Mux                     Mux
%  125  ~.System.Block_48       S-Function              PV-array heat model
%  127  ~.System.Block_54       Product                 Product3
%  128  ~.System.Block_68       Terminator              Terminator
%  133  ~.System.Block_32       Mux                     Mux5
%  134  ~.System.Block_59       S-Function              S-Function1
%  135  ~.System.Block_70       S-Function              Transfer Fcn
%  140  ~.System.Block_4        Constant                Constant
%  141  ~.System.Block_5        Constant                Constant3
%  142  ~.System.Block_6        Constant                Constant4
%  143  ~.System.Block_13       Product                 Divide1
%  144  ~.System.Block_25       Sum                     Minus
%  145  ~.System.Block_26       Sum                     Minus1
%  146  ~.System.Block_67       Scope                   Scope D_controller/D_feedforward
%  148  ~.System.Block_76       Scope                   temperature
%  155  ~.System.Block_31       Mux                     Mux4
%  156  ~.System.Block_58       S-Function              S-Function
%  159  ~.System.Block_49       Scope                   PV_P_DC
%  160  ~.System.Block_51       Product                 Product
%  161  ~.System.Block_52       Product                 Product1
%  162  ~.System.Block_53       Product                 Product2
%  258  ~                       SubSystem               PV Power
%  259  ~.System.Block          Inport                  S_in_PU
%  260  ~.System.Block_1        Inport                  P_req_in_PU
%  261  ~.System.Block_3        Inport                  v_grid_abc_in_PU
%  262  ~.System.Block_2        Inport                  Q_req_in_PU
%  263  ~.System.Block_77       Outport                 P_dc_in_PU
%  264  ~.System.Block_78       Outport                 v_DC_in_PU
%  265  ~.System.Block_79       Outport                 P_grid_in_PU
%  266  ~.System.Block_80       Outport                 Q_grid_in_PU
%  267  ~.System.Block_81       Outport                 I_mag_phase_in_PU
%  268  ~.System.Block_82       Outport                 v_terminal_mag_pahse_PU

% 1st number = output format, 2nd number = todo flag
% ?1 = Outputs, ?3 = Derivatives
% 0? = Vector,  1? = Cell Array,  2? = Struct
flagout = (flag - mod(flag,10))/10; % output format
flag = mod(flag,10); % standard flag
if flag == 2, sys = []; return, end
if flag == 9, sys = []; return, end


% assign parameters to s-functions
p_109 = par_PV;
p_98 = par_PV;
p_119 = par_PV;
p_125 = par_PV;
p_156 = par_PV;
p_134 = par_PV;
p_50 = par_INV;
p_51 = par_INV;
p_52 = par_INV;
p_73 = 1.5707963267949;
p_135_1 = -100;
p_135_2 = 8;
p_135_3 = 12.5;
p_135_4 = 0;

% Initialisation
if flag == 0
    x0 = zeros(18,1);
    [~,x0_temp] = sfun_dcdc_converter([],[],[],0,p_98);
    x0(1:2) = x0_temp(1:2);
    [~,x0_temp] = sfun_SDM_heat([],[],[],0,p_125);
    x0(3:3) = x0_temp(1:1);
    [~,x0_temp] = sfun_cntrl_vpv_TS([],[],[],0,p_156);
    x0(4:4) = x0_temp(1:1);
    [~,x0_temp] = sfun_capacitor([],[],[],0,p_50);
    x0(5:5) = x0_temp(1:1);
    [~,x0_temp] = sFunc_converter([],[],[],0,p_51);
    x0(6:14) = x0_temp(1:9);
    [~,x0_temp] = modl_filter([],[],[],0,p_52);
    x0(15:17) = x0_temp(1:3);
    [~,x0_temp] = tf_sfun([],[],[],0,p_135_1,p_135_2,p_135_3,p_135_4);
    x0(18:18) = x0_temp(1:1);
    sys = [18 ,... % NumContStates
           0 ,... % NumDiscStates
           8 ,... % NumOutputs
           5 ,... % NumInputs
           0 ,... 
           1 ,... % DirectFeedthrough
           1 ]; % NumSampleTimes
    ts = [0 0];
    info.NumInports = 4;
    info.InportsVarName{1} = 'S_in_PU'; info.InportsDimension{1} = [1 1];
    info.InportsVarName{2} = 'P_req_in_PU'; info.InportsDimension{2} = [1 1];
    info.InportsVarName{3} = 'Q_req_in_PU'; info.InportsDimension{3} = [1 1];
    info.InportsVarName{4} = 'v_grid_abc_in_PU'; info.InportsDimension{4} = [2 1];
    info.NumOutports = 6;
    info.OutportsVarName{1} = 'P_dc_in_PU'; info.OutportsDimension{1} = [1 1];
    info.OutportsVarName{2} = 'v_DC_in_PU'; info.OutportsDimension{2} = [1 1];
    info.OutportsVarName{3} = 'P_grid_in_PU'; info.OutportsDimension{3} = [1 1];
    info.OutportsVarName{4} = 'Q_grid_in_PU'; info.OutportsDimension{4} = [1 1];
    info.OutportsVarName{5} = 'I_mag_phase_in_PU'; info.OutportsDimension{5} = [1 2];
    info.OutportsVarName{6} = 'v_terminal_mag_pahse_PU'; info.OutportsDimension{6} = [1 2];
    return
end

% Linearisation
if flag == 7
    if exist('derivest','file') ~= 2
        str = [
            'The function derivest was not found.' newline ...
            'Numerical linearisation relies on the "Adaptive Robust Numerical '...
            'Differentiation" by John D''Errico. You can download it here:' newline ...
            'https://de.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation'];
        error(str);
    end
    t0 = 0;
    x0 = x;
    if isa(u,'cell')
        u0(1:1,1) = u{1};
        u0(2:2,1) = u{2};
        u0(3:3,1) = u{3};
        u0(4:5,1) = u{4};
    elseif isa(u,'struct')
        u0(1:1,1) = u.S_in_PU;
        u0(2:2,1) = u.P_req_in_PU;
        u0(3:3,1) = u.Q_req_in_PU;
        u0(4:5,1) = u.v_grid_abc_in_PU;
    else
        u0 = u(:);
    end
    fun = @(t,x,u,flag)PVPower(t,x,u,flag,par_INV,par_PV);
    sys = linearisator(fun,t0,x0,u0);
    return
end

% Copy local states from global states
x_98(1:2,1) = x(1:2);
x_125(1:1,1) = x(3:3);
x_156(1:1,1) = x(4:4);
x_50(1:1,1) = x(5:5);
x_51(1:9,1) = x(6:14);
x_52(1:3,1) = x(15:17);
x_135(1:1,1) = x(18:18);

% Parse inputs
if flag == 1 || flag == 2 || flag == 3
    % direct feedthrough -> parse inputs for derivatives and outputs call
    if isa(u,'cell')
        S_in_PU = u{1};
        P_req_in_PU = u{2};
        Q_req_in_PU = u{3};
        v_grid_abc_in_PU = u{4};
    elseif isa(u,'struct')
        S_in_PU = u.S_in_PU;
        P_req_in_PU = u.P_req_in_PU;
        Q_req_in_PU = u.Q_req_in_PU;
        v_grid_abc_in_PU = u.v_grid_abc_in_PU;
    else
        S_in_PU = zeros([1 1]);  S_in_PU(:) = u(1:1);
        P_req_in_PU = zeros([1 1]);  P_req_in_PU(:) = u(2:2);
        Q_req_in_PU = zeros([1 1]);  Q_req_in_PU(:) = u(3:3);
        v_grid_abc_in_PU = zeros([2 1]);  v_grid_abc_in_PU(:) = u(4:5);
    end
end


% Constant Block 88 "PU Power"
y_88 = 3000000;
u_85_2 = y_88;                % Divide          <-- PU Power        

% Constant Block 86 "PU DC voltage"
y_86 = 5400;
u_160_2 = y_86;               % Product         <-- PU DC voltage   

% Constant Block 89 "PU Power1"
y_89 = 3000000;
u_162_2 = y_89;               % Product2        <-- PU Power1       

% Constant Block 87 "PU Irradtion"
y_87 = 1000;
u_161_2 = y_87;               % Product1        <-- PU Irradtion    
u_162_1 = P_req_in_PU;        % Product2        <-- P_req_in_PU     
u_161_1 = S_in_PU;            % Product1        <-- S_in_PU         

% S-Function Block 135 "Transfer Fcn"
y_135 = tf_sfun(t,x_135,[],3,p_135_1,p_135_2,p_135_3,p_135_4);

u_155_1 = y_135;              % Mux4            <-- Transfer Fcn    
u_143_1 = y_135;              % Divide1         <-- Transfer Fcn    

% S-Function Block 125 "PV-array heat model"
y_125 = sfun_SDM_heat(t,x_125,[],3,p_125);

u_133_2 = y_125;              % Mux5            <-- PV-array heat model 
u_155_5 = y_125;              % Mux4            <-- PV-array heat model 
u_118_3 = y_125;              % Mux1            <-- PV-array heat model 

% Product Block 161 "Product1"
y_161 =u_161_1 .* u_161_2;

u_118_2 = y_161;              % Mux1            <-- Product1        
u_124_1 = y_161;              % Mux             <-- Product1        
u_133_1 = y_161;              % Mux5            <-- Product1        
u_155_4 = y_161;              % Mux4            <-- Product1        

% S-Function Block 98 "DCDC-converter"
y_98 = sfun_dcdc_converter(t,x_98,[],3,p_98);

u_99_1 = y_98;                % Demux           <-- DCDC-converter  

% Demux Block 99 "Demux"
y_99_1 = u_99_1(1);
y_99_2 = u_99_1(2);

u_111_4 = y_99_2;             % Mux3            <-- Demux           
u_155_3 = y_99_2;             % Mux4            <-- Demux           
u_111_1 = y_99_1;             % Mux3            <-- Demux           
u_118_1 = y_99_1;             % Mux1            <-- Demux           
u_127_2 = y_99_1;             % Product3        <-- Demux           
u_155_2 = y_99_1;             % Mux4            <-- Demux           

% Mux Block 118 "Mux1"
y_118 = [u_118_1;u_118_2;u_118_3];

u_119_1 = y_118;              % PV-array        <-- Mux1            

% S-Function Block 119 "PV-array"
y_119 = sfun_SDM_cells(t,[],u_119_1,3,p_119);

u_127_1 = y_119;              % Product3        <-- PV-array        
u_111_2 = y_119;              % Mux3            <-- PV-array        
u_100_2 = y_119;              % Mux2            <-- PV-array        

% Product Block 127 "Product3"
y_127 =u_127_1 .* u_127_2;

u_124_2 = y_127;              % Mux             <-- Product3        

% Mux Block 124 "Mux"
y_124 = [u_124_1;u_124_2];

u_125_1 = y_124;              % PV-array heat model <-- Mux             

% Constant Block 140 "Constant"
y_140 = 1;
u_144_1 = y_140;              % Minus           <-- Constant        

% Constant Block 142 "Constant4"
y_142 = 5400;
u_143_2 = y_142;              % Divide1         <-- Constant4       

% Product Block 143 "Divide1"
y_143 = u_143_1./ u_143_2 ;

u_144_2 = y_143;              % Minus           <-- Divide1         

% Sum Block 144 "Minus"
y_144 = + u_144_1 - u_144_2;

u_145_2 = y_144;              % Minus1          <-- Minus           

% Constant Block 141 "Constant3"
y_141 = 0.8515;
u_145_3 = y_141;              % Minus1          <-- Constant3       

% Mux Block 155 "Mux4"
y_155 = [u_155_1;u_155_2;u_155_3;u_155_4;u_155_5];

u_156_1 = y_155;              % S-Function      <-- Mux4            

% S-Function Block 156 "S-Function"
y_156 = sfun_cntrl_vpv_TS(t,x_156,u_156_1,3,p_156);

u_145_1 = y_156;              % Minus1          <-- S-Function      

% Sum Block 145 "Minus1"
y_145 = + u_145_1 + u_145_2 - u_145_3;

u_100_3 = y_145;              % Mux2            <-- Minus1          
u_111_5 = y_145;              % Mux3            <-- Minus1          

% Product Block 162 "Product2"
y_162 =u_162_1 .* u_162_2;

u_133_3 = y_162;              % Mux5            <-- Product2        

% Mux Block 133 "Mux5"
y_133 = [u_133_1;u_133_2;u_133_3];

u_134_1 = y_133;              % S-Function1     <-- Mux5            

% S-Function Block 134 "S-Function1"
y_134 = sfun_cntrl_mppt_exact(t,[],u_134_1,3,p_134);

u_135_1 = y_134;              % Transfer Fcn    <-- S-Function1     

% S-Function Block 50 "S-Function4"
y_50 = sfun_capacitor(t,x_50,[],3,p_50);

u_32_1 = y_50;                % Divide5         <-- S-Function4     
u_46_2 = y_50;                % Mux8            <-- S-Function4     

% S-Function Block 52 "S-Function6"
y_52 = modl_filter(t,x_52,[],3,p_52);

u_31_1 = y_52;                % Divide4         <-- S-Function6     
u_47_2 = y_52;                % Mux9            <-- S-Function6     
u_46_4 = y_52;                % Mux8            <-- S-Function6     

% Constant Block 65 "PU Current1"
y_65 = 5400;
u_32_2 = y_65;                % Divide5         <-- PU Current1     

% Product Block 32 "Divide5"
y_32 = u_32_1./ u_32_2 ;

u_160_1 = y_32;               % Product         <-- Divide5         
v_DC_in_PU = y_32;            % v_DC_in_PU      <-- Divide5         

% Product Block 160 "Product"
y_160 =u_160_1 .* u_160_2;

u_111_3 = y_160;              % Mux3            <-- Product         
u_100_1 = y_160;              % Mux2            <-- Product         

% Mux Block 100 "Mux2"
y_100 = [u_100_1;u_100_2;u_100_3];

u_98_1 = y_100;               % DCDC-converter  <-- Mux2            

% Mux Block 111 "Mux3"
y_111 = [u_111_1;u_111_2;u_111_3;u_111_4;u_111_5];

u_109_1 = y_111;              % DCDC-Power      <-- Mux3            

% S-Function Block 109 "DCDC-Power"
y_109 = sfun_dcdc_power(t,[],u_109_1,3,p_109);

u_110_1 = y_109;              % Demux1          <-- DCDC-Power      

% Demux Block 110 "Demux1"
y_110_1 = u_110_1(1);
y_110_2 = u_110_1(2);

u_85_1 = y_110_2;             % Divide          <-- Demux1          

% Product Block 85 "Divide"
y_85 = u_85_1./ u_85_2 ;

u_71_1 = y_85;                % Product5        <-- Divide          
P_dc_in_PU = y_85;            % P_dc_in_PU      <-- Divide          
u_72_1 = Q_req_in_PU;         % Product6        <-- Q_req_in_PU     

% Constant Block 69 "PU Voltage1"
y_69 = 2700;
u_30_2 = y_69;                % Divide3         <-- PU Voltage1     

% Constant Block 67 "PU Power3"
y_67 = 5000000;
u_29_2 = y_67;                % Divide2         <-- PU Power3       
u_28_2 = y_67;                % Divide6         <-- PU Power3       

% Constant Block 66 "PU Power2"
y_66 = 5000000;
u_72_2 = y_66;                % Product6        <-- PU Power2       
u_71_2 = y_66;                % Product5        <-- PU Power2       

% Product Block 71 "Product5"
y_71 =u_71_1 .* u_71_2;

u_45_1 = y_71;                % Mux7            <-- Product5        
u_46_1 = y_71;                % Mux8            <-- Product5        

% Product Block 72 "Product6"
y_72 =u_72_1 .* u_72_2;

u_46_5 = y_72;                % Mux8            <-- Product6        

% Constant Block 68 "PU Voltage"
y_68 = 2700;
u_70_2 = y_68;                % Product4        <-- PU Voltage      
u_73_1 = v_grid_abc_in_PU;    % S-Function8     <-- v_grid_abc_in_PU 

% S-Function Block 73 "S-Function8"
y_73 = modl_magphi2vabc(t,[],u_73_1,3,p_73);

u_70_1 = y_73;                % Product4        <-- S-Function8     

% Product Block 70 "Product4"
y_70 =u_70_1 .* u_70_2;

u_47_1 = y_70;                % Mux9            <-- Product4        
u_44_2 = y_70;                % Mux6            <-- Product4        
u_46_3 = y_70;                % Mux8            <-- Product4        

% Mux Block 46 "Mux8"
y_46 = [u_46_1;u_46_2;u_46_3;u_46_4;u_46_5];

u_51_1 = y_46;                % S-Function5     <-- Mux8            

% S-Function Block 51 "S-Function5"
y_51 = sFunc_converter(t,x_51,u_51_1,3,p_51);

u_58_1 = y_51;                % states          <-- S-Function5     
u_57_1 = y_51;                % omega PLL in PU <-- S-Function5     
u_54_1 = y_51;                % V abc           <-- S-Function5     

% Selector Block 54 "V abc "
y_54 = u_54_1([11 12 13]);


u_30_1 = y_54;                % Divide3         <-- V abc           
u_44_1 = y_54;                % Mux6            <-- V abc           

% Selector Block 57 "omega PLL in PU"
y_57 = u_57_1(10);



% Selector Block 58 "states"
y_58 = u_58_1([1 2 3 4 5 6 7 8 9]);



% Mux Block 44 "Mux6"
y_44 = [u_44_1;u_44_2];

u_52_1 = y_44;                % S-Function6     <-- Mux6            

% Mux Block 47 "Mux9"
y_47 = [u_47_1;u_47_2];

u_49_1 = y_47;                % S-Function7     <-- Mux9            

% S-Function Block 49 "S-Function7"
y_49 = modl_3phase_power(t,[],u_49_1,3);

u_40_1 = y_49;                % Demux2          <-- S-Function7     

% Demux Block 40 "Demux2"
y_40_1 = u_40_1(1);
y_40_2 = u_40_1(2);

u_28_1 = y_40_1;              % Divide6         <-- Demux2          
u_41_1 = y_40_1;              % Gain1           <-- Demux2          

% Gain Block 41 "Gain1"
y_41 = -1*u_41_1;


u_45_2 = y_41;                % Mux7            <-- Gain1           

% Mux Block 45 "Mux7"
y_45 = [u_45_1;u_45_2];

u_50_1 = y_45;                % S-Function4     <-- Mux7            
u_29_1 = y_40_2;              % Divide2         <-- Demux2          

% Product Block 30 "Divide3"
y_30 = u_30_1./ u_30_2 ;

u_74_1 = y_30;                % S-Function2     <-- Divide3         

% S-Function Block 74 "S-Function2"
y_74 = modl_vabc2magphi(t,[],u_74_1,3);

v_terminal_mag_pahse_PU = y_74;% v_terminal_mag_pahse_PU <-- S-Function2     

% Product Block 29 "Divide2"
y_29 = u_29_1./ u_29_2 ;

Q_grid_in_PU = y_29;          % Q_grid_in_PU    <-- Divide2         

% Product Block 28 "Divide6"
y_28 = u_28_1./ u_28_2 ;

P_grid_in_PU = y_28;          % P_grid_in_PU    <-- Divide6         

% Constant Block 64 "PU Current"
y_64 = 1234.5679;
u_31_2 = y_64;                % Divide4         <-- PU Current      

% Product Block 31 "Divide4"
y_31 = u_31_1./ u_31_2 ;

u_75_1 = y_31;                % S-Function3     <-- Divide4         

% S-Function Block 75 "S-Function3"
y_75 = modl_vabc2magphi(t,[],u_75_1,3);

I_mag_phase_in_PU = y_75;     % I_mag_phase_in_PU <-- S-Function3     

% Define output
switch flag

    case 1
        
        % Calculate all derivatives
        dx = zeros(18,1);
        
        % S-Function derivative call of "DCDC-converter" (SID 98)
        dx(1:2) = sfun_dcdc_converter(t,x_98,u_98_1,1,p_98);
        
        % S-Function derivative call of "PV-array heat model" (SID 125)
        dx(3:3) = sfun_SDM_heat(t,x_125,u_125_1,1,p_125);
        
        % S-Function derivative call of "S-Function" (SID 156)
        dx(4:4) = sfun_cntrl_vpv_TS(t,x_156,u_156_1,1,p_156);
        
        % S-Function derivative call of "S-Function4" (SID 50)
        dx(5:5) = sfun_capacitor(t,x_50,u_50_1,1,p_50);
        
        % S-Function derivative call of "S-Function5" (SID 51)
        dx(6:14) = sFunc_converter(t,x_51,u_51_1,1,p_51);
        
        % S-Function derivative call of "S-Function6" (SID 52)
        dx(15:17) = modl_filter(t,x_52,u_52_1,1,p_52);
        
        % S-Function derivative call of "Transfer Fcn" (SID 135)
        dx(18:18) = tf_sfun(t,x_135,u_135_1,1,p_135_1,p_135_2,p_135_3,p_135_4);
        
        sys = dx;
    case 2
        
        % Calculate all mdlupdates
        x_disc_new = zeros(0,1);
        
        sys = x_disc_new;
        
    case 3
        % Compose outputs
        if flagout == 1
            y = {};
            y{1} = P_dc_in_PU;
            y{2} = v_DC_in_PU;
            y{3} = P_grid_in_PU;
            y{4} = Q_grid_in_PU;
            y{5} = I_mag_phase_in_PU;
            y{6} = v_terminal_mag_pahse_PU;
        elseif flagout == 2
            y = struct();
            y.P_dc_in_PU = P_dc_in_PU;
            y.v_DC_in_PU = v_DC_in_PU;
            y.P_grid_in_PU = P_grid_in_PU;
            y.Q_grid_in_PU = Q_grid_in_PU;
            y.I_mag_phase_in_PU = I_mag_phase_in_PU;
            y.v_terminal_mag_pahse_PU = v_terminal_mag_pahse_PU;
        else
            y = [P_dc_in_PU(:);v_DC_in_PU(:);P_grid_in_PU(:);Q_grid_in_PU(:);I_mag_phase_in_PU(:);v_terminal_mag_pahse_PU(:);];
        end
        sys = y;
end

end % end of PVPower
