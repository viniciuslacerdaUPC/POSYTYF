function [sys,x0,info,ts] = sFunc_converter(t,x,u,flag,par)
% level 1 S-Function providing initialisation, derivatives and outputs

if flag == 1 || flag == 3
    p_wt = u(1);
    vDC = u(2);
    Vabc = u(3:5);
    Iabc = u(6:8);
    qr = u(9)/par.Conv.sb;
end

% different tasks
switch flag
    case 0 % initialisation
        [sys,x0,info,ts] = mdlInitialize(par);
    case 1 % calculate derivatives
        sys = mdlDerivatives(t,x,...
            p_wt,vDC,Vabc,Iabc,qr,...
            par);
    case 3 % calculate outputs
        sys = mdlOutputs(t,x,...
            p_wt,vDC,Vabc,Iabc,qr,...
            par);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

end

%==========================================================================
% mdlDerivatives
% Return the derivatives for the continuous states
%==========================================================================
function dx = mdlDerivatives(t,x,...
    p_wt,vDC,Vabc,Iabc,qr,...
    par)

thetaPLL = x(1);%mod(x(1),2*pi);
xIPLL = x(2);

% dq trans
vab_ = par.Conv.T*Vabc/par.Conv.vb;%/sqrt(3);
vab = vab_(1)+1j*vab_(2);

vm = vab*exp(-1j*thetaPLL); % in dq
vdq = vm;

iab_ = par.Conv.T*Iabc/par.Conv.ib;
iab = iab_(1)+1j*iab_(2);

im = iab*exp(-1j*thetaPLL); % in dq
idq = im;

% calculate PLL
wPLLpu = par.Conv.kpPLL*imag(vm) + par.Conv.kiPLL*xIPLL; %
dxIPLL = imag(vm);
wPLL = wPLLpu*par.Conv.w; %
dthetaPLL = wPLL;

% calculate power
sm = vm*conj(im); %3/2*vm*conj(im); % magnitude invariant dqtrafo

% calculate DCLink control
eDC = par.DC.V0-vDC;
dxIvDC = eDC;
xIvDC = x(9);
peDC = par.Conv.kpDC*eDC+par.Conv.kiDC*xIvDC;

% reference values
pr = p_wt/par.Conv.sb; %p_wt
if pr < 0
    pr = 0;
end

if par.ConvVersion == 1 
    pr = (peDC+p_wt)/par.Conv.sb;
end

switch par.ConvVersion
    case 0 % grid following
        xIs = x(3)+1j*x(4); % intergral states of power controller
        xIi = x(5)+1j*x(6); % integral state of current controller
        v = x(7) + 1j*x(8); % just filter state!
        
        dv = -1/par.Conv.Tf*(v-vm);
        %di = -1/par.Conv.Tf*(i-im);
        
        sr = pr+1j*qr;
        
        es = (conj(sr)-conj(sm));
        
        dxIs = es;
        
        % !!
        ir = par.Conv.kps*(es)+par.Conv.kis*xIs+peDC/par.Conv.sb;
        
        [ir,flag] = CurrentLim(par,ir,vm);
        if flag == 1
            dxIs = 0; % freeze integrator
            dxIvDC = 0;
        end
        % calculate current controller
        %ei = ir-im;
        %dxIi = ei;
        [dxIi,~] = CalcCurCntrl(par,im,ir,xIi,vm);
        
        dx = [dthetaPLL; dxIPLL; real(dxIs); imag(dxIs); real(dxIi); imag(dxIi); real(dv); imag(dv);dxIvDC];
        
        if t < -0.5
            dx = [dthetaPLL; dxIPLL; 0; 0; 0; 0; 0; 0;0];
        end
    case 1
        pfil = x(5); % filtered active power signal
        qfil = x(6); % filtered reactive power signal
        prfil = x(7); % filtered active power reference
        xIi = x(10)+1j*x(11);
        
        dpfil = -1/par.Conv.Tf*pfil + 1/par.Conv.Tf*real(sm); %
        dqfil = -1/par.Conv.Tf*qfil + 1/par.Conv.Tf*imag(sm); % same filter time constant as active power meas
        dprfil = -1/par.Conv.Tf*prfil + 1/par.Conv.Tf*pr;
        
        dE0 = 0; % E = E0 + kQ*Q (in SolveNetwork) % can be subsequently used for secondary control!
        
        [ir,flag] = CurrentLim(par,im,vm);
                
        dxIi = 0;
        
        ep = (prfil-pfil);%(pr-real(sm));%(pr-pfil);
        %eQ = (Q-Qd);
        df = par.Conv.kf*ep;
        dtheta = (df + wPLLpu)*par.Conv.w;
        
        dx = [dthetaPLL; dxIPLL; dtheta; dE0; dpfil; dqfil; dprfil; 0; dxIvDC; real(dxIi); imag(dxIi)];
        
        if t < -0.5
            dx = [dthetaPLL; dxIPLL; dthetaPLL; 0; 0; 0; 0; 0;0;0;0];
        end
    case 2
        pfil = x(5); % filtered active power signal
        qfil = x(6); % filtered reactive power signal
        prfil = x(7); % filtered active power reference
        xIi = x(10)+1j*x(11);
        
        ep = (prfil-pfil);
        %eQ = (Q-Qd);
        
        eDC = (par.DC.V0-vDC)/par.DC.V0;
        
        
        df = par.Conv.kf*ep-par.Conv.kiDC*eDC;
        dtheta = (df + 1)*par.Conv.w;
                
        eq = qr-qfil;%-imag(sm); 
        theta = x(3)+par.Conv.ktheta*ep; % + K
        e = x(4) + par.Conv.kpq*eq; % E0 + Q droop
        vm = vab*exp(-1j*theta); % in dq at theta reference frame
        ir = (e-vm)/(par.Conv.rf+1j*par.Conv.w*par.Conv.lf);
               
        % calculate current controller
        [dxIi,~] = CalcCurCntrl(par,im,ir,xIi,vm);
        dE0 = par.Conv.kiq*eq;
        dpfil = -1/par.Conv.Tf*pfil + 1/par.Conv.Tf*real(sm); %
        dqfil = -1/par.Conv.Tf*qfil + 1/par.Conv.Tf*imag(sm); % same filter time constant as active power meas
        dprfil = -1/par.Conv.Tf*prfil + 1/par.Conv.Tf*pr;
        
        dx = [dthetaPLL; dxIPLL; dtheta; dE0; dpfil; dqfil; dprfil; 0; dxIvDC; real(dxIi); imag(dxIi)];
        
        if t < -0.5
            dx = [dthetaPLL; dxIPLL; dthetaPLL; 0; 0; 0; 0; 0;0;0;0];
        end
end

end

%==========================================================================
% mdlOutputs
% Return the block outputs
%==========================================================================
function y = mdlOutputs(t,x,...
    p_wt,vDC,Vabc,Iabc,qr,...
    par)

%% converter output
thetaPLL = x(1);
xIPLL = x(2);

%
vab_ = par.Conv.T*Vabc/par.Conv.vb;%/sqrt(3);
vab = vab_(1)+1j*vab_(2);

vm = vab*exp(-1j*thetaPLL); % in dq

% calculate for output
wPLLpu = par.Conv.kpPLL*imag(vm) + par.Conv.kiPLL*xIPLL; %

iab_ = par.Conv.T*Iabc/par.Conv.ib;
iab = iab_(1)+1j*iab_(2);

im = iab*exp(-1j*thetaPLL); % in dq

sm = vm*conj(im);%3/2*vm*conj(im);

% calculate DCLink control
eDC = par.DC.V0-vDC;
%dxIvDC = eDC;
xIvDC = x(9);
peDC = par.Conv.kpDC*eDC+par.Conv.kiDC*xIvDC;

pr = p_wt/par.Conv.sb;
if pr < 0
    pr = 0;
end
if par.ConvVersion == 1 
    pr = (peDC+p_wt)/par.Conv.sb;
end

sr = pr+1j*qr;

switch par.ConvVersion
    case 0
        xIs = x(3)+1j*x(4);
        xIi = x(5)+1j*x(6);
        
        es = (conj(sr)-conj(sm));%1/conj(v)*(conj(sr)-conj(s));
        
        ir = par.Conv.kps*(es)+par.Conv.kis*xIs+peDC/par.Conv.sb;
        [ir,~] = CurrentLim(par,ir,vm);
        
        
        [~,edq] = CalcCurCntrl(par,im,ir,xIi,vm);
        
        eab_ = edq*exp(1j*thetaPLL);
    case 1
        pfil = x(5); % filtered active power signal
        prfil = x(7); % filtered active power reference
        xIi = x(10)+1j*x(11);
        
        [ir,flag] = CurrentLim(par,im,vm);
        ep = (prfil-pfil);%(pr-real(sm));%(pr-pfil);
        E = x(4) + par.Conv.kV.*imag(sm); % E0 + Q droop
        theta = x(3)+par.Conv.ktheta*ep; % + K
        eab_ = E*exp(1j.*thetaPLL)/par.Conv.vb;
        
    case 2
        pfil = x(5); % filtered active power signal
        qfil = x(6); % filtered reactive power signal
        prfil = x(7); % filtered active power reference
        
        xIi = x(10)+1j*x(11);
        ep = (prfil-pfil);
        eq = qr - qfil;%imag(sm);
        
        eDC = (par.DC.V0-vDC)/par.DC.V0;
        
        theta = x(3)+par.Conv.ktheta*ep - par.Conv.kiDC*eDC; % + K
        e = x(4) + par.Conv.kpq.*eq; % E0 + Q droop
        vm = vab*exp(-1j*theta); % in dq at theta reference frame
        ir = (e-vm)/(par.Conv.rf+1j*par.Conv.w*par.Conv.lf);
        
        [~,edq] = CalcCurCntrl(par,im,ir,xIi,vm);
        eab_ = edq*exp(1j*theta);
        
        % PLL not in use in this case
        df = par.Conv.kf*ep-par.Conv.kiDC*eDC;
        dtheta = (df + 1)*par.Conv.w;
        wPLLpu = dtheta;
end
eab = [real(eab_) ; imag(eab_)];
Vabc_cmd = par.Conv.T_*eab*par.Conv.vb;

if t < -0.5
    Vabc_cmd = Vabc;
end

y = [x ; wPLLpu ; Vabc_cmd];

end

%==========================================================================
% mdlInitialize
% Return the sizes, initial conditions, and sample times for the S-function
%==========================================================================
function [sys,x0,str,ts] = mdlInitialize(par)
sizes = simsizes;
sizes.NumContStates  = numel(par.Conv.x0);
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = numel(par.Conv.x0) + 1 + 3; % states + omega + voltage
sizes.NumInputs      = 9; % total number of in numeric values
sizes.DirFeedthrough = 1; % direct feedthrough since D is not 0
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0  = par.Conv.x0;
ts  = [0 0];

str = [];
end

%==========================================================================
% performs current limitation logic, flag = 1 means the current was altered
%==========================================================================
function [dxIi,e] = CalcCurCntrl(par,im,ir,xIi,vm)
%% current limitation handling
% calculate current controller
ei = ir-im;
dxIi = ei;

e = par.Conv.kpi*(ei) + par.Conv.kii*xIi + vm + 1j*(par.Conv.w*par.Conv.lf)*im;

end

%==========================================================================
% performs current limitation logic, flag = 1 means the current was altered
%==========================================================================
function [ir,flag] = CurrentLim(par,i,vm)
%% current limitation handling
flag = 1;
signiq = -1;
if abs(vm) < par.Conv.VgfaultLimit % voltage fault
    iq = interp1(par.Conv.Vfault,par.Conv.iqfault,abs(vm),'linear',1);
    if abs(iq) > par.Conv.imax
        ir = 1j*iq*signiq;
    else
        id = sqrt(par.Conv.imax^2-iq^2);
        if abs(id) > abs(real(i))
            ir = real(i)+1j*iq*signiq;
        else
            if real(i) > 0
                ir = id + 1j*iq*signiq;
            else
                ir = -id + 1j*iq*signiq;
            end
        end
    end
elseif abs(i) > par.Conv.imax % active power prio
    if abs(real(i)) > par.Conv.imax
        if real(i)>0
            ir = par.Conv.imax;
        else
            ir = -par.Conv.imax;
        end
    else
        iq = sqrt(par.Conv.imax^2-real(i)^2);
        if iq > abs(imag(i))
            ir = real(i) + 1j*imag(i);
        else
            if imag(i) > 0
                ir = real(i) + 1j*iq;
            else
                ir = real(i) - 1j*iq;
            end
        end
    end
else
    ir = i;
    flag = 0;
end

end
