%=========================================================================
%=========================================================================

function [sys,x0,str,ts] = modl_filter(t,x,u,flag,par)
% Netzseitiges Filter
% Inputs    u(1:3) = iin
% States    x(1:3) = iL
% Outputs   y(1:3) = uout

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes(par);
    case 1 % Calculate derivatives
        sys = mdlDerivatives(t,x,u,par);
    case 3 % Calculate outputs
        sys = mdlOutputs(t,x,u,par);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par)
        x0 = par.grid.iF0;
        sizes = simsizes;
        sizes.NumContStates  = numel(x0);
        sizes.NumDiscStates  = 0;
        sizes.NumOutputs     = 3;
        sizes.NumInputs      = 6;
        sizes.DirFeedthrough = 1;
        sizes.NumSampleTimes = 1;
        sys = simsizes(sizes);
        
        str = [];
        % sample time is continuous -> ts = 0 and offset = 0
        ts = [0 0];
    end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(t,x,u,par)
        
        vc = u(1:3); 
        vg = u(4:6); 
        
        if par.CalcRMS == 0 
            RF = par.Conv.Rf; 
            LF = par.Conv.Lf;
            dx = ( - (RF)*x + vc-vg ) / LF;
        else
            dx = zeros(3,1); 
        end

    end

    %%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(t,x,u,par)
        if par.CalcRMS == 0 
            y = x;
        else 
            vc = u(1:3); 
        	vg = u(4:6);
            vc_ab = par.Conv.T*vc; 
            vc_ab = vc_ab(1)+1j*vc_ab(2);
            vg_ab = par.Conv.T*vg;
            vg_ab = vg_ab(1)+1j*vg_ab(2);
            
            omg = par.Conv.w;
            
            RF = par.Conv.Rf; 
            LF = par.Conv.Lf;
            i_ab = (vc_ab-vg_ab)/(RF+1j*omg*LF);
            
            y = par.Conv.T_*[real(i_ab);imag(i_ab)];
        end
        
    end

end % end of modl_grid %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

