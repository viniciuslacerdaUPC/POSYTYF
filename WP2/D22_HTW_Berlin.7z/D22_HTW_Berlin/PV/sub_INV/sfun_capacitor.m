function [sys,x0,str,ts] = sfun_capacitor(t,x,u,flag,par)
% Gleichspannung-Zwischenkreis
% Inputs    u(1) = pM  = Leistungsfluss Zwischenkreis -> Maschine
%           u(2) = pG  = Leistungsfluss Zwischenkreis -> Netzseite
% States    x(1) = vDC = Zwischenkreisspannung
% Outputs   y(1) = vDC = Zwischenkreisspannung
% Parameter par.DClink

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes(par);
    case 1 % Calculate derivatives
        sys = mdlDerivatives(t,x,u,par);
    case 3 % Calculate outputs
        sys = mdlOutputs(x,par);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par)
        x0 = par.DC.V0;
        sizes = simsizes;
        sizes.NumContStates  = numel(x0);
        sizes.NumDiscStates  = 0;
        sizes.NumOutputs     = 1;
        sizes.NumInputs      = 2;
        sizes.DirFeedthrough = 0;
        sizes.NumSampleTimes = 1;
        sys = simsizes(sizes);
        
        str = [];
        % sample time is continuous -> ts = 0 and offset = 0
        ts = [0 0];
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(t,x,u,par)
        vDC = x;
        pM = u(1);
        pG = u(2);
        C = par.DC.C;
        
        
        dx =  ( pM + pG )/C/vDC;   

        if vDC < .1*par.DC.V0 && dx < 0
            dx = 0; 
        elseif vDC > 1.3*par.DC.V0 && dx > 0 
            dx = 0; 
        end
        
        if t < -0.5
            dx = 0;
        end
    
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(x,par)
        vDC = x;
        
        vDC = min( 1.3*par.DC.V0 , max( .1 * par.DC.V0,vDC ) );
        
        y = vDC;
    end

end % end of modl_conv2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


