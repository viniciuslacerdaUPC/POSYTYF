function [sys,x0,str,ts] = sfun_SDM_heat(~,x,u,flag,par)
% Implementation of thermal cell model
% 
% Inputs    u(1) = S    = [W/m^2] irradiation
%           u(2) = P    = [W] electrical power 
% 
% Outputs   y(1) = Tc   = [K] module temperature in Kelvin
% 
% Parameter par_PV.heat

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes(par);
    case 1 % Derivatives
        sys = mdlDerivatives(x,u,par);
    case 3 % Calculate outputs
        sys = mdlOutputs(x);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par)
        x0 = par.heat.x0;
        sys = [ numel(x0) 0 ... % ContStates DiscStates ...
            1 2 ... % NumOutputs NumInputs ...
            0 0 1 ]; % 0 DirFeedthrough NumSampleTimes
        str = [];
        ts = [0 0]; % sample time is continuous -> ts = 0 and offset = 0
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(x,u,par)

        S = u(1); % [W/m^2] irradiation
        P = u(2); % [W] electrical power 

        % temperatures
        T_mod = x; % [K] module temperature in Kelvin
        T_air = par.heat.T_air;
        T_sky = T_air;
        T_film = (T_air + T_mod)/2; % [K] air temp near the module (7)
        T_ground = (3*T_air + 1*T_mod)/4; % approximation by stephan
        
        % properties of air
        abs_humidity = par.heat.abs_humidity;
        air_pressure = par.heat.air_pressure;
        [rho,cp,Pr,nu] = properties_of_air(T_film,abs_humidity,air_pressure);
        alpha = nu/Pr;
        lam = nu*rho*cp/Pr;
        
        % free convection, laminar
        theta = par.heat.theta; % angle of the PV module to horizontal
        L = par.heat.Length; % characteristic length
        
        Ra = 9.81*L^3*abs(T_mod-T_air)/T_air/(alpha*nu); % Rayleigh free convection
        f1 = (1+(0.492/Pr)^(9/16))^(-16/9);
        Nu_bot = ( 0.825 + 0.387*(cos(theta)*Ra*f1)^(1/6) )^2; % Nusselt bottom of plate
        
        Rac = 10^( 8.9 - 0.00178*( theta*180/pi )^1.82 );
        Nu_top = 0.56*( Rac*cos(theta) )^(1/4) + 0.13*( Ra^(1/3) - Rac^(1/3) ); % Nusselt top of plate
        
        Nu_free = Nu_top + Nu_bot; % combine Nussel for top and bottom of plate
        h_free = Nu_free*lam/L;
        
        % forced convection
        v = par.heat.v_wind;
        Re = v*L/nu;
        Nu_forced = 0.931*Re^(1/2)*Pr^(1/3);
        h_forced = Nu_forced*lam/L;
                
        % combined convection
        Nu = (Nu_free^3 + Nu_forced^3)^(1/3);
        h = Nu*lam/L;
        q_conv = h*(T_mod - T_air);
        
        % radiation income
        eta = par.heat.eta; % [1] absorptivity of the PV module
        q_solar = eta*S;

        % radiation losses
        sigma = par.heat.sigma;
        epsilon = par.heat.epsilon;
        q_radiation = sigma*epsilon*( 2*T_mod^4 - T_sky^4 - T_ground^4);
        
       
        A_total = par.heat.A_total;
        C_per_sm = par.heat.C_per_sm;

        dx = + q_solar ... % irradiation
            - P/A_total ... % losses due electrical power gen
            - q_conv ... % convective losses
            - q_radiation; % radiation losses
        
        dx = dx / C_per_sm;
    end




    function [rho,cp,Pr,nu] = properties_of_air(t,x,p)
        TK = t; % [K]
        TC = t - 273.15; % [°C]
        
        ps = 611.0*exp(-1.91275E-4 + 7.258E-2*TC - 2.939E-4*TC.^2 + 9.841E-7*TC.^3 - 1.92E-9*TC.^4);
        xs = 0.622 * ps ./ ( p - ps );
        
        x = min(x,xs);

        rho_dryair = 1./(7.837152e-01 + TC*2.878047e-03); % stephan
        rho_vapour = exp(11.41 - 4194./TK - 99183./TK.^2); % Böckh, Wetzel: Wärmeübertragung
        rho = ( rho_dryair + x.*rho_vapour ) ./ (1+x);
        
        cp_dryair = 1006.5 + TC*5.309587e-3 + TC.^2*4.758596e-4 - TC.^3*1.136145e-7; % stephan
        cp_vapour = TC.^3*7.204488e-05 + TC.^2*2.771800e-03 + TC*8.855238e-01 + 1.887174e+03; % stephan
        cp = ( cp_dryair + x.*cp_vapour ) ./ (1+x);
         
        Pr = 1e9./(1.1*TC.^3 - 1200*TC.^2 + 322000*TC + 1.393e9); % [1]
        
        nu = TC.^2*1.059441e-10 + TC*8.903287e-08 + 1.349846e-05;
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(x)
        y = x; % [K] module temperature in Kelvin
    end



end

