function [sys,x0,str,ts] = sfun_cntrl_mppt_3po(~,x,u,flag,par)

% Ali M. Eltamaly Almoataz Y. Abdelaziz
% Modern Maximum Power Point Tracking Techniques for Photovoltaic Energy Systems
% Chapter 7: On the Improvements of Perturb-and-Observe-Based MPPT in PV Systems
% Section 5: dP-P&O Method [4, 5]
%
% [4] Sera D, Teodorescu R, Kerekes T, Blaabjerg F (2006) Improve MPPT method for rapidly
% changing environmental conditions. In: Proceedings of 12th conference on electronics and
% motion control, Montreal, Quebec, Canada, 2006, pp 1614–1619
%
% [5] Sera D, Teodorescu R, Hantschel J, Knoll M (2008) Optimized maximum power point tracker
% for fast-changing environmental conditions. IEEE Trans Ind Electron 55(7):2629–2637

switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes(par);
    case 2
        sys = mdlUpdate(x,u,par);
    case 3
        sys = mdlOutputs(x,u,par);
    case { 1, 4, 9 }
        sys = [];
    otherwise
        error('Simulink:blocks:unhandledFlag', num2str(flag));
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sys,x0,str,ts] = mdlInitializeSizes(par)

% Parameter
disc_stepsize = par.mppt.apo.delay;
n = par.mppt.apo.n;

NumDiscStates = 2*n;
NumSampleTime = 1;
ts = [ disc_stepsize  0];

% simulink info vector
sys = [0 ,... % NumContStates
    NumDiscStates+1 ,... % NumDiscStates
    1,... % NumOutputs
    1,... % NumInputs
    0 ,...
    1 ,... % DirectFeedthrough
    NumSampleTime ]; % NumSampleTimes

x0 = par.mppt.apo.x0;

str = [];

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function x = mdlUpdate(x,u,par)

n = par.mppt.apo.n;

v = x(1:n);
P = x(n+1:2*n);
v1 = v(1); v2 = v(2); v3 = v(3);
P0 = u; P1 = P(1); P2 = P(2);
dP = (P1 - P2) - (P0 - P1);

flag = x(end);

if flag
    v0 = v1 + (2*(v2>=v3)-1)*(2*(dP>=0)-1)*par.mppt.apo.stepsize;
    switch par.DCDC.type
        case 'buck', v0 = max(par.DCDC.v_DC_R,v0);
        case 'boost', v0 = max(0,min(par.DCDC.v_DC_R,v0));
        case 'buck_boost', v0 = max(0,v0);
        otherwise, error('type');
    end
else
    v0 = v1;
end

x = [ v0 ; v(1:n-1) ; P0 ; P(1:n-1) ; ~flag ];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function y = mdlOutputs(x,u,par)

n = par.mppt.apo.n;

v = x(1:n);
P = x(n+1:2*n);
v1 = v(1); v2 = v(2); v3 = v(3);
P0 = u; P1 = P(1); P2 = P(2);
dP = (P1 - P2) - (P0 - P1);
flag = x(end);

if flag
    v0 = v1 + (2*(v2>=v3)-1)*(2*(dP>=0)-1)*par.mppt.apo.stepsize;
    switch par.DCDC.type
        case 'buck', v0 = max(par.DCDC.v_DC_R,v0);
        case 'boost', v0 = max(0,min(par.DCDC.v_DC_R,v0));
        case 'buck_boost', v0 = max(0,v0);
        otherwise, error('type');
    end
else
    v0 = v1;
end

y = v0;
end

