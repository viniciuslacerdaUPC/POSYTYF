function [sys,x0,str,ts] = sfun_cntrl_membership(t,x,u,flag,par)
% Implementation of TS dc-dc-voltage controller
% Inputs    u(1) = v_pv_ref [V] reference input voltage
%           u(2) = v_pv_cur [V] current input voltage
%           u(3) = i_L_cur  = [A] current coil current
%           u(4) = S [W/m²] irraditaion
%           u(5) = Tc [K] cell temperature
% Premise variables: [S Tc v_pv_cur] = u([4 5 2])
% Outputs   y(1) = h
% Remark 1  Buck converter: D = v_dc / v_pv
%           Boost converter: D = 1 - v_pv / v_dc
%           Buck-Boost converter: D = v_dc / ( v_dc + v_pv )
% Parameter par_PV.cntrl_vpv

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes(par);
    case 3 % Calculate outputs
        sys = mdlOutputs(t,x,u,par);
    case { 1, 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par)
        z = [par.cell.S_STC par.cell.Tc_STC par.geno.V_pv_MMP]; % premise variable
        h = findMembership(z,par.cntrl_vpv.TS.premise);
        n = numel(h);
        x0 = [];
        sys = [ 0 0 ... % ContStates DiscStates ...
            n 5 ... % NumOutputs NumInputs ...
            0 1 1 ]; % 0 DirFeedthrough NumSampleTimes
        str = [];
        ts = [0 0]; % sample time is continuous -> ts = 0 and offset = 0
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function h = mdlOutputs(t,x,u,par)
        
        % inputs
        v_pv_ref = u(1);
        v_pv_cur = u(2);
        i_L_cur = u(3);
        S = u(4);
        T = u(5);

        % parameters
        z = [S T v_pv_cur]; % premise variable
%         z = [S T i_L_cur]; % premise variable
        
        h = full(findMembership(z,par.cntrl_vpv.TS.premise));
        hsum = full(sum(h(:))) - 1;
    end

end

