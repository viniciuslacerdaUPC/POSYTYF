%--------------------------------------------------------------------------
% see func_SDM_Np_Ns_cells                                       29.3.2021
%--------------------------------------------------------------------------
%  Implementation of the single diode model for Np*Ns cells
%--------------------------------------------------------------------------
% para_mdl.Np: Np cells in parallel
% para_mdl.Ns: Ns cells in series
%--------------------------------------------------------------------------
% [1] Weidong Xiao, Photovoltaic Power Systems, Wiley, 2017
% [1,T4.6] Model parameters Model parameters were taken from Table 4.6
% [1,T4.4] Table 4.4, Weidong Xiao, Photovoltaic Power Systems, Wiley, 2017
%--------------------------------------------------------------------------
% [2] Zhao et al., Grid-Integration and Standalone PV Distributed
%     Generation Systems, Wiley, 2018
%--------------------------------------------------------------------------
function [sys,x0,str,ts] = sfun_SDM_cells(~,~,u,flag,par)
% Implementation of the single diode model for Np*Ns cells
% Inputs    u(1) = v_pv = [V] overall cell array voltage
%           u(2) = S    = [W/m^2] irradiation
%           u(3) = Tc   = [K] Cell temperature in Kelvin
% Outputs   y(1) = i_pv = [A] overall cell array current
% Parameter par.modl.cell = one cell
%           par.modl.geno = cell array

if nargin == 0
    mdlTestrun();
    return;
end

if nargin < 5 || isempty(par)
    par = mdlDefaultParameter();
end

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes();
    case 3 % Calculate outputs
        sys = mdlOutputs(u,par);
    case 6 % analytical linearisation
        sys = mdlAnalyticalLinearisation(u,par);
    case 8 % maximum power point
        sys = mdlNumericalMMP(u,par);
    case { 1, 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes()
        x0 = [];
        sys = [ numel(x0) 0 ... % ContStates DiscStates ...
            1 3 ... % NumOutputs NumInputs ...
            0 1 1 ]; % 0 DirFeedthrough NumSampleTimes
        str = [];
        ts = [0 0]; % sample time is continuous -> ts = 0 and offset = 0
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(u,par)
        
        % u = [ v_pv S Tc ]
        v_pv = u(1); % voltage
        S = u(2); % [W/m^2] irradiation
        Tc = u(3); % [K] Cell temperature in Kelvin
        
        %% sub-functions: i_ph(S,Delta_T), v_OV(Delta_T)
        % a) calculation PV photon current i_ph at STC as function of irradiation S and cell temperature Tc
        %    see [2], Equation (2.5) with CT =  alpha_T * Iph_STC  or [1], Equation (4.67)
        % b) calculation open-circuit correction for variation of cell temperature, [1], Equation (4.23)
        %    but without correction factor vT(S)
        Delta_Tc = Tc - par.cell.Tc_STC;
        i_ph = (S/par.cell.S_STC) * par.cell.Iph_SC_STC * ( 1 + par.cell.alpha_T * Delta_Tc);
        v_OC = par.cell.V_OC_STC * (1 + par.cell.beta_T * Delta_Tc);
        
        %% sub-function i_s(S,Delta_T)
        %  calculation PV photon current based on [1], eq. (4.68)
        i_s = (i_ph - (v_OC / par.cell.Rh)) / (exp( v_OC / (par.cell.VT_STC * par.cell.An) ) - 1);
        
        %% function i_pv(S,Delta_T)
        %  calculation PV photon current based on [1], eq. (4.69)
        i_d  = i_s * ((exp( v_pv / (par.geno.Ns * par.cell.VT_STC * par.cell.An) ) - 1));
        i_pv = par.geno.Np * (i_ph - i_d - (v_pv / (par.geno.Ns *par.cell.Rh)));
        
        y = i_pv;
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function sys = mdlAnalyticalLinearisation(u,par)
        %--------------------------------------------------------------------------------------
        %  delta_func_delta_x1_SDM_Np_Ns_cells                               14.4.2021
        %--------------------------------------------------------------------------------------
        %  Implementation of the derivation of the single diode model for Np*Ns cells
        %--------------------------------------------------------------------------------------
        % para_mdl.Np: Np cells in parallel
        % para_mdl.Ns: Ns cells in series
        %--------------------------------------------------------------------------------------
        % [1] Weidong Xiao, Photovoltaic Power Systems, Wiley, 2017, equation (6.12)
        %--------------------------------------------------------------------------------------
        
        % u = [ v_pv S Tc ]
        % u(1) = D is the only input (S and Tc are parameters)
        v_pv_c = u(1); % voltage
        S = u(2); % [W/m^2] irradiation
        Tc = u(3); % [K] Cell temperature in Kelvin
        
        %% sub-functions: i_ph(S,Delta_T), v_OV(Delta_T)
        % a) calculation PV photon current i_ph at STC as function of irradiation S and cell temperature Tc
        %    see [2], Equation (2.5) with CT =  alpha_T * Iph_STC  or [1], Equation (4.67)
        % b) calculation open-circuit correction for variation of cell temperature, [1], Equation (4.23)
        %    but without correction factor vT(S)
        Delta_Tc = Tc - par.cell.Tc_STC;
        i_ph = (S/par.cell.S_STC) * par.cell.Iph_SC_STC * ( 1 + par.cell.alpha_T * Delta_Tc);
        v_OC = par.cell.V_OC_STC * (1 + par.cell.beta_T * Delta_Tc);
        
        %% sub-function i_s(S,Delta_T)
        %  calculation PV photon current based on [1], eq. (4.68)
        i_s = (i_ph - (v_OC / par.cell.Rh)) / (exp( v_OC / (par.cell.VT_STC * par.cell.An) ) - 1);
        
        %% function delta_func_delta_x1_SDM_Np_Ns_cells
        %  calculation of the derivation [1], equation (6.12)
        term = i_s * ( exp( v_pv_c / (par.geno.Ns * par.cell.VT_STC * par.cell.An)));
        term = - term * par.geno.Np / (par.geno.Ns * par.cell.VT_STC * par.cell.An);
        dfdx1 = term - par.geno.Np / (par.geno.Ns * par.cell.Rh);
        
        sys = dfdx1; % there are no states, therefore sys = D
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function sys = mdlNumericalMMP(u,par)
        % finds v_pv = u(1) such that P = v_pv * i_pv is maximal
        %
        % starting value v_pv = u(1), 0 is treated as 1
        % S = u(2) and Tc = u(3) are treated as parameters

        % parameters
        v_pv = u(1); % [V] overall cell array voltage
        S = u(2); % [W/m^2] irradiation
        Tc = u(3); % [K] Cell temperature in Kelvin
        
        if v_pv == 0, v_pv = 1; end
        
        % define derivative of P: P' = i_pv + v_pv * i_pv'
        fun_i_pv = @(v_pv)sfun_SDM_cells([],[],[v_pv;S;Tc],3,par); % i_pv as function of v_pv
        fun_di_pv = @(v_pv)sfun_SDM_cells([],[],[v_pv;S;Tc],6,par); % derivative of i_pv as function of v_pv
        fun_dpower = @(v_pv)fun_di_pv(v_pv)*v_pv + fun_i_pv(v_pv); % derivative of P as function of v_pv

        % find v_pv_max which max P = v_pv * i_pv or which makes P' = 0
        while fun_dpower(v_pv) < 0
            v_pv = v_pv/2;
        end
        while fun_dpower(v_pv) > 0
            v_pv = v_pv*2;
        end
        v_pv_max = fzero(fun_dpower,[v_pv/3 v_pv]);

        sys = v_pv_max;
    end

end

