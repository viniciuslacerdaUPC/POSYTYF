function [w,ind] = findWeight(x,xAP)

if nargout == 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    w = zeros(size(xAP));
    if x <= min(xAP)
        w(1) = 1;
    elseif x >= max(xAP)
        w(end) = 1;
    else
        i1 = find(xAP <= x,1,'last');
        i2 = find(xAP >= x,1,'first');
        if all(i1 == i2)
            w(i1) = 1;
        else
            w(i1) = (xAP(i2) - x)/(xAP(i2) - xAP(i1));
            w(i2) = (x - xAP(i1))/(xAP(i2) - xAP(i1));
        end
    end

elseif nargout == 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if x <= min(xAP)
        w = 1;
        ind = 1;
    elseif x >= max(xAP)
        w = 1;
        ind = numel(xAP);
    else
        i1 = find(xAP <= x,1,'last');
        i2 = find(xAP >= x,1,'first');
        if all(i1 == i2)
            w = 1;
            ind = i1;
        else
            w = [ (xAP(i2) - x)/(xAP(i2) - xAP(i1)) , ...
                (x - xAP(i1))/(xAP(i2) - xAP(i1)) ];
            ind = [ i1 , i2 ];
        end
   
    end
    
else %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    error('nargout ~= 1 && nargout ~= 2');
    
end %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end


