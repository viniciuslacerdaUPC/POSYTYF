function [sys,x0,str,ts] = sfun_cntrl_mppt_es(t,x,u,flag,par)
% Implementation of extremum seeking for max power point tracking
% Inputs    u(1) = P_pv [W] current electrical power
% Outputs   y(1) = v_pv_ref [V] reference photo voltage
% Parameter par.mppt.es

switch flag
    case 0 % Initialization
        [sys,x0,str,ts]=mdlInitializeSizes(par);
    case 1 % Derivatives
        sys = mdlDerivatives(t,u,par);
    case 3 % Calculate outputs
        sys = mdlOutputs(t,x,par);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par)
        x0 = par.mppt.es.I_init;
        sys = [ numel(x0) 0 ... % ContStates DiscStates ...
            1 1 ... % NumOutputs NumInputs ...
            0 0 1 ]; % 0 DirFeedthrough NumSampleTimes
        str = [];
        ts = [0 0]; % sample time is continuous -> ts = 0 and offset = 0
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(t,u,par)
        
        % inputs
        P_pv = u(1);
        
        % sinosidual test signal
        omega_p = par.mppt.es.omega_p;
        usin = sin(t*omega_p);
        
        % multiplication gives the derivative
        dx = P_pv*usin;
        
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function v_pv_ref = mdlOutputs(t,x,par)

        % states
        integ = x(1); % integral of signal multiplication

        % parameters
        Ap = par.mppt.es.Ap;
        kI = par.mppt.es.kI;
        max_v_pv_ref = par.mppt.es.max_v_pv;
        
        % sinosidual test signal
        omega_p = par.mppt.es.omega_p;
        usin = sin(t*omega_p);
        
        % output
        v_pv_ref = min(max_v_pv_ref,max(0,kI*integ + Ap*usin));

    end

end

