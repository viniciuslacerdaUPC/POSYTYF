function [sys,x0,str,ts] = sfun_SDM_dcdc_converter(t,x,u,flag,par)
% Implementation of single diode model (PV) and dc-dc-converter
% 
% Inputs    u(1) = v_dc = [V] output voltage
%           u(2) = D    = [1] duty cylce ratio 0 <= D <= 1
%           u(3) = S    = [W/m^2] irradiation
%           u(4) = Tc   = [K] Cell temperature in Kelvin
% 
% Outputs   y(1) = v_pv = [V] voltage PV side
%           y(2) = i_L  = [A] coil current
%           y(3) = i_pv = [A] overall cell array current
% 
% Remark 1  Buck converter: D = v_dc / v_pv
%           Boost converter: D = 1 - v_pv / v_dc
%           Buck-Boost converter: D = v_dc / ( v_dc + v_pv )
% 
% Parameter par_PV.DCDC

switch flag
    case 0 % Initialization
        [sys,x0,str,ts]=mdlInitializeSizes(par);
    case 1 % Derivatives
        sys = mdlDerivatives(t,x,u,par);
    case 3 % Calculate outputs
        sys = mdlOutputs(x,u,par);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par)
        x0 = par.DCDC.x0;
        sys = [ numel(x0) 0 ... % ContStates DiscStates ...
            3 4 ... % NumOutputs NumInputs ...
            0 1 1 ]; % 0 DirFeedthrough NumSampleTimes
        str = [];
        ts = [0 0]; % sample time is continuous -> ts = 0 and offset = 0
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(t,x,u,par)
        
        % states
        v_pv = x(1);
        i_L = x(2);
        
        % inputs
        v_dc = u(1); % [V] output voltage
        D = u(2); % [1] duty cylce ratio 0 <= D <= 1
        S = u(3); % [W/m^2] irradiation
        Tc = u(4); % [K] Cell temperature in Kelvin
        
        % calculate photo cell current
        i_pv = sfun_SDM_cells([],[],[v_pv;S;Tc],3,par);
        
        % make D either 0 or 1 if no average model is selected
        if ~par.DCDC.avg && D > 0 && D < 1
            D = mod( ( t + par.DCDC.t0 ) * par.DCDC.f_sw , 1 ) <= D;
        end
        
        % L and C values of the converter
        C = par.DCDC.C;
        L = par.DCDC.L;
        
        % right hand side of differential equation
        
        switch par.DCDC.type
            case 'buck' % buck converter
                dx1 = (i_pv - D * i_L )/C;
                dx2 = (D * v_pv - v_dc)/L;
            case 'boost' % boost converter
                dx1 = (i_pv - i_L)/C;
                dx2 = (v_pv + v_dc * D - v_dc)/L;
            case 'buck_boost' % buck boost converter
                dx1 = (i_pv - D*i_L)/C;
                dx2 = (D*v_pv + v_dc*D - v_dc)/L;
            otherwise
                error('unknown converter');
        end
        dx = [dx1;dx2];
        
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(x,u,par)
        
        % states
        v_pv = x(1);
        i_L = x(2);
        
        % inputs
        v_dc = u(1); % [V] output voltage
        D = u(2); % [1] duty cylce ratio 0 <= D <= 1
        S = u(3); % [W/m^2] irradiation
        Tc = u(4); % [K] Cell temperature in Kelvin
        
        % calculate photo cell current
        i_pv = sfun_SDM_cells([],[],[v_pv;S;Tc],3,par);

        y = [v_pv;i_L;i_pv];
    end


end

