function [sys,x0,str,ts] = sfun_cntrl_mppt_exact(~,~,u,flag,par)
% Implementation of the single diode model for Np*Ns cells
% Inputs    u(1) = S    = [W/m^2] irradiation
%           u(2) = T    = [K] Cell temperature in Kelvin
%           u(3) = P    = demanded Power 
%                         P > 0 left of MPPT
%                         P < 0 right of MPPT
% Outputs   y(1) = v_pv = [V] 

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes();
    case 3 % Calculate outputs
        sys = mdlOutputs(u,par);
    case { 1, 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

end


function [sys,x0,str,ts] = mdlInitializeSizes()
x0 = [];
sys = [ numel(x0) 0 ... % ContStates DiscStates ...
    1 3 ... % NumOutputs NumInputs ...
    0 1 1 ]; % 0 DirFeedthrough NumSampleTimes
str = [];
ts = [0 0]; % sample time is continuous -> ts = 0 and offset = 0
end


function y = mdlOutputs(u,par)

% u = [ S T P ]
S = u(1);
T = u(2);
P = u(3);

% define derivative of P: P' = i_pv + v_pv * i_pv'
fun_i_pv = @(v_pv)sfun_SDM_cells([],[],[v_pv;S;T],3,par); % i_pv as function of v_pv
fun_di_pv = @(v_pv)sfun_SDM_cells([],[],[v_pv;S;T],6,par); % derivative of i_pv as function of v_pv
fun_dpower = @(v_pv)fun_di_pv(v_pv)*v_pv + fun_i_pv(v_pv); % derivative of P as function of v_pv

% maximum (actual) power point
Delta_Tc = T - par.cell.Tc_STC;
v_OC = par.geno.Ns * par.cell.V_OC_STC * (1 + par.cell.beta_T * Delta_Tc);
v_pv_max = fzero(fun_dpower,[0 v_OC]);
P_pv_max = v_pv_max * fun_i_pv(v_pv_max);

% cancel if demanded power exceeds possible power
if P_pv_max <= abs(P)
    y = v_pv_max;
    return
end

% search power point corresponding to P
fun_power = @(v_pv) fun_i_pv(v_pv) * v_pv - abs(P);
if P > 0 % search left of maximum
    v_pv_req = fzero(fun_power,[0 v_pv_max]);
else
    v_pv_req = fzero(fun_power,[v_pv_max v_OC]);
end
y = v_pv_req;

end



