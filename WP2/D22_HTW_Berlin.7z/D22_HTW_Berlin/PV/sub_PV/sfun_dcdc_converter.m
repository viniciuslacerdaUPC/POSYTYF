function [sys,x0,str,ts] = sfun_dcdc_converter(t,x,u,flag,par)
% Implementation of dc-dc-converter
% Inputs    u(1) = v_dc = [V] output voltage
%           u(2) = i_pv = [A] input current
%           u(3) = D    = [1] duty cylce ratio 0 <= D <= 1
% Outputs   y(1) = v_pv = [V] input voltage
%           y(2) = i_L  = [A] coil current
% Remark 1  input side usually connects to photovolatic cell (pv)
%           output side usually connects to inverter (dc)
% Remark 2  Buck converter: D = v_dc / v_pv
%           Boost converter: D = 1 - v_pv / v_dc
%           Buck-Boost converter: D = v_dc / ( v_dc + v_pv )
% Parameter par_PV.DCDC

switch flag
    case 0 % Initialization
        [sys,x0,str,ts]=mdlInitializeSizes(par);
    case 1 % Derivatives
        sys = mdlDerivatives(t,x,u,par);
    case 3 % Calculate outputs
        sys = mdlOutputs(x);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes(par)
        x0 = par.DCDC.x0;
        sys = [ numel(x0) 0 ... % ContStates DiscStates ...
            2 3 ... % NumOutputs NumInputs ...
            0 0 1 ]; % 0 DirFeedthrough NumSampleTimes
        str = [];
        ts = [0 0]; % sample time is continuous -> ts = 0 and offset = 0
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(t,x,u,par)
        
        % states
        v_pv = x(1);
        i_L = x(2);
        
        % inputs
        v_dc = u(1);
        i_pv = u(2);
        D = u(3);
        
        % make D either 0 or 1 if no average model is selected
        if ~par.DCDC.avg && D > 0 && D < 1
            D = mod( ( t + par.DCDC.t0 ) * par.DCDC.f_sw , 1 ) <= D;
        end
        
        % L and C values of the converter
        C = par.DCDC.C;
        L = par.DCDC.L;
        
        % right hand side of differential equation
        
        switch par.DCDC.type
            case 'buck' % buck converter
                dx1 = (i_pv - D * i_L )/C;
                dx2 = (D * v_pv - v_dc)/L;
            case 'boost' % boost converter
                dx1 = (i_pv - i_L)/C;
                dx2 = (v_pv + v_dc * D - v_dc)/L;
            case 'buck_boost' % buck boost converter
                dx1 = (i_pv - D*i_L)/C;
                dx2 = (D*v_pv + v_dc*D - v_dc)/L;
            otherwise
                error('unknown converter');
        end
        dx = [dx1;dx2];
        
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(x)
        
        % states
        v_pv = x(1);
        i_L = x(2);

        y = [v_pv;i_L];
    end

end

