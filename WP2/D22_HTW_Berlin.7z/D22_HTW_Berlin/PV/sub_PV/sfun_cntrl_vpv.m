function [sys,x0,str,ts] = sfun_cntrl_vpv(~,x,u,flag,par)
% Implementation of dc-dc-voltage controller
% Inputs    u(1) = v_pv_ref [V] reference input voltage
%           u(2) = v_pv_cur [V] current input voltage
%           u(3) = i_L_cur  = [A] current coil current
% Outputs   y(1) = D    = [1] duty cycle
% Remark 1  input side usually connects to photovolatic cell (pv)
%           output side usually connects to inverter (dc)
% Remark 2  Buck converter: D = v_dc / v_pv
%           Boost converter: D = 1 - v_pv / v_dc
%           Buck-Boost converter: D = v_dc / ( v_dc + v_pv )
% Parameter par_PV.cntrl_vpv

switch flag
    case 0 % Initialization
        [sys,x0,str,ts]=mdlInitializeSizes();
    case 1 % Derivatives
        sys = mdlDerivatives(u);
    case 3 % Calculate outputs
        sys = mdlOutputs(x,u,par);
    case { 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes()
        x0 = 0;
        sys = [ numel(x0) 0 ... % ContStates DiscStates ...
            1 3 ... % NumOutputs NumInputs ...
            0 1 1 ]; % 0 DirFeedthrough NumSampleTimes
        str = [];
        ts = [0 0]; % sample time is continuous -> ts = 0 and offset = 0
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function dx = mdlDerivatives(u)
        
        % inputs
        v_pv_ref = u(1);
        v_pv_cur = u(2);
        i_L = u(3);
        
        % right hand side of differential equation
        dx = v_pv_ref - v_pv_cur;
        
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function y = mdlOutputs(x,u,par)
        
        % inputs
        v_pv_ref = u(1);
        v_pv_cur = u(2);
        i_L_cur = u(3);
        
        % states
        int_delta_v_pv = x(1); % integral of v_pv_ref - v_pv_cur

        % parameters
        Kx = par.cntrl_vpv.Kx;
        KI = par.cntrl_vpv.KI;
        v_pvc = par.cntrl_vpv.eql_point.v_pvc; % v_pv
        i_Lc = par.cntrl_vpv.eql_point.i_Lc; % i_L

        % D
        D = par.cntrl_vpv.eql_point.D - KI*int_delta_v_pv - Kx(1)*(v_pv_cur - v_pvc) - Kx(2)*(i_L_cur - i_Lc);
        D = max(D,par.cntrl_vpv.D_min);
        D = min(D,par.cntrl_vpv.D_max);
        
        y = D;
    end

end

