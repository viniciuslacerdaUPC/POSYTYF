function h = findMembership(z,LinPoints)

n_dim = numel(LinPoints); % Anzahl Dimensionen

h = sparse(1,1,1, 1,1, 2^n_dim);
for i1 = 1:n_dim
    n = numel(LinPoints{i1});
    if z(i1) <= LinPoints{i1}(1)
        h = h * sparse(1,1,1, 1,n, 1);
    elseif z(i1) >= LinPoints{i1}(end)
        h = h * sparse(1,n,1, 1,n, 1);
    else
        ind1 = binarySearch(LinPoints{i1}, z(i1));
        ind2 = ind1 + 1;
        
        xi = z(i1);
        x1 = LinPoints{i1}(ind1);
        x2 = LinPoints{i1}(ind2);
        dx = x2 - x1;
        
        h = h * sparse([1 1],[ind1 ind2],[(x2-xi) (xi-x1)]/dx, 1,n);
    end
    h = h(:);
end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function idx = binarySearch(A, num)
% find largest idx such that A(idx) <= num
l = 1;
r = length(A);
idx = 1;
while l < r
    idx = 1 + floor((l + r - 1) / 2);
    if A(idx) > num
        r = idx - 1;
    elseif A(idx) <= num
        l = idx;
    end
end
if l == r
    idx = r;
end
if A(idx) > num
    idx = -1;
end
end
