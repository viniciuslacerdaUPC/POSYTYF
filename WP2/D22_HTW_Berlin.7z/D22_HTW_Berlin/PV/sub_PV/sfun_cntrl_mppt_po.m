function [sys,x0,str,ts] = sfun_cntrl_mppt_po(~,x,u,flag,par)

switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes(par);
    case 2
        sys = mdlUpdate(x,u,par);
    case 3
        sys = mdlOutputs(x,u,par);
    case { 1, 4, 9 }
        sys = [];
    otherwise
        error('Simulink:blocks:unhandledFlag', num2str(flag));
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sys,x0,str,ts] = mdlInitializeSizes(par)

% Parameter
disc_stepsize = par.mppt.po.delay;
n = par.mppt.po.n;

NumDiscStates = 2*n;
NumSampleTime = 1;
ts = [ disc_stepsize  0];

% simulink info vector
sys = [0 ,... % NumContStates
    NumDiscStates ,... % NumDiscStates
    1,... % NumOutputs
    1,... % NumInputs
    0 ,...
    1 ,... % DirectFeedthrough
    NumSampleTime ]; % NumSampleTimes

x0 = par.mppt.po.x0;

str = [];

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function x = mdlUpdate(x,u,par)

n = par.mppt.po.n;

v = x(1:n);
P = x(n+1:2*n);
v1 = v(1); v2 = v(2);
P0 = u; P1 = P(1);

dP = P0 - P1;
v0 = v1 + (2*(v1>=v2)-1)*(2*(dP>=0)-1)*par.mppt.po.stepsize;
switch par.DCDC.type
    case 'buck', v0 = max(par.DCDC.v_DC_R,v0);
    case 'boost', v0 = max(0,min(par.DCDC.v_DC_R,v0));
    case 'buck_boost', v0 = max(0,v0);
    otherwise, error('type');
end

x = [ v0 ; v(1:n-1) ; P0 ; P(1:n-1) ];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function y = mdlOutputs(x,u,par)

n = par.mppt.po.n;

v = x(1:n);
P = x(n+1:2*n);
v1 = v(1); v2 = v(2);
P0 = u; P1 = P(1);

dP = P0 - P1;
v0 = v1 + (2*(v1>=v2)-1)*(2*(dP>=0)-1)*par.mppt.po.stepsize;
switch par.DCDC.type
    case 'buck', v0 = max(par.DCDC.v_DC_R,v0);
    case 'boost', v0 = max(0,min(par.DCDC.v_DC_R,v0));
    case 'buck_boost', v0 = max(0,v0);
    otherwise, error('type');
end

y = v0;
end

