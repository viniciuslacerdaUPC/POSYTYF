function [sys,x0,str,ts] = sfun_dcdc_power(t,~,u,flag,par)
% Implementation of dc-dc-converter power calculations
% Inputs    u(1) = v_pv = [V] input voltage
%           u(2) = i_pv = [A] input current
%           u(3) = v_dc = [V] output voltage
%           u(4) = i_L  = [A] coil current
%           u(5) = D    = [1] duty cylce ratio 0 <= D <= 1
% Outputs   y(1) = P_pv = [W] input power
%           y(2) = P_dc = [W] output power
% Remark 1  input side usually connects to photovolatic cell (pv)
%           output side usually connects to inverter (dc)
% Remark 2  Buck converter: D = v_dc / v_pv
%           Boost converter: D = 1 - v_pv / v_dc
%           Buck-Boost converter: D = v_dc / ( v_dc + v_pv )
% Parameter par_PV.DCDC

switch flag
    case 0 % Initialization
        [sys,x0,str,ts] = mdlInitializeSizes();
    case 3 % Calculate outputs
        sys = mdlOutputs(t,u,par);
    case { 1, 2, 4, 9 } % Unused flags
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]); % Error handling
end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%
    function [sys,x0,str,ts] = mdlInitializeSizes()
        x0 = [];
        sys = [ numel(x0) 0 ... % ContStates DiscStates ...
            2 5 ... % NumOutputs NumInputs ...
            0 1 1 ]; % 0 DirFeedthrough NumSampleTimes
        str = [];
        ts = [0 0]; % sample time is continuous -> ts = 0 and offset = 0
    end

%%%%%%%%%%%%%%%%%%%%%        SubFunction        %%%%%%%%%%%%%%%%%%%%%

    function y = mdlOutputs(t,u,par)
        
        % inputs
        v_pv = u(1);
        i_pv = u(2);
        v_dc = u(3);
        i_L = u(4);
        D = u(5);
        
        % make D either 0 or 1 if no average model is selected
        if ~par.DCDC.avg && D > 0 && D < 1
            D = mod( ( t + par.DCDC.t0 ) * par.DCDC.f_sw , 1 ) <= D;
        end
        
        switch par.DCDC.type
            case 'buck' % buck converter
                P_pv = v_pv * i_pv; % pv power (input)
                P_dc = v_dc * i_L; % dc power (output)
            case 'boost' % boost converter
                P_pv = v_pv * i_pv; % pv power (input power)
                i_dc = (1 - D) * i_pv;
                P_dc = v_dc * i_dc; % dc power (output power)
            case 'buck_boost' % buck boost converter
                P_pv = v_pv * i_pv; % pv power (input power)
                i_dc = ((1 - D)/D) * i_pv; % dc power (output power)
                P_dc = v_dc * i_dc;
            otherwise
                error('unknown converter');
        end
        
        y = [P_pv;P_dc];
    end



end

