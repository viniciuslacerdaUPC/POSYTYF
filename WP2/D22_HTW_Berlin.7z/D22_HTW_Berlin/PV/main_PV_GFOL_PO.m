function main_PV_GFOL_PO(todo)

if nargin == 0
    main_PV_GFOL_PO(0);
    main_PV_GFOL_PO(1);
    main_PV_GFOL_PO(2);
    main_PV_GFOL_PO(3);
    main_PV_GFOL_PO(4);
    main_PV_GFOL_PO(5);
    return
end

ext = '_GFOL_PO';
str_mdl_name = 'PV';

addpath('sub_PV');
addpath('sub_INV');
addpath('sub_GRID');

              init_time = 1;    event_time = 0.1;     sim_time = 30;
%   -1   0 <--init_time--> X <--event_time--> X <-----sim_time-----> X
% ---+---+-----------------+------------------+----------------------+-> t

open(str_mdl_name);

switch todo
        
    case 0 % sim to op
        
        assign_parameter();
        assign_testcase(init_time+event_time);
        
        open(str_mdl_name);
        res = sim(str_mdl_name, 'StartTime', num2str(-1), 'StopTime', num2str(init_time), 'SaveFinalState', 'on', ...
            'LoadInitialState', 'off', 'SaveOperatingPoint', 'on',...
            'FinalStateName', 'xFinal');
        
        save( ['results\' str_mdl_name '_initialise' ext '.mat'], 'res');
       
    case {1 2 3 4 5} % test cases
        
        assign_parameter();
        assign_testcase(init_time+event_time,todo);
        
        S = load([ 'results\' str_mdl_name '_initialise' ext '.mat']); res = S.res;
        assignin('base', 'xFinal', res.get('xFinal'));
        
        open(str_mdl_name);
        res = sim(str_mdl_name, 'StartTime', num2str(init_time), 'StopTime', num2str(init_time+sim_time), 'SaveFinalState', 'off', ...
            'LoadInitialState', 'on', 'InitialState', 'xFinal');
        save( [ 'results\' str_mdl_name '_Testcase' num2str(todo) ext '.mat'], 'res');
        
end

end


function assign_parameter()

S = load('parameter\parameter_pv_PO.mat');
par_PV = S.par_PV;
assignin('base','par_PV',par_PV);

S = load('parameter\parameter_inv_GFOL.mat');
par_INV = S.par_INV;
assignin('base','par_INV',par_INV);

S = load('parameter\parameter_grid.mat'); 
par_GRID = S.par_GRID;
assignin('base','par_GRID',par_GRID);

end

function assign_testcase(event_time,varargin)

par_TEST.Testcase1 = 0;
par_TEST.Testcase2 = 0;
par_TEST.Testcase3 = 0;
par_TEST.Testcase4 = 0;
par_TEST.Testcase5 = 0;
for i1 = 1:nargin-1
    eval(sprintf('par_TEST.Testcase%i = 1;',varargin{i1}));
end
par_TEST.event_time = event_time;
assignin('base','par_TEST',par_TEST);
        
end


